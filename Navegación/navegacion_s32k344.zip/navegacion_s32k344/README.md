# Navegación visual con una CNN entrenada y ejecutada en el NXP S32K344

Un microcontrolador **NXP S32K344** (Cortex-M7 a 160 MHz) controla un robot **Pioneer P3DX**
simulado en **CoppeliaSim**:

- Pide las fotos de la cámara del robot.
- Las redimensiona y normaliza.
- Ejecuta una CNN INT8 para reconocer señales.
- Decide la acción.
- Calcula la cinemática inversa de las ruedas.

El micro además puede **entrenar la CNN desde cero** con descenso de gradiente, cuantizarla a INT8
y usarla para navegar.

Un programa puente en Python (`pc/puente_coppelia.py`) conecta el simulador con el micro. El puente
solo transporta datos y mide indicadores. Las decisiones y el aprendizaje ocurren en el micro.

```
 CoppeliaSim  --ZMQ-->  puente_coppelia.py  --UART 460800-->  S32K344
 (Pioneer, cámara,  <--   (dataset, fotos,   <--  (preprocesamiento, CNN,
  sensor de distancia)     motores, métricas)       control, entrenamiento)
```

---

## 1. Contenido

```
navegacion_s32k344/
├── firmware/
│   ├── comun/           Código C común (va en el proyecto de S32DS como carpeta vinculada)
│   │   ├── app.c/.h          Lazo principal: pide trabajo a la PC y lo ejecuta
│   │   ├── preproc.c/.h      Gris + Lanczos (idéntico a Pillow) + normalización INT8
│   │   ├── cnn_int8.c/.h     Motor de inferencia INT8 (bit-exacto a TFLite)
│   │   ├── entrenamiento.c/.h  Entrenamiento float (SGD), calibración y cuantización
│   │   ├── control.c/.h      Umbral, votación, máquina de estados, cinemática inversa
│   │   ├── protocolo.c/.h    Tramas binarias con secuencia y CRC-16
│   │   ├── config.h          Parámetros del control (umbral, velocidades, robot)
│   │   ├── arquitectura.h    Dimensiones de la CNN
│   │   ├── memoria.h         Memoria de trabajo compartida y secciones de RAM
│   │   └── hal.h             Interfaz con el hardware
│   ├── modelo/          cnn_modelo.c/.h y cnn_vectores.c/.h (los genera exportar_modelo_c.py)
│   ├── s32k344/         hal_s32k344.c y main.c (van en la carpeta src del proyecto)
│   └── pc/              hal_pc.c, main_pc.c, Makefile: el mismo firmware compilado para la PC
└── pc/
    ├── puente_coppelia.py   Puente PC <-> micro <-> CoppeliaSim (entrenar / evaluar / navegar)
    ├── protocolo.py         Protocolo del lado de la PC (TCP o puerto serie)
    ├── robots.py            Pioneer P3DX, cámara, sensor de distancia y escena
    ├── metricas.py          Indicadores y gráficas
    ├── exportar_modelo_c.py Convierte modelo_int8.tflite a C y lo verifica contra TFLite
    ├── pesos_mcu.py         Convierte los pesos descargados del micro a .npz / Keras
    ├── f1_desde_csv.py      Accuracy y F1 de los modelos del micro a partir de la telemetría
    ├── hacer_hoja.py        Hoja con las fotos que vio la CNN cerca de las señales
    └── diagnostico_serie.py Muestra los bytes crudos que manda el micro (depuración)
```

---

## 2. Requisitos

| Lado | Necesitas |
|---|---|
| PC | Python 3.10+, `pip install numpy pillow matplotlib pyserial coppeliasim-zmqremoteapi-client` (y `tensorflow` solo para `exportar_modelo_c.py` y `pesos_mcu.py`) |
| Simulador | CoppeliaSim Edu 4.10 con la escena `escena_CNN_Coppelia.ttt` (Pioneer P3DX con `CamaraFrontal`, paneles E1–E5) |
| Micro | Tarjeta con S32K344, S32 Design Studio 3.6 con RTD, cable USB (puerto COM virtual) |
| Prueba sin tarjeta (opcional) | MSYS2 UCRT64 con `gcc` y `make` |

---

## 3. Flujo de trabajo

### 3.1 Exportar el modelo INT8 de Python a C

Requiere `modelo_int8.tflite` (de `cuantizar_cnn.py`, ver el README de los códigos de Python):

```
cd pc
python exportar_modelo_c.py --tflite "<...>\resultados_cnn\modelo_int8.tflite" --test "<...>\dataset_run\test"
```

Genera `firmware/modelo/cnn_modelo.c/.h` y `cnn_vectores.c/.h`. Además compara el motor en C con
TFLite. El resultado esperado es que coincidan en la clase en todas las imágenes, con una
diferencia de logits de 1 LSB como máximo.

### 3.2 (Opcional) Probar todo sin la tarjeta

El mismo firmware se compila para la PC y se comunica por TCP:

```
cd firmware/pc
make CC=gcc                      # en MSYS2 UCRT64
```
Abre dos terminales:
```
python pc/puente_coppelia.py navegar --tcp 5005 --modelo pc        # terminal 1 (CoppeliaSim abierto)
firmware/pc/firmware_pc 127.0.0.1 5005                             # terminal 2
```
Los tiempos medidos así son de la PC, no del micro.

### 3.3 Proyecto en S32 Design Studio

1. Crea un proyecto **S32K344** con RTD (configuración `Debug_FLASH`).
2. **ConfigTools:**
   - `CORE_CLK` a 160 MHz.
   - **LPUART6** a **460800** baudios, 8N1, con los pines del LPUART que van al USB de la tarjeta.
     El firmware inicializa el LPUART con RTD, pero envía y recibe leyendo los registros directamente,
     así que **no hace falta configurar interrupciones ni DMA**.
   - Con `LPUART6_CLK` = 40 MHz, el firmware afina el divisor para quedar a 459 770 baudios (−0.2 %).
3. **Archivos:**
   - Agrega `firmware/comun` y `firmware/modelo` como **carpetas vinculadas** (*Linked Folder*) y
     añádelas a los *Includes* y a *Source Location*.
   - Copia `firmware/s32k344/hal_s32k344.c` y `main.c` a la carpeta `src` del proyecto.
   - **No** pongas `hal_pc.c` en `comun` ni en `src`: es solo para la versión de PC.
4. En `hal_s32k344.c`, revisa los nombres marcados **AJUSTAR** (instancia del LPUART, configuración
   de pines y relojes). Deben coincidir con los generados en la carpeta `generate/`.
5. **Linker:** los pesos no caben en `int_sram`. Agrega dentro de `SECTIONS { ... }` de
   `Project_Settings/Linker_Files/linker_flash_s32k344.ld`:
   ```
   .ia_dtcm (NOLOAD) :
   {
       . = ALIGN(4);
       *(.ia_dtcm)
       . = ALIGN(4);
   } > int_dtcm

   .ia_nocache (NOLOAD) :
   {
       . = ALIGN(4);
       *(.ia_nocache)
       . = ALIGN(4);
   } > int_sram_no_cacheable
   ```
6. **Compilador:** *Optimization Level* `-O2`, FPU por hardware (`fpv5-sp-d16`, *hard float*), y
   los símbolos `I_CACHE_ENABLE` y `D_CACHE_ENABLE` en el preprocesador.
7. **Project → Clean**, **Build** y graba con el depurador.

Para obtener la memoria del firmware, usa la línea `text data bss` de la consola de Build:
- **Flash** = (text + data) / 1024 KB
- **RAM** = (data + bss) / 1024 KB

### 3.4 Ejecutar en la tarjeta

Orden recomendado:
1. Abre CoppeliaSim con la escena.
2. Corre el comando de Python.
3. Dale **Resume** al micro en S32DS.

El micro repite su saludo cada 10 s hasta que el puente le contesta. **No toques Play ni Stop en
CoppeliaSim** mientras corre: el puente controla la simulación.

**Evaluar** en el micro el modelo INT8 de Python con el conjunto de prueba:
```
python puente_coppelia.py evaluar --serie COM4 --baudios 460800 --carpeta "<...>\dataset_run\test" --modelo pc
```

**Entrenar en el micro** y luego navegar con la red aprendida (unas 2 h):
```
python puente_coppelia.py entrenar --serie COM4 --baudios 460800 --datos "<...>\dataset_run" --epocas 30 --decaimiento 0.97 --paciencia 5 --navegar --guardar-fotos --flash-total-kb 134.9 --ram-total-kb 344.4
```

**Navegar** con una red entrenada antes en el micro, sin volver a entrenarla. Esto sirve si la
tarjeta se reinició y perdió la RAM. El puente le carga los pesos guardados, comprueba que llegaron
idénticos y el micro los vuelve a calibrar y cuantizar:
```
python puente_coppelia.py navegar --serie COM4 --baudios 460800 --cargar-pesos "resultados_mcu\<fecha>_entrenar\pesos_entrenados_en_mcu.npz" --datos "<...>\dataset_run" --modelo mcu_int8 --guardar-fotos
```

### 3.5 Opciones principales del puente

| Opción | Uso |
|---|---|
| `--serie COM4` / `--tcp 5005` | Tarjeta por puerto serie, o firmware de PC por TCP |
| `--baudios` | Debe coincidir con ConfigTools (por defecto y probado: 460800) |
| `--modelo` | `pc` (INT8 de Python), `mcu_float` o `mcu_int8` (entrenados en el micro) |
| `--epocas`, `--decaimiento`, `--paciencia`, `--tasa` | Entrenamiento en el micro (tasa_e = tasa · decaimiento^e; se detiene si la pérdida de validación no mejora en `paciencia` épocas) |
| `--n-calibracion` | Imágenes para calibrar la cuantización INT8 (200) |
| `--cargar-pesos` | Recarga en el micro un `pesos_entrenados_en_mcu.npz` |
| `--navegar` | Después de entrenar, navega con la red del micro |
| `--guardar-fotos` | Guarda las fotos de la corrida (para `hacer_hoja.py`) |
| `--resolucion` | Resolución de la cámara si el puente la crea (si la escena ya tiene `CamaraFrontal`, usa la suya) |
| `--flash-total-kb`, `--ram-total-kb` | Memoria total del programa (del Build), para el resumen |
| `--corriente-ma`, `--corriente-reposo-ma`, `--voltaje` | Corriente medida en la tarjeta, para calcular el consumo |

### 3.6 Herramientas extra

```
python f1_desde_csv.py "resultados_mcu\<fecha>_entrenar"        # accuracy y F1 de los 3 modelos del micro
python hacer_hoja.py "resultados_mcu\<fecha>_navegar\fotos\corrida1"   # fotos que vio la CNN
python diagnostico_serie.py COM4 460800                         # bytes crudos del micro (sin el puente)
```

---

## 4. Qué hace el micro en cada ciclo

1. **Pide la foto.** La respuesta trae la imagen, los encoders, el giroscopio y la distancia frontal.
2. **Redimensiona** a 64×64 con Lanczos en punto fijo, renglón por renglón mientras la foto llega.
   El resultado es idéntico al de Pillow.
3. **Normaliza** (p/255) y cuantiza a INT8 con una tabla de 256 valores.
4. **Inferencia** con la CNN INT8.
5. **Probabilidades** con Softmax.
6. **Umbral de confianza:** 0.70. Por debajo, la acción es "incierta" y el robot avanza lento.
7. **Acción:**
   - Los giros y las paradas se confirman con 3 cuadros iguales, y solo si el sensor frontal ve
     algo a ≤ 2 m.
   - Una máquina de estados controla el robot: AVANZAR, GIRO de 90° con el giroscopio, y PARADO
     (reanuda tras 3 cuadros sin obstáculo).
   - En línea recta mantiene el rumbo.
8. **Comandos de motores:** velocidades v y ω.
9. **Cinemática inversa:** ω_R = (v + ωL/2)/r, ω_L = (v − ωL/2)/r, con saturación a 8 rad/s.

Los parámetros del control están en `firmware/comun/config.h`.

### Protocolo
- **Trama:** `A5 5A | tipo | longitud (u32) | datos | CRC-16/CCITT`.
- El micro es el maestro: cada petición lleva un **número de secuencia** que la respuesta repite.
  Así se descartan respuestas viejas o duplicadas.
- Si una trama llega dañada o no llega, el micro la vuelve a pedir con el mismo número y el puente
  reenvía la misma respuesta.

### Memoria del firmware (RAM ≈ 328 KB para la IA)
| Bloque | Tamaño |
|---|---|
| Pesos float32 entrenables | 201.3 KB |
| Memoria de trabajo compartida (entrenamiento / inferencia INT8) | 100.0 KB |
| Preprocesamiento | 16.2 KB |
| Imagen 64×64 y tablas | 8.5 KB |
| Modelo INT8 del micro (sin la capa densa, que vive en la memoria de trabajo) | 2.0 KB |
| Modelo INT8 de Python (Flash) | 50.6 KB |

---

## 5. Resultados obtenidos

| Indicador | Valor |
|---|---|
| Accuracy en prueba (300 imágenes) | 97.67 % red entrenada en el micro (float y INT8), 98.00 % modelo INT8 de Python |
| Entrenamiento en el micro | 23 épocas, 269 s por época (94.3 s de cómputo, 67 ms por paso) |
| Inferencia CNN INT8 | 70.2 ms |
| Preprocesamiento 320×320 → 64×64 | 35.7 ms |
| Captura (foto de 320×320 en gris por UART a 460800) | 2.22 s |
| FPS solo cómputo / lazo completo | 9.4 / 0.43 |
| Programa completo | Flash 134.9 KB, RAM 344.4 KB |
| Navegación | Éxito 100 % (E1–E5), 0 colisiones, 0 decisiones incorrectas, 70.0 s, 14.0 m, error RMS 0.126 m |

La latencia la domina la transmisión por UART. Con fotos de 64×64 la captura baja a ~95 ms
(6 FPS de lazo completo).

---

## 6. Solución de problemas

| Síntoma | Causa y solución |
|---|---|
| `could not open port 'COM4'` | Otro programa tiene el puerto (otra terminal, la terminal serie de S32DS, PuTTY). Ciérralo. |
| "Micro conectado" se repite cada 10 s | El micro no recibe las respuestas: revisa la velocidad y el pin RX. Con `diagnostico_serie.py` verifica que las tramas lleguen con "CRC correcto". |
| "trama dañada - CRC incorrecto" | Velocidad distinta en ConfigTools y en `--baudios`, o un firmware anterior al envío/recepción por registros. |
| Se atora siempre en el mismo bloque o foto | Pérdida de bytes en el micro. Pausa y revisa en *Expressions* `diag_rx_errores`, `diag_rx_vencidas` y `diag_err_stat` (0x80000 = desborde). |
| La simulación no avanza (t = 0) | El micro no completa el primer ciclo. Revisa los contadores anteriores. No presiones Play/Stop. |
| `arpa/inet.h: No such file` al compilar en S32DS | `hal_pc.c` quedó en `comun`. Bórralo de ahí (va en `firmware/pc`). |
| `.sram_bss will not fit in region int_sram` | Faltan las secciones `.ia_dtcm` / `.ia_nocache` en el linker (paso 3.3.5). |
| Se perdió la red al desconectar la tarjeta | La red vive en RAM. Usa `--cargar-pesos` con el `.npz` guardado. |
| Lecturas raras con *Real Time Expressions* | Revisa las variables con el micro pausado y la vista *Expressions* normal. |

Variables de diagnóstico del firmware (vista *Expressions*, con el micro pausado):

| Variable | Qué indica |
|---|---|
| `diag_rx_ok` | Recepciones completas |
| `diag_rx_vencidas` | Recepciones canceladas por tiempo |
| `diag_rx_errores` | Errores de línea |
| `diag_err_stat` | Tipo del último error (en hexadecimal) |
| `diag_err_pos` | Byte de la recepción donde ocurrió el último error |
| `diag_tx_bytes` | Bytes enviados |
| `diag_baud` | Registro BAUD del LPUART (debe valer `0x1C000003` a 460800) |

---

## 7. Resultados que genera

Cada corrida se guarda en `pc/resultados_mcu/<fecha>_<modo>/`:
- `resumen.txt` y `metricas.json`: todos los indicadores.
- Telemetría por cuadro (`*_telemetria.csv`).
- Gráficas: matrices de confusión, métricas por clase, tiempos, trayectoria y curvas de
  entrenamiento.
- En el modo `entrenar`:
  - `entrenamiento_pasos.csv`.
  - Las curvas de entrenamiento (las métricas de cada época van en `metricas.json`).
  - `pesos_entrenados_en_mcu.npz`.
  - `modelo_entrenado_en_mcu.keras`, si TensorFlow está instalado.
- Las fotos de la corrida, con `--guardar-fotos`.
