/*
 * app.c - Lazo principal del microcontrolador.
 *
 * El micro pide trabajo a la PC en cada ciclo y hace lo que le toca:
 *
 *   FOTO     -> 2-3. recibe la foto renglón por renglón, la pasa a gris, la
 *                    redimensiona a 64x64 y la normaliza mientras llega (preproc.c)
 *               4-5. ejecuta la CNN y obtiene las probabilidades
 *               6-7. aplica el umbral de confianza y selecciona la acción (control.c)
 *               8-9. cinemática inversa -> comandos de motores + telemetría
 *   MUESTRA  -> paso de entrenamiento: adelante, retropropagación y actualización
 *               de pesos (entrenamiento.c); responde con la pérdida y los tiempos
 *   ODOM     -> durante un giro solo hacen falta los encoders
 *   COMANDO  -> configurar el robot, iniciar pesos, calibrar, cuantizar a INT8,
 *               elegir el modelo activo o mandar los pesos a la PC
 */
#include <string.h>
#include "app.h"
#include "config.h"
#include "hal.h"
#include "protocolo.h"
#include "preproc.h"
#include "cnn_int8.h"
#include "cnn_modelo.h"
#include "control.h"
#include "entrenamiento.h"
#include "arquitectura.h"
#include "memoria.h"

#define VERSION_FIRMWARE  2

static uint8_t imagen[ARQ_ENT * ARQ_ENT];          /* imagen preprocesada 64x64 (gris) */
static int8_t  entrada_q[ARQ_ENT * ARQ_ENT];       /* la misma, cuantizada a INT8       */
static uint8_t renglones[2][PRE_MAX_ENTRADA * 3];
static int8_t  tabla_pc[256], tabla_mcu[256];       /* normalización de cada modelo      */
static int     modelo = MODELO_PC_INT8;

typedef struct {
    uint8_t  tipo, banderas, canales, etiqueta;
    uint16_t ancho, alto, dist_mm;
    int32_t  enc_izq, enc_der;
    uint32_t id, epoca, n_cmd;
    float    tasa, rumbo;
    uint8_t  cmd[64];
} respuesta_t;

static float leer_f32(const uint8_t *p)
{
    uint32_t u = get_u32(p);
    float f;
    memcpy(&f, &u, 4);
    return f;
}

/* Número de la petición actual. Cada PEDIR_FOTO / PEDIR_ODOM lo lleva y la PC lo
 * repite en su respuesta; así se descartan respuestas atrasadas o duplicadas (por
 * ejemplo, si la PC tardó y el micro volvió a pedir). */
static uint32_t secuencia = 1;

/* Lee y descarta el resto de una trama que no sirve (datos + CRC). */
static void descartar(uint32_t n)
{
    while (n > 0) {
        uint32_t k = n > sizeof(renglones[0]) ? (uint32_t)sizeof(renglones[0]) : n;
        if (prt_leer(renglones[0], k, TIMEOUT_RESPUESTA_US) != 0) return;
        n -= k;
    }
    prt_verificar_crc(TIMEOUT_RESPUESTA_US);
}

static int esperar_ack(void)
{
    uint8_t tipo, estado;
    uint32_t len;
    for (;;) {
        if (prt_recibir_cabecera(&tipo, &len, TIMEOUT_RESPUESTA_US) != 0) return -1;
        if (tipo == MSG_ACK && len == 1) break;
        descartar(len);                       /* respuesta atrasada: se ignora */
    }
    if (prt_leer(&estado, 1, TIMEOUT_RESPUESTA_US) != 0) return -1;
    return prt_verificar_crc(TIMEOUT_RESPUESTA_US);
}

static void saludar(int autoprueba)
{
    uint8_t d[LEN_HOLA];
    memset(d, 0, sizeof(d));
    put_u16(&d[0], VERSION_FIRMWARE);
    d[2] = ARQ_CLASES;
    d[3] = (uint8_t)autoprueba;
    put_u32(&d[4], hal_cpu_mhz());
    put_u32(&d[8], CNN_FLASH_BYTES);
    put_u32(&d[12], MEM_TRABAJO_BYTES);
    put_u32(&d[16], preproc_ram_bytes() + (uint32_t)sizeof(renglones));
    put_u32(&d[20], ARQ_N_PARAMETROS);
    put_f32(&d[24], UMBRAL_CONFIANZA);
    put_u32(&d[28], ent_ram_pesos_bytes());
    put_u32(&d[32], ent_ram_int8_bytes());
    put_u32(&d[36], (uint32_t)(sizeof(imagen) + sizeof(entrada_q) + sizeof(tabla_pc) + sizeof(tabla_mcu)));
    do {
        prt_enviar(MSG_HOLA, d, LEN_HOLA);
    } while (esperar_ack() != 0);
}

/* Recibe la imagen en streaming con doble búfer: mientras llega el renglón r+1
 * se procesa el renglón r. */
static int recibir_pixeles(const respuesta_t *r, uint32_t len, uint32_t *t_proc_ciclos)
{
    const uint32_t bytes_renglon = (uint32_t)r->ancho * r->canales;
    if (len != LEN_CABECERA_FOTO + bytes_renglon * r->alto) return -1;
    if (preproc_comenzar(r->ancho, r->alto, r->canales) != 0) return -1;

    if (hal_uart_rx_iniciar(renglones[0], bytes_renglon) != 0) return -1;
    for (int k = 0; k < r->alto; k++) {
        if (hal_uart_rx_esperar(TIMEOUT_RESPUESTA_US) != 0) return -1;
        uint8_t *listo = renglones[k & 1];
        if (k + 1 < r->alto) {
            hal_uart_rx_iniciar(renglones[(k + 1) & 1], bytes_renglon);
        }
        uint32_t c0 = hal_ciclos();
        prt_acumular_crc(listo, bytes_renglon);
        preproc_renglon(listo);
        *t_proc_ciclos += hal_ciclos() - c0;
    }
    if (prt_verificar_crc(TIMEOUT_RESPUESTA_US) != 0) return -1;

    uint32_t c0 = hal_ciclos();
    int ok = preproc_terminar(imagen);
    *t_proc_ciclos += hal_ciclos() - c0;
    return ok;
}

static int recibir_respuesta(respuesta_t *r, uint32_t *t_proc_ciclos)
{
    uint8_t c[LEN_CABECERA_FOTO];
    uint32_t len;
    *t_proc_ciclos = 0;

    for (;;) {    /* se ignoran las tramas que no responden a la petición actual */
        if (prt_recibir_cabecera(&r->tipo, &len, TIMEOUT_RESPUESTA_US) != 0) return -1;

        switch (r->tipo) {
        case MSG_FOTO:
        case MSG_MUESTRA:
            if (len < LEN_CABECERA_FOTO) { descartar(len); continue; }
            if (prt_leer(c, LEN_CABECERA_FOTO, TIMEOUT_RESPUESTA_US) != 0) return -1;
            r->id = get_u32(&c[16]);
            if (r->id != secuencia) { descartar(len - LEN_CABECERA_FOTO); continue; }
            r->banderas = c[0];
            r->canales  = c[1];
            r->ancho    = get_u16(&c[2]);
            r->alto     = get_u16(&c[4]);
            r->rumbo    = leer_f32(&c[20]);                /* giroscopio (IMU) */
            if (r->tipo == MSG_FOTO) {
                r->dist_mm = get_u16(&c[6]);               /* sensor de distancia frontal */
                r->enc_izq = (int32_t)get_u32(&c[8]);
                r->enc_der = (int32_t)get_u32(&c[12]);
            } else {
                uint32_t u = get_u32(&c[8]);
                r->etiqueta = c[6];
                memcpy(&r->tasa, &u, 4);
                r->epoca = get_u32(&c[12]);
            }
            return recibir_pixeles(r, len, t_proc_ciclos);

        case MSG_ODOM:
            if (len != LEN_ODOM) { descartar(len); continue; }
            if (prt_leer(c, LEN_ODOM, TIMEOUT_RESPUESTA_US) != 0) return -1;
            if (prt_verificar_crc(TIMEOUT_RESPUESTA_US) != 0) return -1;
            r->id = get_u32(&c[12]);
            if (r->id != secuencia) continue;
            r->banderas = c[0];
            r->enc_izq  = (int32_t)get_u32(&c[4]);
            r->enc_der  = (int32_t)get_u32(&c[8]);
            r->rumbo    = leer_f32(&c[16]);
            return 0;

        case MSG_COMANDO:
            /* [cmd][0][0][0][secuencia u32][datos...] */
            if (len > sizeof(r->cmd) && len >= 12) {
                /* Comando grande: solo CARGAR_PESOS ([...][u32 bloque][floats]). Los
                 * floats se copian directo a su lugar, sin búfer intermedio. */
                if (prt_leer(r->cmd, 12, TIMEOUT_RESPUESTA_US) != 0) return -1;
                uint32_t n_floats = 0;
                float *destino = (r->cmd[0] == CMD_CARGAR_PESOS)
                                 ? ent_bloque_escribir((int)get_u32(&r->cmd[8]), &n_floats) : 0;
                if (get_u32(&r->cmd[4]) != secuencia || destino == 0 || len - 12 != 4u * n_floats) {
                    descartar(len - 12);
                    continue;
                }
                if (prt_leer((uint8_t *)destino, len - 12, TIMEOUT_RESPUESTA_US) != 0) return -1;
                if (prt_verificar_crc(TIMEOUT_RESPUESTA_US) != 0) return -1;   /* la PC lo reenvía */
                r->n_cmd = 12;
                return 0;
            }
            if (len < 8) { descartar(len); continue; }
            if (prt_leer(r->cmd, len, TIMEOUT_RESPUESTA_US) != 0) return -1;
            if (prt_verificar_crc(TIMEOUT_RESPUESTA_US) != 0) return -1;
            if (get_u32(&r->cmd[4]) != secuencia) continue;
            r->n_cmd = len;
            return 0;

        default:                       /* p. ej. un ACK atrasado */
            descartar(len);
            continue;
        }
    }
}

/* ---------------- 4-5. Inferencia con el modelo activo ---------------- */
static void inferir(float *prob)
{
    int8_t logits[ARQ_CLASES];
    switch (modelo) {
    case MODELO_MCU_FLOAT:
        ent_inferir(imagen, prob);
        break;
    case MODELO_MCU_INT8:
        ent_preparar_int8();
        preproc_cuantizar(imagen, tabla_mcu, entrada_q);
        cnn_inferir(ent_capas_int8(), 6, entrada_q, logits, ARQ_CLASES);
        cnn_probabilidades(logits, ARQ_CLASES, ent_salida_escala(), ent_salida_zp(), prob);
        break;
    default:
        preproc_cuantizar(imagen, tabla_pc, entrada_q);
        cnn_inferir(cnn_capas, CNN_N_CAPAS, entrada_q, logits, CNN_N_CLASES);
        cnn_probabilidades(logits, CNN_N_CLASES, CNN_SALIDA_ESCALA, CNN_SALIDA_ZP, prob);
        break;
    }
#ifdef PRUEBA_ORACULO
    /* SOLO PARA PROBAR EL PUENTE SIN UN MODELO REAL: el puente pinta la imagen con
     * el valor 25 + 50 * clase y aquí se usa como si fuera la salida de la CNN. */
    int clase = imagen[0] / 50;
    for (int k = 0; k < 4; k++) prob[k] = (k == clase) ? 0.97f : 0.01f;
#endif
}

/* ---------------- Comandos ---------------- */

static void ejecutar_comando(const respuesta_t *r)
{
    const uint8_t *c = r->cmd;
    uint8_t cab[LEN_RESULTADO_CAB], extra[16];
    uint32_t n_extra = 0, c0 = hal_ciclos();
    uint8_t estado = 0;

    switch (c[0]) {
    case CMD_CONFIG_ROBOT:
        if (r->n_cmd < 20) { estado = 2; break; }
        control_configurar(leer_f32(&c[8]), leer_f32(&c[12]), leer_f32(&c[16]));
        break;
    case CMD_INICIAR_PESOS:
        ent_iniciar_pesos(r->n_cmd >= 12 ? get_u32(&c[8]) : SEMILLA_PESOS);
        break;
    case CMD_USAR_MODELO: {
        int m = r->n_cmd >= 9 ? c[8] : MODELO_PC_INT8;
        if ((m == MODELO_MCU_FLOAT && !ent_hay_pesos()) || (m == MODELO_MCU_INT8 && !ent_hay_int8()) ||
            m > MODELO_MCU_INT8) {
            estado = 1;                                  /* ese modelo no existe todavía */
        } else {
            modelo = m;
        }
        break;
    }
    case CMD_CALIBRAR:
        if (!ent_hay_pesos()) { estado = 1; break; }
        ent_calibrar_iniciar();
        break;
    case CMD_CUANTIZAR:
        if (ent_cuantizar() != 0) { estado = 1; break; }
        modelo = MODELO_MCU_INT8;
        put_f32(&extra[0], ent_salida_escala());
        put_u32(&extra[4], (uint32_t)ent_salida_zp());
        put_u32(&extra[8], ent_calibrar_muestras());
        put_u32(&extra[12], ent_ram_int8_bytes() + ARQ_N_W3);   /* tamaño total del modelo INT8 */
        n_extra = 16;
        break;
    case CMD_SUBIR_PESOS:
        if (!ent_hay_pesos()) { estado = 1; break; }
        break;
    case CMD_CARGAR_PESOS: {
        /* Bloque grande: ya se copió al recibirlo (n_cmd = 12).
         * Bloque chico (cabe en r->cmd): se copia aquí. */
        if (r->n_cmd < 12) { estado = 2; break; }
        if (r->n_cmd > 12) {
            uint32_t n_floats = 0;
            float *destino = ent_bloque_escribir((int)get_u32(&c[8]), &n_floats);
            if (destino == 0 || r->n_cmd - 12 != 4u * n_floats) { estado = 2; break; }
            memcpy(destino, &c[12], 4u * n_floats);
        }
        ent_pesos_cargados();
        if (modelo != MODELO_PC_INT8) {
            modelo = MODELO_MCU_FLOAT;
        }
        break;
    }
    default:
        estado = 2;
        break;
    }

    cab[0] = c[0];
    cab[1] = estado;
    cab[2] = (uint8_t)modelo;
    cab[3] = 0;
    put_u32(&cab[4], hal_us_desde(c0, hal_ciclos()));

    if (c[0] == CMD_SUBIR_PESOS && estado == 0) {
        /* Todos los pesos float en el orden w1, b1, w2, b2, w3, b3, w4, b4 */
        prt_enviar_inicio(MSG_RESULTADO, LEN_RESULTADO_CAB + 4u * ARQ_N_PARAMETROS);
        prt_enviar_parte(cab, LEN_RESULTADO_CAB);
        for (int i = 0; i < ent_n_bloques(); i++) {
            uint32_t n;
            const float *p = ent_bloque(i, &n);
            prt_enviar_parte((const uint8_t *)p, 4u * n);
        }
        prt_enviar_fin();
    } else {
        prt_enviar_inicio(MSG_RESULTADO, LEN_RESULTADO_CAB + n_extra);
        prt_enviar_parte(cab, LEN_RESULTADO_CAB);
        prt_enviar_parte(extra, n_extra);
        prt_enviar_fin();
    }
    esperar_ack();
}

/* ---------------- Paso de entrenamiento ---------------- */
static void entrenar(const respuesta_t *r, uint32_t t_captura, uint32_t t_preproc, uint32_t t_periodo)
{
    float prob[ARQ_CLASES];
    int pred = 0;
    if (!ent_hay_pesos()) {
        ent_iniciar_pesos(SEMILLA_PESOS);
    }
    uint32_t c0 = hal_ciclos();
    float perdida = ent_paso(imagen, r->etiqueta < ARQ_CLASES ? r->etiqueta : 0, r->tasa, prob, &pred);
    uint32_t t_paso = hal_us_desde(c0, hal_ciclos());
    if (modelo == MODELO_MCU_INT8) {
        modelo = MODELO_MCU_FLOAT;             /* el INT8 quedó viejo al cambiar los pesos */
    }

    uint8_t d[LEN_ENTRENO];
    memset(d, 0, sizeof(d));
    put_u32(&d[0], r->id);
    d[4] = r->etiqueta;
    d[5] = (uint8_t)pred;
    put_f32(&d[8], perdida);
    for (int k = 0; k < ARQ_CLASES; k++) put_f32(&d[12 + 4 * k], prob[k]);
    put_u32(&d[28], t_captura);
    put_u32(&d[32], t_preproc);
    put_u32(&d[36], t_paso);
    put_u32(&d[40], r->epoca);
    put_u32(&d[44], t_periodo);
    prt_enviar(MSG_ENTRENO, d, LEN_ENTRENO);
    esperar_ack();
}

void app_ejecutar(void)
{
    respuesta_t r;
    control_salida_t s;
    float prob[ARQ_CLASES];
    uint32_t inicio_previo = 0;
    int primer_ciclo = 1;

    preproc_crear_tabla(CNN_ENTRADA_ESCALA, CNN_ENTRADA_ZP, tabla_pc);
    preproc_crear_tabla(1.0f / 255.0f, -128, tabla_mcu);      /* entrada del INT8 del micro */
    control_reiniciar(0, 0);
    saludar(cnn_autoprueba());

    for (;;) {
        uint32_t c_inicio = hal_ciclos();
        uint32_t ciclos_pre = 0;

        /* 1) Pedir trabajo: una foto (o solo encoders durante un giro) */
        uint8_t pedido[4];
        put_u32(pedido, secuencia);
        prt_enviar(control_necesita_imagen() ? MSG_PEDIR_FOTO : MSG_PEDIR_ODOM, pedido, 4);
        memset(&r, 0, sizeof(r));
        int ok = recibir_respuesta(&r, &ciclos_pre);
        uint32_t c_recibido = hal_ciclos();
        if (ok != 0) {
            continue;                    /* trama perdida o dañada: volver a pedir */
        }
        secuencia++;                     /* esta petición ya quedó atendida */
        uint32_t t_preproc = ciclos_pre / hal_ciclos_por_us();
        uint32_t t_captura = hal_us_desde(c_inicio, c_recibido) - t_preproc;
        uint32_t t_periodo = primer_ciclo ? 0 : hal_us_desde(inicio_previo, c_inicio);
        inicio_previo = c_inicio;
        primer_ciclo = 0;

        if (r.tipo == MSG_COMANDO) {
            ejecutar_comando(&r);
            continue;
        }
        if (r.tipo == MSG_MUESTRA) {
            entrenar(&r, t_captura, t_preproc, t_periodo);
            continue;
        }

        /* ---- FOTO u ODOM: navegación o evaluación ---- */
        int con_imagen = (r.tipo == MSG_FOTO);
        if (r.banderas & BANDERA_REINICIO) {
            control_reiniciar(r.enc_izq, r.enc_der);
        }
        memset(prob, 0, sizeof(prob));

        uint32_t c0 = hal_ciclos();
        if (con_imagen) {
            inferir(prob);                                   /* 4-5 */
        }
        uint32_t c1 = hal_ciclos();

        float w_izq = 0.0f, w_der = 0.0f;
        if (r.banderas & BANDERA_EVALUACION) {
            memset(&s, 0, sizeof(s));
            s.accion = ACC_ESPERANDO;
        } else {
            float dist = (!con_imagen || r.dist_mm == 0xFFFFu) ? -1.0f : r.dist_mm / 1000.0f;
            control_paso(con_imagen, prob, r.enc_izq, r.enc_der, dist, r.rumbo, &s);   /* 6-7 */
            cinematica_inversa(s.v, s.w, &w_izq, &w_der);               /* 9   */
        }
        uint32_t c2 = hal_ciclos();

        uint8_t clase = 255;
        float conf = 0.0f;
        if (con_imagen) {
            for (int k = 0; k < ARQ_CLASES; k++) {
                if (prob[k] > conf) { conf = prob[k]; clase = (uint8_t)k; }
            }
        }

        /* 8) Comando de motores + telemetría */
        uint8_t d[LEN_MOTORES];
        memset(d, 0, sizeof(d));
        put_f32(&d[0], w_izq);
        put_f32(&d[4], w_der);
        put_u32(&d[8], r.id);
        d[12] = clase;
        d[13] = s.accion;
        d[14] = s.estado;
        d[15] = s.decision;
        for (int k = 0; k < 4; k++) put_f32(&d[16 + 4 * k], prob[k]);
        put_f32(&d[32], conf);
        put_f32(&d[36], s.v);
        put_f32(&d[40], s.w);
        put_u32(&d[44], t_captura);
        put_u32(&d[48], t_preproc);
        put_u32(&d[52], hal_us_desde(c0, c1));
        put_u32(&d[56], hal_us_desde(c1, c2));
        put_u32(&d[60], hal_us_desde(c_inicio, c2));
        put_u32(&d[64], t_periodo);
        d[68] = (uint8_t)con_imagen;
        d[69] = (uint8_t)modelo;
        prt_enviar(MSG_MOTORES, d, LEN_MOTORES);
        esperar_ack();
    }
}
