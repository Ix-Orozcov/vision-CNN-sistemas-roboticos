/*
 * app.h - Lazo principal: pedir foto -> preprocesar -> inferir -> decidir -> motores.
 */
#ifndef APP_H
#define APP_H

/* No regresa. Llamar después de inicializar el hardware (hal_iniciar). */
void app_ejecutar(void);

#endif
