/*
 * arquitectura.h - Dimensiones de la CNN (la misma que se entrenó en la PC):
 *
 *   Imagen 64x64x1 -> Conv2D 8 (3x3) + ReLU -> MaxPool 2x2
 *                  -> Conv2D 16 (3x3) + ReLU -> MaxPool 2x2
 *                  -> Flatten (3136) -> Dense 16 + ReLU -> Dense 4 -> Softmax
 */
#ifndef ARQUITECTURA_H
#define ARQUITECTURA_H

#define ARQ_ENT        64                                   /* entrada 64 x 64 x 1 */
#define ARQ_K          3                                    /* kernel 3 x 3        */
#define ARQ_C1         8
#define ARQ_C1_SAL     (ARQ_ENT - ARQ_K + 1)                /* 62 */
#define ARQ_P1         (ARQ_C1_SAL / 2)                     /* 31 */
#define ARQ_C2         16
#define ARQ_C2_SAL     (ARQ_P1 - ARQ_K + 1)                 /* 29 */
#define ARQ_P2         (ARQ_C2_SAL / 2)                     /* 14 */
#define ARQ_PLANO      (ARQ_P2 * ARQ_P2 * ARQ_C2)           /* 3136 */
#define ARQ_D1         16
#define ARQ_CLASES     4

#define ARQ_N_W1       (ARQ_C1 * ARQ_K * ARQ_K)
#define ARQ_N_W2       (ARQ_C2 * ARQ_K * ARQ_K * ARQ_C1)
#define ARQ_N_W3       (ARQ_D1 * ARQ_PLANO)
#define ARQ_N_W4       (ARQ_CLASES * ARQ_D1)
#define ARQ_N_PARAMETROS (ARQ_N_W1 + ARQ_C1 + ARQ_N_W2 + ARQ_C2 + ARQ_N_W3 + ARQ_D1 + \
                          ARQ_N_W4 + ARQ_CLASES)            /* 51 508 */

/* Búferes de activaciones de la inferencia INT8 (ping-pong) */
#define ARQ_BUF_A_BYTES (ARQ_C1_SAL * ARQ_C1_SAL * ARQ_C1)  /* salida de conv1: 30 752 */
#define ARQ_BUF_B_BYTES (ARQ_P1 * ARQ_P1 * ARQ_C1)          /* salida de pool1:  7 688 */

#endif
