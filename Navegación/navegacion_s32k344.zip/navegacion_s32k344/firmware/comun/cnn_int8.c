/*
 * cnn_int8.c - Inferencia INT8 (ver cnn_int8.h).
 */
#include <math.h>
#include <stddef.h>
#include "cnn_int8.h"
#include "cnn_modelo.h"
#include "cnn_vectores.h"
#include "arquitectura.h"
#include "memoria.h"

/* Búferes ping-pong dentro de la memoria de trabajo compartida */
#define BUF_A ((int8_t *)memoria_trabajo)
#define BUF_B ((int8_t *)memoria_trabajo + ARQ_BUF_A_BYTES)

_Static_assert(ARQ_BUF_A_BYTES + ARQ_BUF_B_BYTES <= MEM_TRABAJO_BYTES, "memoria de trabajo insuficiente");
_Static_assert(CNN_BUF_A_BYTES <= ARQ_BUF_A_BYTES && CNN_BUF_B_BYTES <= ARQ_BUF_B_BYTES,
               "el modelo de la PC no coincide con arquitectura.h");

uint32_t cnn_ram_bytes(void)
{
    return ARQ_BUF_A_BYTES + ARQ_BUF_B_BYTES;
}

/* ---------- Aritmética de punto fijo idéntica a TensorFlow Lite ---------- */

static inline int32_t srdhm(int32_t a, int32_t b)
{
    /* SaturatingRoundingDoublingHighMul */
    if (a == INT32_MIN && b == INT32_MIN) {
        return INT32_MAX;
    }
    int64_t ab = (int64_t)a * (int64_t)b;
    int32_t nudge = (ab >= 0) ? (1 << 30) : (1 - (1 << 30));
    return (int32_t)((ab + nudge) / (1LL << 31));
}

static inline int32_t rdbpot(int32_t x, int exponente)
{
    /* RoundingDivideByPOT */
    int32_t mascara = (int32_t)((1LL << exponente) - 1);
    int32_t resto = x & mascara;
    int32_t umbral = (mascara >> 1) + ((x < 0) ? 1 : 0);
    return (x >> exponente) + ((resto > umbral) ? 1 : 0);
}

static inline int32_t reescalar(int32_t acc, int32_t mult, int desp)
{
    /* MultiplyByQuantizedMultiplier */
    int izq = desp > 0 ? desp : 0;
    int der = desp > 0 ? 0 : -desp;
    return rdbpot(srdhm((int32_t)((uint32_t)acc << izq), mult), der);
}

static inline int8_t saturar(int32_t v, int32_t vmin, int32_t vmax)
{
    if (v < vmin) v = vmin;
    if (v > vmax) v = vmax;
    return (int8_t)v;
}

/* ---------- Capas ---------- */

static void conv2d(const capa_t *c, const int8_t *x, int8_t *y)
{
    const int K = c->k, IW = c->in_w, IC = c->in_c;
    const int fila_in = IW * IC;
    const int n_kernel = K * K * IC;

    for (int oy = 0; oy < c->out_h; oy++) {
        for (int ox = 0; ox < c->out_w; ox++) {
            const int8_t *base = x + oy * fila_in + ox * IC;
            int8_t *salida = y + (oy * c->out_w + ox) * c->out_c;
            for (int oc = 0; oc < c->out_c; oc++) {
                const int8_t *w = c->w + oc * n_kernel;
                int32_t acc = c->b[oc];
                for (int ky = 0; ky < K; ky++) {
                    const int8_t *px = base + ky * fila_in;
                    const int8_t *pw = w + ky * K * IC;
                    for (int i = 0; i < K * IC; i++) {
                        acc += (int32_t)px[i] * (int32_t)pw[i];
                    }
                }
                int q = c->por_canal ? oc : 0;
                acc = reescalar(acc, c->mult[q], c->desp[q]) + c->out_zp;
                salida[oc] = saturar(acc, c->act_min, c->act_max);
            }
        }
    }
}

static void maxpool(const capa_t *c, const int8_t *x, int8_t *y)
{
    const int K = c->k, IW = c->in_w, C = c->in_c;
    for (int oy = 0; oy < c->out_h; oy++) {
        for (int ox = 0; ox < c->out_w; ox++) {
            for (int ch = 0; ch < C; ch++) {
                int32_t m = -128;
                for (int ky = 0; ky < K; ky++) {
                    for (int kx = 0; kx < K; kx++) {
                        int32_t v = x[((oy * K + ky) * IW + (ox * K + kx)) * C + ch];
                        if (v > m) m = v;
                    }
                }
                y[(oy * c->out_w + ox) * C + ch] = saturar(m, c->act_min, c->act_max);
            }
        }
    }
}

static void densa(const capa_t *c, const int8_t *x, int8_t *y)
{
    const int N = c->in_c;
    for (int o = 0; o < c->out_c; o++) {
        const int8_t *w = c->w + o * N;
        int32_t acc = c->b[o];
        for (int i = 0; i < N; i++) {
            acc += (int32_t)x[i] * (int32_t)w[i];
        }
        int q = c->por_canal ? o : 0;
        acc = reescalar(acc, c->mult[q], c->desp[q]) + c->out_zp;
        y[o] = saturar(acc, c->act_min, c->act_max);
    }
}

int cnn_inferir(const capa_t *capas, int n_capas, const int8_t *entrada, int8_t *logits, int n_clases)
{
    const int8_t *x = entrada;
    for (int i = 0; i < n_capas; i++) {
        const capa_t *c = &capas[i];
        int8_t *y = (i % 2 == 0) ? BUF_A : BUF_B;
        if ((uint32_t)c->out_h * c->out_w * c->out_c > (uint32_t)((i % 2 == 0) ? ARQ_BUF_A_BYTES : ARQ_BUF_B_BYTES)) {
            return -1;
        }
        switch (c->tipo) {
        case CAPA_CONV:    conv2d(c, x, y);  break;
        case CAPA_MAXPOOL: maxpool(c, x, y); break;
        case CAPA_FC:      densa(c, x, y);   break;
        default:           return -1;
        }
        x = y;
    }
    for (int k = 0; k < n_clases; k++) {
        logits[k] = x[k];
    }
    return 0;
}

void cnn_probabilidades(const int8_t *logits, int n, float escala, int32_t zp, float *prob)
{
    float zmax = -1e30f, suma = 0.0f;
    for (int k = 0; k < n; k++) {
        prob[k] = ((int32_t)logits[k] - zp) * escala;
        if (prob[k] > zmax) zmax = prob[k];
    }
    for (int k = 0; k < n; k++) {
        prob[k] = expf(prob[k] - zmax);
        suma += prob[k];
    }
    for (int k = 0; k < n; k++) {
        prob[k] /= suma;
    }
}

int cnn_autoprueba(void)
{
#if CNN_N_VECTORES > 0
    int8_t logits[CNN_N_CLASES];
    for (int v = 0; v < CNN_N_VECTORES; v++) {
        cnn_inferir(cnn_capas, CNN_N_CAPAS, cnn_vec_entrada[v], logits, CNN_N_CLASES);
        for (int k = 0; k < CNN_N_CLASES; k++) {
            if (logits[k] != cnn_vec_logits[v][k]) {
                return 0;
            }
        }
    }
    return 1;
#else
    return 2;
#endif
}
