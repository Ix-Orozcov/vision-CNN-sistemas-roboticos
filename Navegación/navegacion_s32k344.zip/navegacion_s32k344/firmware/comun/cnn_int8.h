/*
 * cnn_int8.h - Motor de inferencia INT8 para la CNN de navegación.
 *
 * Reproduce la aritmética de los kernels de referencia de TensorFlow Lite
 * (cuantización por canal, re-escalado en punto fijo), sin depender de TFLite Micro.
 * Ejecuta dos modelos con la misma arquitectura:
 *   - el entrenado en la PC (firmware/modelo/cnn_modelo.c, generado por el exportador)
 *   - el entrenado y cuantizado en el propio micro (entrenamiento.c)
 */
#ifndef CNN_INT8_H
#define CNN_INT8_H

#include <stdint.h>

typedef enum {
    CAPA_CONV    = 0,   /* Conv2D 'valid', paso 1, kernel k x k (+ ReLU)   */
    CAPA_MAXPOOL = 1,   /* MaxPooling k x k, paso k                         */
    CAPA_FC      = 2    /* Dense / Fully connected (+ ReLU opcional)        */
} tipo_capa_t;

typedef struct {
    uint8_t  tipo;               /* tipo_capa_t                                     */
    uint8_t  k;                  /* tamaño del kernel o de la ventana de pooling    */
    uint8_t  por_canal;          /* 1: mult/desp por canal de salida; 0: uno solo   */
    uint8_t  reservado;
    uint16_t in_h, in_w, in_c;   /* dimensiones de entrada (FC: 1 x 1 x N)          */
    uint16_t out_h, out_w, out_c;
    int32_t  out_zp;             /* punto cero de la salida                         */
    int32_t  act_min, act_max;   /* recorte de activación (ReLU fusionada)          */
    const int8_t  *w;            /* pesos: conv OHWI, fc [salidas][entradas]        */
    const int32_t *b;            /* sesgo ya corregido: b - zp_entrada * suma(w)    */
    const int32_t *mult;         /* multiplicador en punto fijo Q31                 */
    const int8_t  *desp;         /* desplazamiento (exponente) del multiplicador   */
} capa_t;

/* Ejecuta una red INT8 descrita por 'capas'. Devuelve 0 si todo salió bien. */
int  cnn_inferir(const capa_t *capas, int n_capas, const int8_t *entrada,
                 int8_t *logits, int n_clases);

/* Softmax en float sobre los logits cuantizados. */
void cnn_probabilidades(const int8_t *logits, int n, float escala, int32_t zp, float *prob);

/* Prueba al arranque del modelo de la PC con los vectores generados en la PC.
 * Devuelve 1 si coincide bit a bit, 0 si falla, 2 si no hay vectores. */
int  cnn_autoprueba(void);

/* Memoria usada por los búferes de activaciones (bytes, dentro de memoria_trabajo). */
uint32_t cnn_ram_bytes(void);

#endif
