/*
 * config.h - Parámetros ajustables del sistema de navegación.
 *
 * Todo lo que normalmente querrás modificar está aquí: umbral de confianza,
 * velocidades, geometría del robot y tamaños máximos de imagen.
 */
#ifndef CONFIG_H
#define CONFIG_H

/* ---------------- Percepción ---------------- */
#define UMBRAL_CONFIANZA     0.70f  /* probabilidad mínima para aceptar una clase      */
#define N_VOTOS              3      /* cuadros seguidos iguales para confirmar acción  */
#define N_LIBRE              3      /* cuadros sin obstáculo para reanudar la marcha   */
#define D_DECISION           2.00f  /* solo se decide si hay algo delante a <= 2 m     */

/* ---------------- Movimiento (m/s, rad/s) ---------------- */
#define V_CRUCERO            0.25f  /* velocidad lineal con señal "avanzar"            */
#define V_LENTO              0.10f  /* velocidad con baja confianza o acción en espera */
#define W_GIRO_MAX           1.00f  /* velocidad angular máxima al girar               */
#define K_GIRO               1.50f  /* ganancia proporcional del giro                  */
#define TOL_GIRO             0.03f  /* error de orientación aceptado al terminar giro  */
#define DIST_ENFRIAMIENTO    0.80f  /* metros recorridos tras un giro antes de otro    */
#define K_RUMBO              1.50f  /* ganancia para mantener el rumbo en línea recta  */
#define W_RUMBO_MAX          0.30f  /* corrección angular máxima al ir derecho (rad/s) */

/* ---------------- Robot diferencial ----------------
 * Valores por defecto. Con el Pioneer P3DX el puente los mide en CoppeliaSim y se
 * los manda al micro al inicio (comando CONFIG_ROBOT), así siempre coinciden. */
#define R_RUEDA              0.0975f /* radio de rueda (m)                             */
#define L_EJE                0.331f  /* distancia entre ruedas (m)                     */
#define W_RUEDA_MAX          8.00f   /* velocidad máxima de cada motor (rad/s)         */
#define TICKS_POR_VUELTA     2048   /* resolución de los encoders                      */

/* ---------------- Imagen ---------------- */
#define PRE_MAX_ENTRADA      320    /* ancho/alto máximo que puede llegar de la cámara */
#define PRE_SALIDA           64     /* tamaño de entrada de la CNN                     */

/* ---------------- Entrenamiento en el micro ----------------
 * La tasa de aprendizaje y la época las manda la PC con cada muestra. */
#define SEMILLA_PESOS        42u

/* ---------------- Comunicación ---------------- */
#ifndef TIMEOUT_RESPUESTA_US
#define TIMEOUT_RESPUESTA_US 10000000u /* espera máxima de una respuesta del puente   */
#endif

#endif
