/*
 * control.c - Umbral de confianza, votación, máquina de estados, odometría y
 *             cinemática inversa del robot diferencial.
 *
 * Estados:
 *   AVANZAR: mira cada cuadro. Con "avanzar" va a V_CRUCERO; si la confianza no
 *            alcanza el umbral o una acción aún no se confirma, va a V_LENTO.
 *            Una acción se confirma con N_VOTOS cuadros seguidos iguales.
 *            En línea recta mantiene el rumbo con la odometría (K_RUMBO).
 *   GIRO:    gira 90° en su lugar usando la orientación de la odometría.
 *   Las decisiones solo se toman si el sensor de distancia frontal detecta algo a
 *   menos de D_DECISION (la distancia con la que se entrenó la CNN).
 *   PARADO:  detenido frente a un obstáculo; reanuda tras N_LIBRE cuadros
 *            consecutivos sin "obstaculo".
 */
#include <math.h>
#include "control.h"
#include "config.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* Geometría del robot: valores de config.h hasta que el puente mande la del robot real */
static float   r_rueda = R_RUEDA, l_eje = L_EJE, w_rueda_max = W_RUEDA_MAX;

static int     estado;
static int     candidato_previo, votos, libres;
static float   theta_objetivo, theta_rumbo, dist_desde_giro;
static float   x_odo, y_odo, th_odo;
static int32_t enc_izq_prev, enc_der_prev;
static int     imu_listo;            /* ya se tomó la referencia del giroscopio */
static float   imu_cero;             /* lectura del giroscopio al iniciar la corrida */

static float envolver(float a)
{
    while (a > (float)M_PI)  a -= 2.0f * (float)M_PI;
    while (a < -(float)M_PI) a += 2.0f * (float)M_PI;
    return a;
}

static float saturarf(float v, float lim)
{
    if (v > lim)  return lim;
    if (v < -lim) return -lim;
    return v;
}

void control_configurar(float radio, float eje, float w_max)
{
    if (radio > 0.0f) r_rueda = radio;
    if (eje > 0.0f)   l_eje = eje;
    if (w_max > 0.0f) w_rueda_max = w_max;
}

void control_reiniciar(int32_t enc_izq, int32_t enc_der)
{
    estado = EST_AVANZAR;
    candidato_previo = -1;
    votos = 0;
    libres = 0;
    dist_desde_giro = DIST_ENFRIAMIENTO;     /* se permite girar desde el inicio */
    x_odo = y_odo = th_odo = 0.0f;
    theta_rumbo = 0.0f;                      /* rumbo a mantener en línea recta */
    imu_listo = 0;
    enc_izq_prev = enc_izq;
    enc_der_prev = enc_der;
}

int control_necesita_imagen(void)
{
    return estado != EST_GIRO;   /* durante el giro basta con la odometría */
}

void control_pose(float *x, float *y, float *theta)
{
    *x = x_odo;
    *y = y_odo;
    *theta = th_odo;
}

/* Odometría: la distancia sale de los encoders. La orientación sale del giroscopio
 * (IMU) si está disponible, porque los encoders no ven los giros por patinaje (p. ej.
 * cuando la rueda loca del Pioneer se reacomoda al arrancar). Sin IMU, de los encoders. */
static void actualizar_odometria(int32_t enc_izq, int32_t enc_der, float rumbo_imu)
{
    const float rad_por_tick = 2.0f * (float)M_PI / TICKS_POR_VUELTA;
    float d_izq = (float)(enc_izq - enc_izq_prev) * rad_por_tick * r_rueda;
    float d_der = (float)(enc_der - enc_der_prev) * rad_por_tick * r_rueda;
    enc_izq_prev = enc_izq;
    enc_der_prev = enc_der;

    float ds = 0.5f * (d_izq + d_der);
    float dth = (d_der - d_izq) / l_eje;
    if (!isnan(rumbo_imu)) {
        if (!imu_listo) {
            imu_cero = rumbo_imu - th_odo;
            imu_listo = 1;
        }
        dth = envolver(envolver(rumbo_imu - imu_cero) - th_odo);
    }
    x_odo += ds * cosf(th_odo + 0.5f * dth);
    y_odo += ds * sinf(th_odo + 0.5f * dth);
    th_odo = envolver(th_odo + dth);
    dist_desde_giro += fabsf(ds);
}

/* Mantener el rumbo en línea recta: el robot real (con física) se tuerce un poco al
 * arrancar, frenar o después de girar; con la orientación medida se corrige el desvío. */
static float corregir_rumbo(void)
{
    return saturarf(K_RUMBO * envolver(theta_rumbo - th_odo), W_RUMBO_MAX);
}

static int accion_de_clase(int clase)
{
    switch (clase) {
    case CLASE_AVANZAR:   return ACC_AVANZAR;
    case CLASE_IZQUIERDA: return ACC_IZQUIERDA;
    case CLASE_DERECHA:   return ACC_DERECHA;
    default:              return ACC_DETENER;
    }
}

void control_paso(int con_imagen, const float *prob, int32_t enc_izq, int32_t enc_der,
                  float dist_frontal, float rumbo_imu, control_salida_t *s)
{
    /* Sensor de distancia frontal (como los sonares del Pioneer): la CNN solo se
     * entrenó con señales a ~1.2-1.9 m. Si no hay nada delante a esa distancia, lo
     * que "ve" la red no es confiable y no se toma ninguna decisión. dist < 0: sin sensor. */
    const int lejos = (dist_frontal >= 0.0f && dist_frontal > D_DECISION);

    int clase = CLASE_NINGUNA;
    float conf = 0.0f;

    actualizar_odometria(enc_izq, enc_der, rumbo_imu);
    s->decision = DEC_NINGUNA;

    if (con_imagen) {
        for (int k = 0; k < 4; k++) {
            if (prob[k] > conf) {
                conf = prob[k];
                clase = k;
            }
        }
    }

    switch (estado) {
    case EST_AVANZAR: {
        if (!con_imagen) {               /* no debería ocurrir; avanzar con cautela */
            s->v = V_LENTO;
            s->w = corregir_rumbo();
            s->accion = ACC_INCIERTO;
            break;
        }
        if (lejos) {                     /* nada delante a distancia de decisión */
            s->v = V_CRUCERO;
            s->w = corregir_rumbo();
            s->accion = ACC_SIN_OBJETO;
            votos = 0;
            candidato_previo = -1;
            break;
        }
        /* Umbral de confianza */
        int candidato = (conf >= UMBRAL_CONFIANZA) ? accion_de_clase(clase) : ACC_INCIERTO;

        /* Votación: la misma acción en cuadros consecutivos */
        votos = (candidato == candidato_previo) ? votos + 1 : 1;
        candidato_previo = candidato;

        s->w = corregir_rumbo();
        s->accion = (uint8_t)candidato;
        if (candidato == ACC_AVANZAR) {
            s->v = V_CRUCERO;
        } else if (candidato == ACC_INCIERTO) {
            s->v = V_LENTO;
        } else if (votos >= N_VOTOS &&
                   (candidato == ACC_DETENER || dist_desde_giro >= DIST_ENFRIAMIENTO)) {
            if (candidato == ACC_DETENER) {
                estado = EST_PARADO;
                libres = 0;
                s->decision = DEC_DETENER;
                s->v = 0.0f;
                s->w = 0.0f;
            } else {
                float signo = (candidato == ACC_IZQUIERDA) ? 1.0f : -1.0f;
                /* 90° respecto al rumbo que se venía manteniendo (no al actual,
                 * para que los pequeños desvíos no se acumulen de un tramo a otro) */
                theta_objetivo = envolver(theta_rumbo + signo * 0.5f * (float)M_PI);
                estado = EST_GIRO;
                s->decision = (candidato == ACC_IZQUIERDA) ? DEC_IZQUIERDA : DEC_DERECHA;
                s->v = 0.0f;
                s->w = signo * W_GIRO_MAX;
            }
            votos = 0;
            candidato_previo = -1;
        } else {
            s->v = V_LENTO;              /* acción en espera de confirmación */
        }
        break;
    }

    case EST_GIRO: {
        float error = envolver(theta_objetivo - th_odo);
        if (fabsf(error) < TOL_GIRO) {
            estado = EST_AVANZAR;          /* giro terminado: seguir avanzando con cautela */
            dist_desde_giro = 0.0f;
            theta_rumbo = theta_objetivo;  /* nuevo rumbo a mantener */
            s->v = V_LENTO;
            s->w = corregir_rumbo();
        } else {
            s->v = 0.0f;
            s->w = saturarf(K_GIRO * error, W_GIRO_MAX);
        }
        s->accion = ACC_GIRANDO;
        break;
    }

    case EST_PARADO:
    default: {
        s->v = 0.0f;
        s->w = 0.0f;
        s->accion = ACC_ESPERANDO;
        if (con_imagen) {
            int obstaculo = (clase == CLASE_OBSTACULO && conf >= UMBRAL_CONFIANZA) && !lejos;
            libres = obstaculo ? 0 : libres + 1;
            if (libres >= N_LIBRE) {
                estado = EST_AVANZAR;
                candidato_previo = -1;
                votos = 0;
                s->decision = DEC_REANUDAR;
                s->v = V_LENTO;
                s->w = corregir_rumbo();
                s->accion = ACC_AVANZAR;
            }
        }
        break;
    }
    }
    s->estado = (uint8_t)estado;
}

void cinematica_inversa(float v, float w, float *w_izq, float *w_der)
{
    /* v_der = v + w L/2 ;  v_izq = v - w L/2 ;  w_rueda = v_rueda / r */
    float wd = (v + 0.5f * w * l_eje) / r_rueda;
    float wi = (v - 0.5f * w * l_eje) / r_rueda;

    float m = fmaxf(fabsf(wd), fabsf(wi));
    if (m > w_rueda_max) {               /* escalar ambas para no deformar la trayectoria */
        wd *= w_rueda_max / m;
        wi *= w_rueda_max / m;
    }
    *w_izq = wi;
    *w_der = wd;
}
