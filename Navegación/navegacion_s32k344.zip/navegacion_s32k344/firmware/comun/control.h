/*
 * control.h - Decisión de navegación, odometría y cinemática del robot diferencial.
 */
#ifndef CONTROL_H
#define CONTROL_H

#include <stdint.h>

/* Clases de la CNN (mismo orden que en el entrenamiento) */
enum { CLASE_AVANZAR = 0, CLASE_IZQUIERDA = 1, CLASE_DERECHA = 2, CLASE_OBSTACULO = 3,
       CLASE_NINGUNA = 255 };

/* Acción seleccionada en cada ciclo */
enum { ACC_AVANZAR = 0, ACC_IZQUIERDA = 1, ACC_DERECHA = 2, ACC_DETENER = 3,
       ACC_INCIERTO = 4, ACC_GIRANDO = 5, ACC_ESPERANDO = 6, ACC_SIN_OBJETO = 7 };

/* Estado de la máquina de estados */
enum { EST_AVANZAR = 0, EST_GIRO = 1, EST_PARADO = 2 };

/* Decisiones confirmadas (eventos) */
enum { DEC_NINGUNA = 0, DEC_IZQUIERDA = 1, DEC_DERECHA = 2, DEC_DETENER = 3,
       DEC_REANUDAR = 4 };

typedef struct {
    float   v;          /* velocidad lineal deseada (m/s)    */
    float   w;          /* velocidad angular deseada (rad/s) */
    uint8_t accion;
    uint8_t estado;
    uint8_t decision;
} control_salida_t;

/* Geometría del robot (radio de rueda, distancia entre ruedas, vel. máx. de rueda).
 * El puente la manda al inicio con la del Pioneer; si no, se usa la de config.h. */
void control_configurar(float radio, float eje, float w_max);
void control_reiniciar(int32_t enc_izq, int32_t enc_der);
int  control_necesita_imagen(void);

/* Un paso de control.
 *   con_imagen: 1 si en este ciclo hubo inferencia (prob válido)
 *   prob:       probabilidades de las 4 clases
 *   enc_*:      lecturas de los encoders (ticks acumulados)
 *   dist_frontal: distancia (m) al objeto más cercano delante; < 0 si no hay sensor
 *   rumbo_imu:  orientación del giroscopio (rad); NAN si no hay IMU */
void control_paso(int con_imagen, const float *prob, int32_t enc_izq, int32_t enc_der,
                  float dist_frontal, float rumbo_imu,
                  control_salida_t *s);

/* Cinemática inversa del robot diferencial: (v, w) -> velocidades de rueda (rad/s),
 * con saturación que conserva la curvatura. */
void cinematica_inversa(float v, float w, float *w_izq, float *w_der);

/* Pose estimada por odometría (para depuración) */
void control_pose(float *x, float *y, float *theta);

#endif
