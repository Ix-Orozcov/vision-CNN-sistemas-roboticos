/*
 * entrenamiento.c - Retropropagación completa de la CNN en float32 (ver entrenamiento.h).
 *
 * Distribución de datos (NHWC, igual que Keras):
 *   w1[c][ky][kx]          b1[c]       conv1: 64x64x1  -> 62x62x8  -> pool 31x31x8
 *   w2[c][ky][kx][ic]      b2[c]       conv2: 31x31x8  -> 29x29x16 -> pool 14x14x16
 *   w3[o][i] (i = NHWC)    b3[o]       dense: 3136 -> 16 (ReLU)
 *   w4[k][o]               b4[k]       dense: 16 -> 4 (softmax)
 */
#include <math.h>
#include <string.h>
#include "entrenamiento.h"
#include "arquitectura.h"
#include "memoria.h"

/* ---------------- Pesos en float32 ---------------- */
static float w1[ARQ_N_W1], b1[ARQ_C1];
static float w2[ARQ_N_W2], b2[ARQ_C2];
/* La capa densa grande (~196 KB) se parte en cuatro bloques de ~49 KB que se reparten
 * entre las RAM del micro (ver memoria.h). */
static float w3_0[ARQ_D1 / 4][ARQ_PLANO] SECCION_DTCM;
static float w3_1[ARQ_D1 / 4][ARQ_PLANO] SECCION_DTCM;
static float w3_2[ARQ_D1 / 4][ARQ_PLANO] SECCION_NOCACHE;
static float w3_3[ARQ_D1 / 4][ARQ_PLANO];
static float *w3[ARQ_D1];
static float b3[ARQ_D1];
static float w4[ARQ_N_W4], b4[ARQ_CLASES];
static int   pesos_listos;

/* ---------------- Memoria de trabajo compartida ---------------- */
uint32_t memoria_trabajo[(MEM_TRABAJO_BYTES + 3) / 4];

#define N_P1  (ARQ_P1 * ARQ_P1 * ARQ_C1)
#define F_BASE ((float *)memoria_trabajo)
#define P1    (F_BASE)                         /* salida pool1 (tras ReLU)          */
#define DP1   (P1 + N_P1)                      /* gradiente respecto a pool1         */
#define P2    (DP1 + N_P1)                     /* salida pool2 = entrada de la densa */
#define DP2   (P2 + ARQ_PLANO)                 /* gradiente respecto a pool2         */
#define GW1   (DP2 + ARQ_PLANO)                /* gradientes de conv1 y conv2        */
#define GB1   (GW1 + ARQ_N_W1)
#define GW2   (GB1 + ARQ_C1)
#define GB2   (GW2 + ARQ_N_W2)
#define IDX1  ((uint8_t *)(GB2 + ARQ_C2))      /* posición del máximo en cada pooling */
#define IDX2  (IDX1 + N_P1)

/* Activaciones pequeñas. La imagen de entrada no se copia a float: se usa la del
 * llamador (uint8) y se normaliza al vuelo, lo que ahorra 16 KB de RAM. */
static const uint8_t *img;
#define X(i) ((float)img[i] * (1.0f / 255.0f))
static float h1[ARQ_D1], z[ARQ_CLASES];

/* ---------------- Calibración y modelo INT8 cuantizado en el micro ---------------- */
static int      calibrando;
static uint32_t n_calib;
static float    max_p1, max_p2, max_h1, min_z, max_z;

static int8_t   q_w1[ARQ_N_W1], q_w2[ARQ_N_W2], q_w4[ARQ_N_W4];
/* Los pesos INT8 de la capa densa grande (50 KB) no tienen arreglo propio: se guardan en
 * la memoria de trabajo, en una zona que la inferencia INT8 no usa. Como el entrenamiento
 * y la inferencia float también usan esa memoria, después de usarlas se vuelven a
 * calcular desde los pesos float (mismo resultado, ~50 mil divisiones). */
#define q_w3 ((int8_t *)memoria_trabajo + MEM_OFFSET_Q_W3)
static float    s_w3[ARQ_D1];          /* escala por renglón de esa capa */
static int      q_w3_vigente;
_Static_assert(MEM_OFFSET_Q_W3 + ARQ_N_W3 <= MEM_TRABAJO_BYTES, "q_w3 no cabe en la memoria de trabajo");
static int32_t  q_b1[ARQ_C1], q_b2[ARQ_C2], q_b3[ARQ_D1], q_b4[ARQ_CLASES];
static int32_t  q_m1[ARQ_C1], q_m2[ARQ_C2], q_m3[ARQ_D1], q_m4[ARQ_CLASES];
static int8_t   q_d1[ARQ_C1], q_d2[ARQ_C2], q_d3[ARQ_D1], q_d4[ARQ_CLASES];
static capa_t   capas_mcu[6];
static float    s_salida;
static int32_t  zp_salida;
static int      int8_listo;

/* ======================================================================= */

static uint32_t semilla_rng;
static float aleatorio_uniforme(float limite)          /* xorshift32 -> [-limite, limite) */
{
    semilla_rng ^= semilla_rng << 13;
    semilla_rng ^= semilla_rng >> 17;
    semilla_rng ^= semilla_rng << 5;
    return limite * (2.0f * (float)(semilla_rng >> 8) / 16777216.0f - 1.0f);
}

/* Los renglones de w3 están repartidos en 4 bloques de memoria (DTCM, SRAM sin caché
 * y SRAM normal); w3[o] apunta al renglón o. */
static void enlazar_w3(void)
{
    for (int o = 0; o < ARQ_D1; o++) {
        int b = o / (ARQ_D1 / 4), r = o % (ARQ_D1 / 4);
        w3[o] = (b == 0) ? w3_0[r] : (b == 1) ? w3_1[r] : (b == 2) ? w3_2[r] : w3_3[r];
    }
}

void ent_iniciar_pesos(uint32_t semilla)
{
    semilla_rng = semilla ? semilla : 1u;
    enlazar_w3();
    /* Glorot uniforme: límite = sqrt(6 / (fan_in + fan_out)), sesgos en cero */
    float l1 = sqrtf(6.0f / (ARQ_K * ARQ_K * 1 + ARQ_K * ARQ_K * ARQ_C1));
    float l2 = sqrtf(6.0f / (ARQ_K * ARQ_K * ARQ_C1 + ARQ_K * ARQ_K * ARQ_C2));
    float l3 = sqrtf(6.0f / (ARQ_PLANO + ARQ_D1));
    float l4 = sqrtf(6.0f / (ARQ_D1 + ARQ_CLASES));
    for (int i = 0; i < ARQ_N_W1; i++) w1[i] = aleatorio_uniforme(l1);
    for (int i = 0; i < ARQ_N_W2; i++) w2[i] = aleatorio_uniforme(l2);
    for (int o = 0; o < ARQ_D1; o++)
        for (int i = 0; i < ARQ_PLANO; i++) w3[o][i] = aleatorio_uniforme(l3);
    for (int i = 0; i < ARQ_N_W4; i++) w4[i] = aleatorio_uniforme(l4);
    memset(b1, 0, sizeof(b1));
    memset(b2, 0, sizeof(b2));
    memset(b3, 0, sizeof(b3));
    memset(b4, 0, sizeof(b4));
    pesos_listos = 1;
    int8_listo = 0;
}

int ent_hay_pesos(void) { return pesos_listos; }

/* ---------------- Paso hacia adelante ---------------- */

static void hacia_adelante(const uint8_t *imagen, float *prob)
{
    img = imagen;                                              /* normalización: X(i) = píxel/255 */
    q_w3_vigente = 0;                      /* la memoria de trabajo se va a sobrescribir */

    /* conv1 + ReLU + maxpool 2x2 (sin guardar la salida completa de la convolución) */
    for (int oy = 0; oy < ARQ_P1; oy++) {
        for (int ox = 0; ox < ARQ_P1; ox++) {
            for (int c = 0; c < ARQ_C1; c++) {
                const float *w = &w1[c * 9];
                float m = -1e30f;
                uint8_t arg = 0;
                for (int d = 0; d < 4; d++) {
                    int py = 2 * oy + (d >> 1), px = 2 * ox + (d & 1);
                    const int b = py * ARQ_ENT + px;
                    float v = b1[c]
                        + X(b) * w[0] + X(b + 1) * w[1] + X(b + 2) * w[2]
                        + X(b + ARQ_ENT) * w[3] + X(b + ARQ_ENT + 1) * w[4] + X(b + ARQ_ENT + 2) * w[5]
                        + X(b + 2 * ARQ_ENT) * w[6] + X(b + 2 * ARQ_ENT + 1) * w[7]
                        + X(b + 2 * ARQ_ENT + 2) * w[8];
                    if (v > m) { m = v; arg = (uint8_t)d; }
                }
                int i = (oy * ARQ_P1 + ox) * ARQ_C1 + c;
                P1[i] = m > 0.0f ? m : 0.0f;
                IDX1[i] = arg;
            }
        }
    }

    /* conv2 + ReLU + maxpool 2x2 (la fila/columna 28 no llega a ningún pooling) */
    for (int oy = 0; oy < ARQ_P2; oy++) {
        for (int ox = 0; ox < ARQ_P2; ox++) {
            for (int c = 0; c < ARQ_C2; c++) {
                const float *w = &w2[c * 72];
                float m = -1e30f;
                uint8_t arg = 0;
                for (int d = 0; d < 4; d++) {
                    int py = 2 * oy + (d >> 1), px = 2 * ox + (d & 1);
                    float v = b2[c];
                    for (int ky = 0; ky < 3; ky++) {
                        const float *x = &P1[((py + ky) * ARQ_P1 + px) * ARQ_C1];
                        const float *wk = &w[ky * 3 * ARQ_C1];
                        for (int j = 0; j < 3 * ARQ_C1; j++) {
                            v += x[j] * wk[j];
                        }
                    }
                    if (v > m) { m = v; arg = (uint8_t)d; }
                }
                int i = (oy * ARQ_P2 + ox) * ARQ_C2 + c;
                P2[i] = m > 0.0f ? m : 0.0f;
                IDX2[i] = arg;
            }
        }
    }

    /* dense 3136 -> 16 + ReLU */
    for (int o = 0; o < ARQ_D1; o++) {
        const float *w = w3[o];
        float s = b3[o];
        for (int i = 0; i < ARQ_PLANO; i++) {
            s += w[i] * P2[i];
        }
        h1[o] = s > 0.0f ? s : 0.0f;
    }

    /* dense 16 -> 4 + softmax */
    float zmax = -1e30f, suma = 0.0f;
    for (int k = 0; k < ARQ_CLASES; k++) {
        float s = b4[k];
        for (int o = 0; o < ARQ_D1; o++) {
            s += w4[k * ARQ_D1 + o] * h1[o];
        }
        z[k] = s;
        if (s > zmax) zmax = s;
    }
    for (int k = 0; k < ARQ_CLASES; k++) {
        prob[k] = expf(z[k] - zmax);
        suma += prob[k];
    }
    for (int k = 0; k < ARQ_CLASES; k++) {
        prob[k] /= suma;
    }
}

void ent_inferir(const uint8_t *imagen, float *prob)
{
    hacia_adelante(imagen, prob);
    if (calibrando) {                      /* rangos para la cuantización INT8 */
        for (int i = 0; i < N_P1; i++)      if (P1[i] > max_p1) max_p1 = P1[i];
        for (int i = 0; i < ARQ_PLANO; i++) if (P2[i] > max_p2) max_p2 = P2[i];
        for (int o = 0; o < ARQ_D1; o++)    if (h1[o] > max_h1) max_h1 = h1[o];
        for (int k = 0; k < ARQ_CLASES; k++) {
            if (z[k] < min_z) min_z = z[k];
            if (z[k] > max_z) max_z = z[k];
        }
        n_calib++;
    }
}

/* ---------------- Paso de entrenamiento ---------------- */

float ent_paso(const uint8_t *imagen, int etiqueta, float tasa, float *prob, int *pred)
{
    float dz[ARQ_CLASES], dh[ARQ_D1];

    hacia_adelante(imagen, prob);
    int mejor = 0;
    for (int k = 1; k < ARQ_CLASES; k++) {
        if (prob[k] > prob[mejor]) mejor = k;
    }
    *pred = mejor;
    float perdida = -logf(prob[etiqueta] > 1e-7f ? prob[etiqueta] : 1e-7f);

    /* Salida: d(pérdida)/dz = softmax - one_hot */
    for (int k = 0; k < ARQ_CLASES; k++) {
        dz[k] = prob[k] - (k == etiqueta ? 1.0f : 0.0f);
    }

    /* dense 16 -> 4: gradiente hacia atrás con los pesos viejos y luego actualizar */
    for (int o = 0; o < ARQ_D1; o++) {
        float s = 0.0f;
        for (int k = 0; k < ARQ_CLASES; k++) s += w4[k * ARQ_D1 + o] * dz[k];
        dh[o] = h1[o] > 0.0f ? s : 0.0f;                          /* derivada de ReLU */
    }
    for (int k = 0; k < ARQ_CLASES; k++) {
        for (int o = 0; o < ARQ_D1; o++) w4[k * ARQ_D1 + o] -= tasa * dz[k] * h1[o];
        b4[k] -= tasa * dz[k];
    }

    /* dense 3136 -> 16: para cada entrada i se calcula su gradiente con los pesos
     * viejos y enseguida se actualiza esa columna (no hace falta otro búfer) */
    for (int i = 0; i < ARQ_PLANO; i++) {
        float s = 0.0f, xi = P2[i];
        for (int o = 0; o < ARQ_D1; o++) {
            s += w3[o][i] * dh[o];
            w3[o][i] -= tasa * dh[o] * xi;
        }
        DP2[i] = xi > 0.0f ? s : 0.0f;                           /* ReLU (vía el pooling) */
    }
    for (int o = 0; o < ARQ_D1; o++) b3[o] -= tasa * dh[o];

    /* conv2: el gradiente solo pasa por la posición que ganó cada pooling */
    memset(GW2, 0, sizeof(float) * (ARQ_N_W2 + ARQ_C2));
    memset(DP1, 0, sizeof(float) * N_P1);
    for (int oy = 0; oy < ARQ_P2; oy++) {
        for (int ox = 0; ox < ARQ_P2; ox++) {
            for (int c = 0; c < ARQ_C2; c++) {
                int i = (oy * ARQ_P2 + ox) * ARQ_C2 + c;
                float g = DP2[i];
                if (g == 0.0f) continue;
                int py = 2 * oy + (IDX2[i] >> 1), px = 2 * ox + (IDX2[i] & 1);
                GB2[c] += g;
                for (int ky = 0; ky < 3; ky++) {
                    int base = ((py + ky) * ARQ_P1 + px) * ARQ_C1;
                    float *gw = &GW2[c * 72 + ky * 3 * ARQ_C1];
                    const float *w = &w2[c * 72 + ky * 3 * ARQ_C1];
                    for (int j = 0; j < 3 * ARQ_C1; j++) {
                        gw[j] += g * P1[base + j];
                        DP1[base + j] += g * w[j];
                    }
                }
            }
        }
    }
    for (int i = 0; i < ARQ_N_W2; i++) w2[i] -= tasa * GW2[i];
    for (int c = 0; c < ARQ_C2; c++)   b2[c] -= tasa * GB2[c];

    /* conv1 */
    memset(GW1, 0, sizeof(float) * (ARQ_N_W1 + ARQ_C1));
    for (int i = 0; i < N_P1; i++) {
        float g = (P1[i] > 0.0f) ? DP1[i] : 0.0f;                 /* ReLU de conv1 */
        if (g == 0.0f) continue;
        int c = i % ARQ_C1, celda = i / ARQ_C1;
        int oy = celda / ARQ_P1, ox = celda % ARQ_P1;
        int py = 2 * oy + (IDX1[i] >> 1), px = 2 * ox + (IDX1[i] & 1);
        GB1[c] += g;
        for (int ky = 0; ky < 3; ky++)
            for (int kx = 0; kx < 3; kx++)
                GW1[c * 9 + ky * 3 + kx] += g * X((py + ky) * ARQ_ENT + px + kx);
    }
    for (int i = 0; i < ARQ_N_W1; i++) w1[i] -= tasa * GW1[i];
    for (int c = 0; c < ARQ_C1; c++)   b1[c] -= tasa * GB1[c];

    int8_listo = 0;                     /* los pesos cambiaron: hay que volver a cuantizar */
    return perdida;
}

/* ---------------- Calibración y cuantización INT8 ---------------- */

void ent_calibrar_iniciar(void)
{
    calibrando = 1;
    n_calib = 0;
    max_p1 = max_p2 = max_h1 = 0.0f;
    min_z = 0.0f;
    max_z = 0.0f;
}

uint32_t ent_calibrar_muestras(void) { return n_calib; }

static void cuantizar_multiplicador(double real, int32_t *m, int8_t *d)
{
    /* QuantizeMultiplier de TFLite */
    if (real <= 0.0) { *m = 0; *d = 0; return; }
    int e;
    double q = frexp(real, &e);
    long long qf = llround(q * 2147483648.0);
    if (qf == 2147483648LL) { qf /= 2; e++; }
    if (e < -31) { qf = 0; e = 0; }
    if (e > 30)  { qf = 2147483647LL; e = 30; }
    *m = (int32_t)qf;
    *d = (int8_t)e;
}

/* Cuantiza una capa con pesos por canal simétricos y sesgo int32.
 * s_in/zp_in: escala de la entrada, s_out/zp_out: de la salida. */
static void cuantizar_capa(int n_out, int n_por_salida, float *const *filas, const float *w_plano,
                           const float *b, float s_in, int32_t zp_in, float s_out,
                           int8_t *qw, int32_t *qb, int32_t *qm, int8_t *qd, float *escalas)
{
    for (int o = 0; o < n_out; o++) {
        const float *w = filas ? filas[o] : &w_plano[o * n_por_salida];
        float maxabs = 0.0f;
        for (int i = 0; i < n_por_salida; i++) if (fabsf(w[i]) > maxabs) maxabs = fabsf(w[i]);
        float s_w = maxabs > 0.0f ? maxabs / 127.0f : 1e-8f;
        if (escalas) escalas[o] = s_w;
        int32_t suma = 0;
        for (int i = 0; i < n_por_salida; i++) {
            long v = lroundf(w[i] / s_w);
            if (v > 127) v = 127;
            if (v < -127) v = -127;
            qw[o * n_por_salida + i] = (int8_t)v;
            suma += (int32_t)v;
        }
        double s_bias = (double)s_in * (double)s_w;
        qb[o] = (int32_t)llround((double)b[o] / s_bias) - zp_in * suma;   /* sesgo corregido */
        cuantizar_multiplicador(s_bias / (double)s_out, &qm[o], &qd[o]);
    }
}

static capa_t capa(uint8_t tipo, uint8_t k, int ih, int iw, int ic, int oh, int ow, int oc,
                   int32_t zp, int32_t amin, const int8_t *w, const int32_t *b,
                   const int32_t *m, const int8_t *d)
{
    capa_t c;
    memset(&c, 0, sizeof(c));
    c.tipo = tipo; c.k = k; c.por_canal = 1;
    c.in_h = (uint16_t)ih; c.in_w = (uint16_t)iw; c.in_c = (uint16_t)ic;
    c.out_h = (uint16_t)oh; c.out_w = (uint16_t)ow; c.out_c = (uint16_t)oc;
    c.out_zp = zp; c.act_min = amin; c.act_max = 127;
    c.w = w; c.b = b; c.mult = m; c.desp = d;
    return c;
}

int ent_cuantizar(void)
{
    if (!pesos_listos || n_calib == 0) {
        return -1;
    }
    /* Escalas de las activaciones (ReLU: rango [0, max] -> punto cero -128) */
    const float s_in = 1.0f / 255.0f;                 /* entrada: píxel/255, zp = -128 */
    const int32_t zp_in = -128;
    float s1 = (max_p1 > 0 ? max_p1 : 1e-6f) / 255.0f;
    float s2 = (max_p2 > 0 ? max_p2 : 1e-6f) / 255.0f;
    float s3 = (max_h1 > 0 ? max_h1 : 1e-6f) / 255.0f;
    float zmin = min_z < 0.0f ? min_z : 0.0f, zmax = max_z > 0.0f ? max_z : 0.0f;
    float s4 = (zmax - zmin > 1e-6f ? zmax - zmin : 1e-6f) / 255.0f;
    long zp4 = lroundf(-128.0f - zmin / s4);
    if (zp4 < -128) zp4 = -128;
    if (zp4 > 127) zp4 = 127;

    cuantizar_capa(ARQ_C1, ARQ_K * ARQ_K, NULL, w1, b1, s_in, zp_in, s1, q_w1, q_b1, q_m1, q_d1, NULL);
    cuantizar_capa(ARQ_C2, ARQ_K * ARQ_K * ARQ_C1, NULL, w2, b2, s1, -128, s2, q_w2, q_b2, q_m2, q_d2, NULL);
    cuantizar_capa(ARQ_D1, ARQ_PLANO, w3, NULL, b3, s2, -128, s3, q_w3, q_b3, q_m3, q_d3, s_w3);
    cuantizar_capa(ARQ_CLASES, ARQ_D1, NULL, w4, b4, s3, -128, s4, q_w4, q_b4, q_m4, q_d4, NULL);
    q_w3_vigente = 1;

    capas_mcu[0] = capa(CAPA_CONV, 3, ARQ_ENT, ARQ_ENT, 1, ARQ_C1_SAL, ARQ_C1_SAL, ARQ_C1, -128, -128,
                        q_w1, q_b1, q_m1, q_d1);
    capas_mcu[1] = capa(CAPA_MAXPOOL, 2, ARQ_C1_SAL, ARQ_C1_SAL, ARQ_C1, ARQ_P1, ARQ_P1, ARQ_C1, -128, -128,
                        NULL, NULL, NULL, NULL);
    capas_mcu[2] = capa(CAPA_CONV, 3, ARQ_P1, ARQ_P1, ARQ_C1, ARQ_C2_SAL, ARQ_C2_SAL, ARQ_C2, -128, -128,
                        q_w2, q_b2, q_m2, q_d2);
    capas_mcu[3] = capa(CAPA_MAXPOOL, 2, ARQ_C2_SAL, ARQ_C2_SAL, ARQ_C2, ARQ_P2, ARQ_P2, ARQ_C2, -128, -128,
                        NULL, NULL, NULL, NULL);
    capas_mcu[4] = capa(CAPA_FC, 1, 1, 1, ARQ_PLANO, 1, 1, ARQ_D1, -128, -128, q_w3, q_b3, q_m3, q_d3);
    capas_mcu[5] = capa(CAPA_FC, 1, 1, 1, ARQ_D1, 1, 1, ARQ_CLASES, (int32_t)zp4, -128,
                        q_w4, q_b4, q_m4, q_d4);
    s_salida = s4;
    zp_salida = (int32_t)zp4;
    calibrando = 0;
    int8_listo = 1;
    return 0;
}

void ent_preparar_int8(void)
{
    /* Vuelve a escribir los pesos INT8 de la capa densa grande si la memoria de trabajo
     * se usó para otra cosa. Mismos pesos float y mismas escalas -> mismos valores. */
    if (!int8_listo || q_w3_vigente) {
        return;
    }
    for (int o = 0; o < ARQ_D1; o++) {
        for (int i = 0; i < ARQ_PLANO; i++) {
            long v = lroundf(w3[o][i] / s_w3[o]);
            if (v > 127) v = 127;
            if (v < -127) v = -127;
            q_w3[o * ARQ_PLANO + i] = (int8_t)v;
        }
    }
    q_w3_vigente = 1;
}

int           ent_hay_int8(void)      { return int8_listo; }
const capa_t *ent_capas_int8(void)    { return capas_mcu; }
float         ent_salida_escala(void) { return s_salida; }
int32_t       ent_salida_zp(void)     { return zp_salida; }

uint32_t ent_ram_pesos_bytes(void)
{
    return (uint32_t)(sizeof(w1) + sizeof(b1) + sizeof(w2) + sizeof(b2) + sizeof(w3_0) + sizeof(w3_1) +
                      sizeof(w3_2) + sizeof(w3_3) +
                      sizeof(b3) + sizeof(w4) + sizeof(b4) + sizeof(h1) + sizeof(z));
}

uint32_t ent_ram_int8_bytes(void)
{
    return (uint32_t)(sizeof(q_w1) + sizeof(q_w2) + sizeof(q_w4) + sizeof(s_w3) + sizeof(q_b1) +
                      sizeof(q_b2) + sizeof(q_b3) + sizeof(q_b4) + sizeof(q_m1) + sizeof(q_m2) +
                      sizeof(q_m3) + sizeof(q_m4) + sizeof(q_d1) + sizeof(q_d2) + sizeof(q_d3) +
                      sizeof(q_d4) + sizeof(capas_mcu));
}

/* ---------------- Exportación ---------------- */

int ent_n_bloques(void) { return 7 + ARQ_D1; }

float *ent_bloque_escribir(int i, uint32_t *n)
{
    if (i < 0 || i >= ent_n_bloques()) {
        *n = 0;
        return 0;
    }
    enlazar_w3();
    return (float *)ent_bloque(i, n);
}

void ent_pesos_cargados(void)
{
    pesos_listos = 1;
    int8_listo = 0;                        /* hay que volver a calibrar y cuantizar */
    q_w3_vigente = 0;
}

const float *ent_bloque(int i, uint32_t *n)
{
    if (i == 0) { *n = ARQ_N_W1; return w1; }
    if (i == 1) { *n = ARQ_C1;   return b1; }
    if (i == 2) { *n = ARQ_N_W2; return w2; }
    if (i == 3) { *n = ARQ_C2;   return b2; }
    if (i < 4 + ARQ_D1) { *n = ARQ_PLANO; return w3[i - 4]; }
    if (i == 4 + ARQ_D1) { *n = ARQ_D1; return b3; }
    if (i == 5 + ARQ_D1) { *n = ARQ_N_W4; return w4; }
    *n = ARQ_CLASES;
    return b4;
}
