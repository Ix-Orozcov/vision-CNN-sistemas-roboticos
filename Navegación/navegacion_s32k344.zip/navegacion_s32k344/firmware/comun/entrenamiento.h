/*
 * entrenamiento.h - Entrenamiento de la CNN completa en el microcontrolador.
 *
 * - Pesos en float32 en RAM (51 508 parámetros, ~201 KB).
 * - Descenso de gradiente estocástico con un ejemplo a la vez (batch = 1): cada capa
 *   se actualiza en cuanto se conoce su gradiente, así no hace falta un búfer de
 *   gradientes del tamaño de la red (no cabría en la RAM).
 * - Las convoluciones se calculan junto con el MaxPooling y solo se guarda el valor
 *   máximo y su posición; con eso basta para la retropropagación.
 * - Después de entrenar, el micro calibra los rangos de activación y cuantiza la red
 *   a INT8 (igual que TFLite: pesos por canal, activaciones asimétricas).
 */
#ifndef ENTRENAMIENTO_H
#define ENTRENAMIENTO_H

#include <stdint.h>
#include "cnn_int8.h"

/* Inicialización Glorot uniforme (la de Keras por defecto) con la semilla dada. */
void     ent_iniciar_pesos(uint32_t semilla);
int      ent_hay_pesos(void);

/* Un paso de entrenamiento con una imagen 64x64 (uint8) y su etiqueta.
 * Devuelve la pérdida (entropía cruzada) ANTES de actualizar; deja en prob/pred
 * la salida del paso hacia adelante. */
float    ent_paso(const uint8_t *imagen, int etiqueta, float tasa, float *prob, int *pred);

/* Inferencia en float con los pesos actuales. Si la calibración está activa,
 * acumula los rangos de activación para la cuantización. */
void     ent_inferir(const uint8_t *imagen, float *prob);

void     ent_calibrar_iniciar(void);
uint32_t ent_calibrar_muestras(void);

/* Cuantiza los pesos actuales a INT8. Devuelve 0 si salió bien. */
int      ent_cuantizar(void);
int      ent_hay_int8(void);
/* Llamar antes de usar el INT8 del micro (repone sus pesos en la memoria de trabajo). */
void     ent_preparar_int8(void);
const capa_t *ent_capas_int8(void);
float    ent_salida_escala(void);
int32_t  ent_salida_zp(void);

/* Memoria: pesos float + memoria de trabajo + modelo INT8 cuantizado en el micro */
uint32_t ent_ram_pesos_bytes(void);
uint32_t ent_ram_int8_bytes(void);

/* Exportación de los pesos (para guardarlos en la PC): bloques en el orden
 * w1, b1, w2, b2, w3 (16 renglones), b3, w4, b4. */
int          ent_n_bloques(void);
const float *ent_bloque(int i, uint32_t *n_floats);

/* Carga de pesos guardados en la PC (mismos bloques). ent_bloque_escribir devuelve
 * dónde copiar el bloque i (NULL si no existe); al terminar, ent_pesos_cargados()
 * los marca como válidos (el INT8 del micro se debe volver a calibrar y cuantizar). */
float       *ent_bloque_escribir(int i, uint32_t *n_floats);
void         ent_pesos_cargados(void);

#endif
