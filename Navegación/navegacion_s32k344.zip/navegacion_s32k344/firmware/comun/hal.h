/*
 * hal.h - Capa de abstracción de hardware.
 *
 * El resto del firmware solo usa estas funciones, así que el mismo código corre
 * en el S32K344 (hal_s32k344.c) y en la PC para pruebas (hal_pc.c).
 */
#ifndef HAL_H
#define HAL_H

#include <stdint.h>

void     hal_iniciar(int argc, char **argv);

/* Contador libre de ciclos de reloj (DWT->CYCCNT en el Cortex-M7). */
uint32_t hal_ciclos(void);
uint32_t hal_ciclos_por_us(void);
uint32_t hal_cpu_mhz(void);

/* UART: escritura bloqueante. Devuelve 0 si todo salió bien. */
int      hal_uart_escribir(const uint8_t *datos, uint32_t n);

/* UART: recepción en dos pasos para poder procesar un renglón de la imagen
 * mientras llega el siguiente (doble búfer).
 *   hal_uart_rx_iniciar(): arranca la recepción de n bytes en 'destino'.
 *   hal_uart_rx_esperar(): espera a que termine. 0 = completa, <0 = error/timeout. */
int      hal_uart_rx_iniciar(uint8_t *destino, uint32_t n);
int      hal_uart_rx_esperar(uint32_t timeout_us);

/* UART: pasa al búfer de la recepción en curso los bytes que ya llegaron.
 * El preprocesamiento lo llama seguido mientras trabaja en un renglón, para que
 * el FIFO del LPUART (de pocos bytes) no se desborde a velocidades altas.
 * En la PC no hace nada. */
void     hal_uart_sondear(void);

/* Utilidad: microsegundos entre dos lecturas de hal_ciclos(). */
static inline uint32_t hal_us_desde(uint32_t c0, uint32_t c1)
{
    return (c1 - c0) / hal_ciclos_por_us();
}

#endif
