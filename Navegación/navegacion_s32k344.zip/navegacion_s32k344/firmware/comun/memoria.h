/*
 * memoria.h - Memoria de trabajo compartida.
 *
 * El entrenamiento (activaciones y gradientes) y la inferencia INT8 (búferes
 * ping-pong) nunca se ejecutan al mismo tiempo, así que usan el MISMO bloque de RAM.
 * Esto ahorra ~44 KB y es lo que permite que todo quepa en el S32K344.
 */
#ifndef MEMORIA_H
#define MEMORIA_H

#include <stdint.h>
#include "arquitectura.h"

/* Contenido durante el entrenamiento (en floats):
 *   pool1 + d_pool1 (31x31x8 c/u), pool2 + d_pool2 (14x14x16 c/u),
 *   gradientes de conv1 y conv2, y los índices del máximo de cada pooling. */
#define MEM_FLOATS_ENTRENAMIENTO (2 * ARQ_P1 * ARQ_P1 * ARQ_C1 + 2 * ARQ_PLANO + \
                                  ARQ_N_W1 + ARQ_C1 + ARQ_N_W2 + ARQ_C2)
#define MEM_BYTES_INDICES        (ARQ_P1 * ARQ_P1 * ARQ_C1 + ARQ_PLANO)
#define MEM_TRABAJO_BYTES        (MEM_FLOATS_ENTRENAMIENTO * 4 + MEM_BYTES_INDICES)

/* Reparto de los arreglos grandes entre las RAM del S32K344 (solo al compilar para ARM).
 * El linker de RTD pone todo .bss en int_sram (192 KB) y no cabe; por eso:
 *   .ia_dtcm    -> DTCM (int_dtcm)                    : 2/4 de los pesos de la capa densa + Lanczos
 *   .ia_nocache -> SRAM no cacheable (int_sram_no_cacheable): 1/4 de los pesos de la capa densa
 *   el resto    -> int_sram (como siempre)
 * Hay que agregar esas dos secciones al archivo del linker (ver README, sección 4.3).
 * Estos arreglos no necesitan iniciar en cero: el firmware los llena antes de usarlos. */
#if defined(__arm__) && !defined(SIN_SECCIONES_RAM)
#define SECCION_DTCM    __attribute__((section(".ia_dtcm"), aligned(4)))
#define SECCION_NOCACHE __attribute__((section(".ia_nocache"), aligned(4)))
#else
#define SECCION_DTCM
#define SECCION_NOCACHE
#endif

extern uint32_t memoria_trabajo[(MEM_TRABAJO_BYTES + 3) / 4];

/* Mientras se usa la inferencia INT8 del modelo entrenado en el micro, sus pesos de la
 * capa densa grande (16 x 3136 bytes) viven aquí, justo después de los búferes ping-pong. */
#define MEM_OFFSET_Q_W3          (ARQ_BUF_A_BYTES + ARQ_BUF_B_BYTES)

#endif
