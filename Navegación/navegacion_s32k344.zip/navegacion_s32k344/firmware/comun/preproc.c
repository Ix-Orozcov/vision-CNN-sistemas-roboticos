/*
 * preproc.c - Escala de grises + Lanczos (igual que PIL) + normalización INT8.
 *
 * El filtro reproduce Pillow (libImaging/Resample.c): coeficientes en punto fijo
 * de 22 bits, primero pasada horizontal y luego vertical, con redondeo a 8 bits
 * entre ambas. La pasada vertical usa un búfer circular de pocos renglones, así
 * que la RAM necesaria no depende del alto de la foto.
 */
#include <math.h>
#include <string.h>
#include "preproc.h"
#include "config.h"
#include "memoria.h"
#include "hal.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define BITS_PRECISION  22                                         /* 32 - 8 - 2 de PIL */
#define PRE_KMAX        (((3 * PRE_MAX_ENTRADA + PRE_SALIDA - 1) / PRE_SALIDA) * 2 + 1)

/* Coeficientes y límites de cada pasada. Una sola tabla basta: la imagen es cuadrada
 * (misma tabla para las dos pasadas) o uno de sus lados ya mide 64 (esa pasada se omite). */
static int32_t coef[PRE_SALIDA * PRE_KMAX] SECCION_DTCM;
static int16_t xmin_t[PRE_SALIDA], ymin_t[PRE_SALIDA];
static uint8_t xn_t[PRE_SALIDA],  yn_t[PRE_SALIDA];

/* Renglones ya filtrados en horizontal (búfer circular) */
static uint8_t anillo[PRE_KMAX][PRE_SALIDA] SECCION_DTCM;
static uint8_t gris[PRE_MAX_ENTRADA];
static uint8_t salida_u8[PRE_SALIDA * PRE_SALIDA];

static int ancho_in, alto_in, canales_in, renglon_actual, siguiente_salida;
static int ancho_previo = -1, alto_previo = -1;

uint32_t preproc_ram_bytes(void)
{
    return (uint32_t)(sizeof(coef) + sizeof(anillo) + sizeof(gris) +
                      sizeof(salida_u8) + sizeof(xmin_t) +
                      sizeof(ymin_t) + sizeof(xn_t) + sizeof(yn_t));
}

/* ---------- Filtro de Lanczos (a = 3), igual que Pillow ---------- */

static double sinc(double x)
{
    if (x == 0.0) {
        return 1.0;
    }
    x = x * M_PI;
    return sin(x) / x;
}

static double lanczos(double x)
{
    if (-3.0 <= x && x < 3.0) {
        return sinc(x) * sinc(x / 3.0);
    }
    return 0.0;
}

static int calcular_coeficientes(int n_in, int n_out, int16_t *vmin, uint8_t *vn, int32_t *coef)
{
    double escala = (double)n_in / n_out;
    double escala_filtro = escala < 1.0 ? 1.0 : escala;
    double soporte = 3.0 * escala_filtro;
    int ksize = (int)ceil(soporte) * 2 + 1;
    double k[PRE_KMAX];

    if (ksize > PRE_KMAX) {
        return -1;
    }
    for (int xx = 0; xx < n_out; xx++) {
        double centro = (xx + 0.5) * escala;
        double suma = 0.0, ss = 1.0 / escala_filtro;
        int xmin = (int)(centro - soporte + 0.5);
        int xmax = (int)(centro + soporte + 0.5);
        if (xmin < 0) xmin = 0;
        if (xmax > n_in) xmax = n_in;
        xmax -= xmin;
        for (int x = 0; x < xmax; x++) {
            double w = lanczos((x + xmin - centro + 0.5) * ss);
            k[x] = w;
            suma += w;
        }
        for (int x = 0; x < PRE_KMAX; x++) {
            double w = (x < xmax && suma != 0.0) ? k[x] / suma : 0.0;
            coef[xx * PRE_KMAX + x] = (w < 0) ? (int32_t)(-0.5 + w * (1 << BITS_PRECISION))
                                               : (int32_t)(0.5 + w * (1 << BITS_PRECISION));
        }
        vmin[xx] = (int16_t)xmin;
        vn[xx] = (uint8_t)xmax;
    }
    return 0;
}

static inline uint8_t recortar8(int32_t v)
{
    if (v >= (1 << BITS_PRECISION << 8)) return 255;
    if (v <= 0) return 0;
    return (uint8_t)(v >> BITS_PRECISION);
}

/* ---------- API ---------- */

void preproc_crear_tabla(float escala, int32_t zp, int8_t *tabla)
{
    for (int p = 0; p < 256; p++) {
        float x = (float)p / 255.0f;                            /* normalizar a [0, 1] */
        long q = lroundf(x / escala) + zp;                      /* cuantizar a INT8     */
        if (q < -128) q = -128;
        if (q > 127) q = 127;
        tabla[p] = (int8_t)q;
    }
}

void preproc_cuantizar(const uint8_t *imagen, const int8_t *tabla, int8_t *salida)
{
    for (int i = 0; i < PRE_SALIDA * PRE_SALIDA; i++) {
        salida[i] = tabla[imagen[i]];
    }
}

int preproc_comenzar(int ancho, int alto, int canales)
{
    if (ancho < 1 || alto < 1 || ancho > PRE_MAX_ENTRADA || alto > PRE_MAX_ENTRADA ||
        (canales != 1 && canales != 3)) {
        return -1;
    }
    if (ancho != alto && ancho != PRE_SALIDA && alto != PRE_SALIDA) {
        return -1;              /* no soportado: rectangular con ningún lado de 64 */
    }
    if (ancho != ancho_previo || alto != alto_previo) {      /* recalcular solo si cambia */
        if (ancho != PRE_SALIDA &&
            calcular_coeficientes(ancho, PRE_SALIDA, xmin_t, xn_t, coef) != 0) {
            return -1;
        }
        if (alto != PRE_SALIDA) {
            if (alto == ancho) {                              /* cuadrada: mismos coeficientes */
                memcpy(ymin_t, xmin_t, sizeof(ymin_t));
                memcpy(yn_t, xn_t, sizeof(yn_t));
            } else if (calcular_coeficientes(alto, PRE_SALIDA, ymin_t, yn_t, coef) != 0) {
                return -1;
            }
        }
        ancho_previo = ancho;
        alto_previo = alto;
    }
    ancho_in = ancho;
    alto_in = alto;
    canales_in = canales;
    renglon_actual = 0;
    siguiente_salida = 0;
    return 0;
}

static void pasada_vertical(int y)
{
    uint8_t *dst = &salida_u8[y * PRE_SALIDA];
    if (alto_in == PRE_SALIDA) {                     /* sin cambio de alto: copiar */
        memcpy(dst, anillo[y % PRE_KMAX], PRE_SALIDA);
        return;
    }
    const int32_t *k = &coef[y * PRE_KMAX];
    const int ymin = ymin_t[y], n = yn_t[y];
    for (int x = 0; x < PRE_SALIDA; x++) {
        int32_t s = 1 << (BITS_PRECISION - 1);
        if ((x & 7) == 0) {
            hal_uart_sondear();          /* no dejar que se llene el FIFO del UART */
        }
        for (int i = 0; i < n; i++) {
            s += (int32_t)anillo[(ymin + i) % PRE_KMAX][x] * k[i];
        }
        dst[x] = recortar8(s);
    }
}

void preproc_renglon(const uint8_t *renglon)
{
    const uint8_t *px = renglon;

    /* 1) Escala de grises (fórmula ITU-R 601 en punto fijo, igual que PIL) */
    if (canales_in == 3) {
        for (int x = 0; x < ancho_in; x++) {
            const uint8_t *p = &renglon[3 * x];
            gris[x] = (uint8_t)((p[0] * 19595u + p[1] * 38470u + p[2] * 7471u + 0x8000u) >> 16);
            if ((x & 31) == 0) {
                hal_uart_sondear();
            }
        }
        px = gris;
    }

    /* 2a) Pasada horizontal: ancho_in -> 64 */
    uint8_t *dst = anillo[renglon_actual % PRE_KMAX];
    if (ancho_in == PRE_SALIDA) {
        memcpy(dst, px, PRE_SALIDA);
    } else {
        for (int xx = 0; xx < PRE_SALIDA; xx++) {
            const int32_t *k = &coef[xx * PRE_KMAX];
            const uint8_t *src = &px[xmin_t[xx]];
            int32_t s = 1 << (BITS_PRECISION - 1);
            if ((xx & 7) == 0) {
                hal_uart_sondear();
            }
            for (int i = 0; i < xn_t[xx]; i++) {
                s += (int32_t)src[i] * k[i];
            }
            dst[xx] = recortar8(s);
        }
    }

    /* 2b) Pasada vertical para todas las salidas que ya tienen sus renglones */
    while (siguiente_salida < PRE_SALIDA) {
        int ultimo = (alto_in == PRE_SALIDA) ? siguiente_salida
                                             : ymin_t[siguiente_salida] + yn_t[siguiente_salida] - 1;
        if (ultimo > renglon_actual) {
            break;
        }
        pasada_vertical(siguiente_salida++);
    }
    renglon_actual++;
}

int preproc_terminar(uint8_t *salida)
{
    if (renglon_actual != alto_in || siguiente_salida != PRE_SALIDA) {
        return -1;
    }
    memcpy(salida, salida_u8, sizeof(salida_u8));
    return 0;
}
