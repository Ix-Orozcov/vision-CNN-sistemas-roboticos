/*
 * preproc.h - Preprocesamiento de la imagen en streaming.
 *
 * La foto de 320 x 320 no cabe completa en la RAM del micro junto con la CNN y su entrenamiento,
 * así que se procesa renglón por renglón mientras llega por la UART:
 *
 *   1. Escala de grises (si llega en RGB), con la misma fórmula que PIL convert("L").
 *   2. Redimensionado a 64 x 64 con filtro Lanczos, réplica bit a bit de
 *      PIL Image.resize(..., Image.LANCZOS) usado en el entrenamiento.
 *   3. Normalización a [0, 1] (en float para el entrenamiento) o cuantización a INT8
 *      con la escala y punto cero de la entrada de cada modelo (tabla de 256 valores).
 */
#ifndef PREPROC_H
#define PREPROC_H

#include <stdint.h>


/* Prepara el redimensionado para una imagen de ancho x alto con 1 o 3 canales. */
int      preproc_comenzar(int ancho, int alto, int canales);

/* Procesa el siguiente renglón recibido (ancho * canales bytes). */
void     preproc_renglon(const uint8_t *renglon);

/* Termina y deja la imagen 64 x 64 en gris (uint8) en 'salida'. */
int      preproc_terminar(uint8_t *salida);

/* Normalización + cuantización: tabla de 256 valores para una escala/punto cero dados */
void     preproc_crear_tabla(float escala, int32_t zp, int8_t *tabla);
void     preproc_cuantizar(const uint8_t *imagen, const int8_t *tabla, int8_t *salida);

uint32_t preproc_ram_bytes(void);

#endif
