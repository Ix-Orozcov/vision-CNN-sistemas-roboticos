/*
 * protocolo.c - Tramas con sincronía y CRC-16/CCITT-FALSE (polinomio 0x1021, inicio 0xFFFF).
 */
#include <string.h>
#include "protocolo.h"
#include "hal.h"

static uint16_t crc_rx, crc_tx;

/* CRC-16/CCITT-FALSE con tabla (unas 10 veces más rápido que bit por bit: importa
 * porque se calcula sobre cada renglón de la foto mientras llega el siguiente). */
static uint16_t tabla_crc[256];
static int      tabla_crc_lista;

static void crear_tabla_crc(void)
{
    for (int b = 0; b < 256; b++) {
        uint16_t crc = (uint16_t)(b << 8);
        for (int i = 0; i < 8; i++) {
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
        }
        tabla_crc[b] = crc;
    }
    tabla_crc_lista = 1;
}

static uint16_t crc16(uint16_t crc, const uint8_t *d, uint32_t n)
{
    if (!tabla_crc_lista) {
        crear_tabla_crc();
    }
    while (n--) {
        crc = (uint16_t)((crc << 8) ^ tabla_crc[((crc >> 8) ^ *d++) & 0xFFu]);
        if ((n & 63u) == 0u) {
            hal_uart_sondear();
        }
    }
    return crc;
}

void put_u16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
void put_u32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
void put_f32(uint8_t *p, float v) { uint32_t u; memcpy(&u, &v, 4); put_u32(p, u); }
uint16_t get_u16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
uint32_t get_u32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

int prt_enviar_inicio(uint8_t tipo, uint32_t len)
{
    uint8_t cab[7] = { PRT_SINC0, PRT_SINC1, tipo };
    put_u32(&cab[3], len);
    crc_tx = crc16(0xFFFF, &cab[2], 5);
    return hal_uart_escribir(cab, 7);
}

int prt_enviar_parte(const uint8_t *datos, uint32_t n)
{
    if (n == 0) return 0;
    crc_tx = crc16(crc_tx, datos, n);
    return hal_uart_escribir(datos, n);
}

int prt_enviar_fin(void)
{
    uint8_t fin[2];
    put_u16(fin, crc_tx);
    return hal_uart_escribir(fin, 2);
}

int prt_enviar(uint8_t tipo, const uint8_t *datos, uint32_t len)
{
    if (prt_enviar_inicio(tipo, len) != 0) return -1;
    if (prt_enviar_parte(datos, len) != 0) return -1;
    return prt_enviar_fin();
}

static int leer_crudo(uint8_t *d, uint32_t n, uint32_t timeout_us)
{
    if (hal_uart_rx_iniciar(d, n) != 0) return -1;
    return hal_uart_rx_esperar(timeout_us);
}

int prt_recibir_cabecera(uint8_t *tipo, uint32_t *len, uint32_t timeout_us)
{
    uint8_t b = 0, previo = 0;
    /* Buscar los bytes de sincronía (descarta basura si se perdió una trama) */
    for (int intentos = 0; intentos < 4096; intentos++) {
        if (leer_crudo(&b, 1, timeout_us) != 0) return -1;
        if (previo == PRT_SINC0 && b == PRT_SINC1) {
            uint8_t cab[5];
            if (leer_crudo(cab, 5, timeout_us) != 0) return -1;
            *tipo = cab[0];
            *len = get_u32(&cab[1]);
            crc_rx = crc16(0xFFFF, cab, 5);
            return 0;
        }
        previo = b;
    }
    return -1;
}

void prt_acumular_crc(const uint8_t *datos, uint32_t n)
{
    crc_rx = crc16(crc_rx, datos, n);
}

int prt_leer(uint8_t *destino, uint32_t n, uint32_t timeout_us)
{
    if (leer_crudo(destino, n, timeout_us) != 0) return -1;
    prt_acumular_crc(destino, n);
    return 0;
}

int prt_verificar_crc(uint32_t timeout_us)
{
    uint8_t fin[2];
    if (leer_crudo(fin, 2, timeout_us) != 0) return -1;
    return (get_u16(fin) == crc_rx) ? 0 : -2;
}
