/*
 * protocolo.h - Mensajes binarios entre el S32K344 y el puente de la PC.
 *
 * Trama:  0xA5 0x5A | tipo (1) | longitud (4, LE) | datos | CRC-16/CCITT (2, LE)
 * El CRC cubre tipo + longitud + datos. Todos los números son little-endian.
 *
 * El micro siempre pregunta (PEDIR_FOTO / PEDIR_ODOM, con un número de secuencia
 * u32) y la PC responde con lo que toque hacer: una foto, una muestra de
 * entrenamiento, los encoders o un comando. La respuesta repite la secuencia (campo
 * "id" de FOTO/MUESTRA/ODOM, bytes 4-7 de COMANDO); el micro descarta las que no
 * coinciden, así los mensajes atrasados o duplicados no desordenan la comunicación.
 *
 * Micro -> PC                              PC -> Micro
 *   HOLA        (datos del firmware)         ACK      (1 byte de estado)
 *   PEDIR_FOTO  (sin datos)                  FOTO     (cabecera + píxeles)
 *   PEDIR_ODOM  (sin datos)                  MUESTRA  (cabecera con etiqueta + píxeles)
 *   MOTORES     (comandos + telemetría)      ODOM     (encoders)
 *   ENTRENO     (resultado de un paso)       COMANDO  (instrucción para el micro)
 *   RESULTADO   (respuesta a un comando)     ACK
 *
 * Esta definición debe coincidir con pc/protocolo.py.
 */
#ifndef PROTOCOLO_H
#define PROTOCOLO_H

#include <stdint.h>

#define PRT_SINC0          0xA5
#define PRT_SINC1          0x5A

#define MSG_HOLA           0x01
#define MSG_PEDIR_FOTO     0x02
#define MSG_PEDIR_ODOM     0x03
#define MSG_MOTORES        0x04
#define MSG_ENTRENO        0x05
#define MSG_RESULTADO      0x06
#define MSG_ACK            0x81
#define MSG_FOTO           0x82
#define MSG_ODOM           0x83
#define MSG_MUESTRA        0x84
#define MSG_COMANDO        0x85

/* Comandos: COMANDO = [cmd][0][0][0][secuencia u32][datos...] */
#define CMD_CONFIG_ROBOT   1   /* f32 radio, f32 eje, f32 w_max: geometría del robot     */
#define CMD_INICIAR_PESOS  2   /* u32 semilla: pesos aleatorios (Glorot)                 */
#define CMD_USAR_MODELO    3   /* u8 modelo: 0 INT8 de la PC, 1 float del micro, 2 INT8 del micro */
#define CMD_CALIBRAR       4   /* empezar a medir rangos de activación                   */
#define CMD_CUANTIZAR      5   /* cuantizar a INT8 los pesos entrenados en el micro      */
#define CMD_SUBIR_PESOS    6   /* mandar a la PC todos los pesos float                   */
#define CMD_CARGAR_PESOS   7   /* u32 bloque + floats: recibir un bloque de pesos de la PC */

#define MODELO_PC_INT8     0
#define MODELO_MCU_FLOAT   1
#define MODELO_MCU_INT8    2

#define BANDERA_REINICIO   0x01   /* inicio de una corrida: reiniciar estado y odometría */
#define BANDERA_EVALUACION 0x02   /* solo clasificar (modo evaluación), sin mover        */

#define LEN_CABECERA_FOTO  24   /* FOTO y MUESTRA; los últimos 4 bytes: rumbo del IMU (f32) */
#define LEN_ODOM           20   /* incluye el rumbo del IMU (f32) al final              */
#define LEN_HOLA           40
#define LEN_MOTORES        72
#define LEN_ENTRENO        48
#define LEN_RESULTADO_CAB  8

typedef struct {
    uint8_t  banderas;
    uint8_t  canales;
    uint16_t ancho, alto;
    uint16_t dist_mm;            /* sensor de distancia frontal (mm); 0xFFFF = sin dato */
    int32_t  enc_izq, enc_der;
    uint32_t id;
    float    rumbo;              /* giroscopio (rad); NAN = sin IMU */
} cabecera_foto_t;

int prt_enviar(uint8_t tipo, const uint8_t *datos, uint32_t len);

/* Envío por partes (para mensajes grandes como los pesos) */
int prt_enviar_inicio(uint8_t tipo, uint32_t len);
int prt_enviar_parte(const uint8_t *datos, uint32_t n);
int prt_enviar_fin(void);

/* Recepción por partes: cabecera, datos (en uno o varios trozos) y CRC al final */
int prt_recibir_cabecera(uint8_t *tipo, uint32_t *len, uint32_t timeout_us);
int prt_leer(uint8_t *destino, uint32_t n, uint32_t timeout_us);
void prt_acumular_crc(const uint8_t *datos, uint32_t n);   /* para datos leídos por fuera */
int prt_verificar_crc(uint32_t timeout_us);

/* Serialización little-endian */
void     put_u16(uint8_t *p, uint16_t v);
void     put_u32(uint8_t *p, uint32_t v);
void     put_f32(uint8_t *p, float v);
uint16_t get_u16(const uint8_t *p);
uint32_t get_u32(const uint8_t *p);

#endif
