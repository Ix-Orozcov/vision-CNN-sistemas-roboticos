/* Generado por exportar_modelo_c.py - no editar a mano. */
#ifndef CNN_MODELO_H
#define CNN_MODELO_H

#include "cnn_int8.h"

#define CNN_ENTRADA_H       64
#define CNN_ENTRADA_W       64
#define CNN_ENTRADA_C       1
#define CNN_ENTRADA_ESCALA  3.9215688594e-03f
#define CNN_ENTRADA_ZP      (-128)
#define CNN_N_CLASES        4
#define CNN_SALIDA_ESCALA   2.0074313879e-01f
#define CNN_SALIDA_ZP       (12)
#define CNN_N_CAPAS         6
#define CNN_BUF_A_BYTES     30752
#define CNN_BUF_B_BYTES     7688
#define CNN_N_PARAMETROS    51508u
#define CNN_FLASH_BYTES     51860u   /* pesos + sesgos + multiplicadores */

extern const capa_t cnn_capas[CNN_N_CAPAS];

#endif
