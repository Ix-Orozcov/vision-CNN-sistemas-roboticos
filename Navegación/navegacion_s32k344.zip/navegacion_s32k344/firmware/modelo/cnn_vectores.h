/* Generado por exportar_modelo_c.py - no editar a mano. */
#ifndef CNN_VECTORES_H
#define CNN_VECTORES_H

#include <stdint.h>
#include "cnn_modelo.h"

#define CNN_N_VECTORES 4
#if CNN_N_VECTORES > 0
extern const int8_t cnn_vec_entrada[CNN_N_VECTORES][CNN_ENTRADA_H * CNN_ENTRADA_W * CNN_ENTRADA_C];
extern const int8_t cnn_vec_logits[CNN_N_VECTORES][CNN_N_CLASES];
#endif

#endif
