/*
 * hal_pc.c - HAL para correr el MISMO firmware en la PC (pruebas sin la tarjeta).
 *
 * En lugar de la UART usa una conexión TCP al puente (puente_coppelia.py --tcp).
 * Funciona en Windows (MinGW/MSYS2) y en Linux/macOS.
 * Uso:  firmware_pc [host] [puerto]      (por defecto 127.0.0.1 5005)
 */
#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <windows.h>
   typedef SOCKET socket_t;
#  define cerrar closesocket
#  define dormir_1s() Sleep(1000)
#else
#  define _POSIX_C_SOURCE 200809L
#  include <arpa/inet.h>
#  include <netinet/in.h>
#  include <netinet/tcp.h>
#  include <sys/select.h>
#  include <sys/socket.h>
#  include <time.h>
#  include <unistd.h>
   typedef int socket_t;
#  define cerrar close
#  define dormir_1s() sleep(1)
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hal.h"

static socket_t sock;
static uint8_t *rx_destino;
static uint32_t rx_n;

void hal_iniciar(int argc, char **argv)
{
    const char *host = argc > 1 ? argv[1] : "127.0.0.1";
    int puerto = argc > 2 ? atoi(argv[2]) : 5005;
    struct sockaddr_in dir;

#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    memset(&dir, 0, sizeof(dir));
    dir.sin_family = AF_INET;
    dir.sin_port = htons((unsigned short)puerto);
    dir.sin_addr.s_addr = inet_addr(host);

    for (int intento = 0; intento < 60; intento++) {      /* esperar a que abra el puente */
        sock = socket(AF_INET, SOCK_STREAM, 0);
        if (connect(sock, (struct sockaddr *)&dir, sizeof(dir)) == 0) {
            int uno = 1;
            setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&uno, sizeof(uno));
            printf("Conectado al puente en %s:%d\n", host, puerto);
            return;
        }
        cerrar(sock);
        dormir_1s();
    }
    fprintf(stderr, "No se pudo conectar al puente.\n");
    exit(1);
}

uint32_t hal_ciclos(void)
{
#ifdef _WIN32
    static LARGE_INTEGER frec;
    LARGE_INTEGER c;
    if (frec.QuadPart == 0) QueryPerformanceFrequency(&frec);
    QueryPerformanceCounter(&c);
    return (uint32_t)((c.QuadPart * 1000000LL) / frec.QuadPart);
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint32_t)((uint64_t)ts.tv_sec * 1000000u + (uint64_t)ts.tv_nsec / 1000u);
#endif
}

uint32_t hal_ciclos_por_us(void) { return 1; }   /* en la PC el "ciclo" es 1 µs */
uint32_t hal_cpu_mhz(void)       { return 0; }   /* 0 = ejecución en PC        */

int hal_uart_escribir(const uint8_t *datos, uint32_t n)
{
    while (n > 0) {
        int k = send(sock, (const char *)datos, (int)n, 0);
        if (k <= 0) {
            fprintf(stderr, "Conexión cerrada por el puente.\n");
            exit(0);
        }
        datos += k;
        n -= (uint32_t)k;
    }
    return 0;
}

int hal_uart_rx_iniciar(uint8_t *destino, uint32_t n)
{
    rx_destino = destino;
    rx_n = n;
    return 0;
}

int hal_uart_rx_esperar(uint32_t timeout_us)
{
    while (rx_n > 0) {
        fd_set fds;
        struct timeval tv = { (long)(timeout_us / 1000000u), (long)(timeout_us % 1000000u) };
        FD_ZERO(&fds);
        FD_SET(sock, &fds);
        if (select((int)sock + 1, &fds, NULL, NULL, &tv) <= 0) {
            return -1;
        }
        int k = recv(sock, (char *)rx_destino, (int)rx_n, 0);
        if (k <= 0) {
            fprintf(stderr, "Conexión cerrada por el puente.\n");
            exit(0);
        }
        rx_destino += k;
        rx_n -= (uint32_t)k;
    }
    return 0;
}
