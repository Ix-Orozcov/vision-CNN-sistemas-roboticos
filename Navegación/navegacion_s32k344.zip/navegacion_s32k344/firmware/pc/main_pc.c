/* main_pc.c - Punto de entrada del firmware compilado para la PC. */
#include "hal.h"
#include "app.h"

int main(int argc, char **argv)
{
    hal_iniciar(argc, argv);
    app_ejecutar();
    return 0;
}
