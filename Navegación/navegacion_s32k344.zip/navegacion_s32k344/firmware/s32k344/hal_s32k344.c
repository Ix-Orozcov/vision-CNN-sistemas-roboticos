/*
 * hal_s32k344.c - HAL para el NXP S32K344 con los drivers RTD (Real-Time Drivers)
 *                 de S32 Design Studio.
 *
 * Usa:
 *   - LPUART en modo interrupción (Lpuart_Uart_Ip) para la comunicación con la PC.
 *     La recepción asíncrona permite procesar un renglón de la foto mientras llega
 *     el siguiente sin perder bytes.
 *   - El contador de ciclos DWT del Cortex-M7 para medir tiempos.
 *
 * IMPORTANTE: los nombres marcados con "AJUSTAR" los genera S32 Config Tools y
 * dependen de tu proyecto (instancia de LPUART, versión de RTD, nombre del
 * contenedor de pines). Revisa los archivos generados en la carpeta "generate/"
 * (Clock_Ip_PBcfg.h, Lpuart_Uart_Ip_PBcfg.h, Siul2_Port_Ip_Cfg.h) y corrígelos.
 */
#include "hal.h"
#include "Clock_Ip.h"
#include "IntCtrl_Ip.h"
#include "Lpuart_Uart_Ip.h"
#include "Siul2_Port_Ip.h"

/* ---------------- AJUSTAR según tu configuración ---------------- */
#define UART_INSTANCIA       6u                          /* LPUART usado (p. ej. LPUART6)  */
#define UART_IRQ             LPUART6_IRQn
#define UART_ISR             LPUART_UART_IP_6_IRQHandler
#define UART_CONFIG          (&Lpuart_Uart_Ip_xHwConfigPB_6)
#define PINES_N              NUM_OF_CONFIGURED_PINS_PortContainer_0_BOARD_InitPeripherals
#define PINES_CONFIG         g_pin_mux_InitConfigArr_PortContainer_0_BOARD_InitPeripherals
#define RELOJ_CPU_MHZ        160u                        /* CORE_CLK configurado (máx. 160) */
/* ----------------------------------------------------------------- */

/* Registros del DWT / CoreDebug (direcciones estándar de ARMv7-M) */
#define DEMCR       (*(volatile uint32_t *)0xE000EDFCu)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000u)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004u)
#define DWT_LAR     (*(volatile uint32_t *)0xE0001FB0u)

extern void UART_ISR(void);

void hal_iniciar(int argc, char **argv)
{
    (void)argc;
    (void)argv;

    /* Relojes, pines y UART (configurados en S32 Config Tools) */
    Clock_Ip_Init(&Clock_Ip_aClockConfig[0]);
    Siul2_Port_Ip_Init(PINES_N, PINES_CONFIG);
    IntCtrl_Ip_InstallHandler(UART_IRQ, UART_ISR, NULL_PTR);
    IntCtrl_Ip_EnableIrq(UART_IRQ);
    Lpuart_Uart_Ip_Init(UART_INSTANCIA, UART_CONFIG);

    /* Contador de ciclos */
    DEMCR |= (1u << 24);          /* TRCENA */
    DWT_LAR = 0xC5ACCE55u;        /* desbloqueo (necesario en algunos Cortex-M7) */
    DWT_CYCCNT = 0u;
    DWT_CTRL |= 1u;               /* CYCCNTENA */
}

uint32_t hal_ciclos(void)        { return DWT_CYCCNT; }
uint32_t hal_ciclos_por_us(void) { return RELOJ_CPU_MHZ; }
uint32_t hal_cpu_mhz(void)       { return RELOJ_CPU_MHZ; }

int hal_uart_escribir(const uint8_t *datos, uint32_t n)
{
    /* Tiempo máximo: 10 bits por byte a 115200 baudios como peor caso, en µs */
    uint32_t timeout_us = 100u * n + 10000u;
    return (Lpuart_Uart_Ip_SyncSend(UART_INSTANCIA, datos, n, timeout_us) ==
            LPUART_UART_IP_STATUS_SUCCESS) ? 0 : -1;
}

int hal_uart_rx_iniciar(uint8_t *destino, uint32_t n)
{
    return (Lpuart_Uart_Ip_AsyncReceive(UART_INSTANCIA, destino, n) ==
            LPUART_UART_IP_STATUS_SUCCESS) ? 0 : -1;
}

int hal_uart_rx_esperar(uint32_t timeout_us)
{
    uint32_t restantes;
    uint32_t c0 = hal_ciclos();
    while (Lpuart_Uart_Ip_GetReceiveStatus(UART_INSTANCIA, &restantes) == LPUART_UART_IP_STATUS_BUSY) {
        if (hal_us_desde(c0, hal_ciclos()) > timeout_us) {
            Lpuart_Uart_Ip_AbortReceivingData(UART_INSTANCIA);
            return -1;
        }
    }
    return (Lpuart_Uart_Ip_GetReceiveStatus(UART_INSTANCIA, &restantes) ==
            LPUART_UART_IP_STATUS_SUCCESS) ? 0 : -1;
}
