/*
 * main.c - Punto de entrada en el S32K344.
 *
 * Reemplaza el main.c que crea S32 Design Studio por este archivo.
 */
#include "hal.h"
#include "app.h"

int main(void)
{
    hal_iniciar(0, 0);
    app_ejecutar();          /* no regresa */
    for (;;) {
    }
    return 0;
}
