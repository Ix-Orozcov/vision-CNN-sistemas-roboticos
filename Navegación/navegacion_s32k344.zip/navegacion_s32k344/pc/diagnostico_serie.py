"""
diagnostico_serie.py - Muestra en hexadecimal los bytes crudos que manda el micro.

Sirve para ver si las tramas llegan completas. Cada trama del micro empieza con
A5 5A; el saludo (HOLA) del micro se ve así:

    A5 5A 01 28 00 00 00  <40 bytes de datos>  <2 bytes de CRC>
    |sinc| |  longitud=40  |

Uso (cierra antes el puente; el puerto no se puede abrir dos veces):
    python diagnostico_serie.py COM4 115200
Reinicia el micro (botón RESET o "Resume" en el depurador) mientras corre.
"""
import sys
import time

import serial

from protocolo import crc16


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return
    puerto, baudios = sys.argv[1], int(sys.argv[2])
    s = serial.Serial(puerto, baudios, timeout=0.1)
    s.reset_input_buffer()
    print(f"Escuchando {puerto} a {baudios} baudios durante 25 s...\n")
    datos = bytearray()
    fin = time.monotonic() + 25
    while time.monotonic() < fin:
        b = s.read(256)
        if b:
            t = 25 - (fin - time.monotonic())
            print(f"[{t:5.2f} s] {len(b):3d} B: " + " ".join(f"{x:02X}" for x in b))
            datos += b
    s.close()

    print(f"\nTotal recibido: {len(datos)} bytes")
    i = datos.find(b"\xA5\x5A")
    if i < 0:
        print("No apareció ningún A5 5A: velocidad distinta o pines/LPUART equivocados.")
        return
    while i >= 0 and i + 7 <= len(datos):
        tipo = datos[i + 2]
        n = int.from_bytes(datos[i + 3:i + 7], "little")
        trama = datos[i + 2:i + 7 + n]
        crc_ok = None
        if n < 10000 and i + 9 + n <= len(datos):
            crc = int.from_bytes(datos[i + 7 + n:i + 9 + n], "little")
            crc_ok = (crc == crc16(bytes(trama)))
        estado = "incompleta" if crc_ok is None else ("CRC correcto" if crc_ok else "CRC INCORRECTO")
        print(f"  trama en byte {i}: tipo {tipo}, longitud {n} -> {estado}")
        i = datos.find(b"\xA5\x5A", i + 2)


if __name__ == "__main__":
    main()
