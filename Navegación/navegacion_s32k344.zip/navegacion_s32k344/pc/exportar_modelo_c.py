"""
Convierte modelo_int8.tflite (generado por cuantizar_cnn.py) en código C para el S32K344.

Genera en firmware/modelo/:
    cnn_modelo.h / cnn_modelo.c     pesos INT8, sesgos y multiplicadores de punto fijo
    cnn_vectores.h / cnn_vectores.c imágenes de prueba con su salida esperada
                                    (el micro las verifica al arrancar)

Además comprueba que la implementación en C (simulada aquí en numpy, con la misma
aritmética entera) da EXACTAMENTE la misma salida que el intérprete de TensorFlow Lite.

Uso:
    python exportar_modelo_c.py --tflite ruta/modelo_int8.tflite --test ruta/dataset/test
Requisitos:
    pip install tensorflow pillow numpy
"""
import argparse
import math
from pathlib import Path

import numpy as np
from PIL import Image

CLASES = ["avanzar", "izquierda", "derecha", "obstaculo"]
EXTENSIONES = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
TAM = 64


# ============================================================
# 1) LECTURA DEL MODELO TFLITE
# ============================================================
def _cuant(t):
    q = t["quantization_parameters"]
    return np.asarray(q["scales"], dtype=np.float32), np.asarray(q["zero_points"], dtype=np.int64)


def leer_tflite(ruta):
    """Devuelve un diccionario con la descripción de cada capa del modelo INT8."""
    try:
        import tensorflow as tf
        Interpreter, Resolver = tf.lite.Interpreter, tf.lite.experimental.OpResolverType
    except (ImportError, AttributeError):              # versiones nuevas: paquete LiteRT
        from ai_edge_litert.interpreter import Interpreter, OpResolverType as Resolver
    # Kernels de referencia (aritmética exacta) y conservar los tensores intermedios
    # para poder leer los logits antes del softmax.
    try:
        interp = Interpreter(model_path=str(ruta), experimental_preserve_all_tensors=True,
                             experimental_op_resolver_type=Resolver.BUILTIN_REF)
    except Exception:
        interp = Interpreter(model_path=str(ruta), experimental_preserve_all_tensors=True)
    interp.allocate_tensors()
    tensores = {t["index"]: t for t in interp.get_tensor_details()}
    ops = interp._get_ops_details()

    ent = interp.get_input_details()[0]
    if ent["dtype"] != np.int8:
        raise ValueError("La entrada del modelo no es INT8. Usa modelo_int8.tflite.")
    e_s, e_zp = _cuant(ent)
    _, h, w, c = ent["shape"]
    modelo = {"entrada": dict(h=int(h), w=int(w), c=int(c), escala=float(e_s[0]), zp=int(e_zp[0])),
              "capas": [], "clases": CLASES}

    def forma(i):
        s = list(tensores[i]["shape"])
        return tuple(int(v) for v in (s[1:] if len(s) == 4 else [1, 1, s[-1]]))

    ultima_logits = None
    omitidas = set()
    for op in ops:
        nombre = op["op_name"]
        ins, outs = list(op["inputs"]), list(op["outputs"])
        if nombre in ("CONV_2D", "FULLY_CONNECTED"):
            x_s, x_zp = _cuant(tensores[ins[0]])
            w_s, w_zp = _cuant(tensores[ins[1]])
            y_s, y_zp = _cuant(tensores[outs[0]])
            if np.any(w_zp != 0):
                raise ValueError("Se esperaban pesos simétricos (punto cero 0).")
            pesos = interp.get_tensor(ins[1]).astype(np.int8)
            sesgo = (interp.get_tensor(ins[2]).astype(np.int64) if len(ins) > 2 and ins[2] >= 0
                     else np.zeros(pesos.shape[0], np.int64))
            capa = dict(w=pesos, b=sesgo, in_zp=int(x_zp[0]), in_escala=float(x_s[0]),
                        w_escalas=w_s, out_zp=int(y_zp[0]), out_escala=float(y_s[0]),
                        in_hwc=forma(ins[0]), out_hwc=forma(outs[0]))
            if nombre == "CONV_2D":
                k = pesos.shape[1]
                if capa["out_hwc"][0] != capa["in_hwc"][0] - k + 1:
                    raise ValueError("Solo se admite Conv2D con padding 'valid' y paso 1.")
                capa.update(tipo="conv", k=k)
            else:
                n_in = pesos.shape[1]
                capa.update(tipo="fc", k=1, in_hwc=(1, 1, n_in), out_hwc=(1, 1, pesos.shape[0]))
                ultima_logits = capa
            modelo["capas"].append(capa)
        elif nombre == "MAX_POOL_2D":
            a_s, a_zp = _cuant(tensores[ins[0]])
            b_s, b_zp = _cuant(tensores[outs[0]])
            if a_zp[0] != b_zp[0] or not np.isclose(a_s[0], b_s[0]):
                raise ValueError("MaxPool con cuantización distinta en entrada y salida.")
            ih, oh = forma(ins[0]), forma(outs[0])
            k = ih[0] // oh[0]
            modelo["capas"].append(dict(tipo="maxpool", k=k, in_hwc=ih, out_hwc=oh,
                                        out_zp=int(b_zp[0])))
        elif nombre == "RESHAPE":
            continue                           # Flatten: no cambia la memoria (NHWC)
        elif nombre == "SOFTMAX":
            continue                           # se calcula en float en el micro
        elif all(tensores[o]["dtype"] != np.int8 for o in outs):
            # Keras 3 implementa Flatten calculando la forma en tiempo de ejecución
            # (SHAPE, STRIDED_SLICE, PACK...). Esas operaciones solo trabajan con enteros
            # de forma, no con la imagen, así que el micro no las necesita.
            omitidas.add(nombre)
            continue
        else:
            raise ValueError(f"Operación no soportada por el motor en C: {nombre}")

    if omitidas:
        print(f"Operaciones de cálculo de forma omitidas (no afectan la imagen): {', '.join(sorted(omitidas))}")
    tipos = [c["tipo"] for c in modelo["capas"]]
    if tipos != ["conv", "maxpool", "conv", "maxpool", "fc", "fc"]:
        raise ValueError(f"La red no tiene la arquitectura esperada: {tipos}")

    # ReLU fusionada en todas las capas salvo la de salida
    for c in modelo["capas"]:
        c["relu"] = c["tipo"] in ("conv", "fc") and c is not ultima_logits
    s = modelo["capas"][-1]
    modelo["salida"] = dict(escala=s["out_escala"], zp=s["out_zp"], n=s["out_hwc"][2])
    if modelo["salida"]["n"] != len(CLASES):
        raise ValueError(f"El modelo tiene {modelo['salida']['n']} clases; se esperaban 4.")
    return modelo, interp


# ============================================================
# 2) PARÁMETROS DE PUNTO FIJO (igual que TensorFlow Lite)
# ============================================================
def _redondear(v):
    return math.floor(abs(v) + 0.5) * (1 if v >= 0 else -1)   # std::round


def quantize_multiplier(real):
    if real == 0.0:
        return 0, 0
    q, desp = math.frexp(real)
    q_fijo = _redondear(q * (1 << 31))
    if q_fijo == (1 << 31):
        q_fijo //= 2
        desp += 1
    if desp < -31:
        return 0, 0
    if desp > 30:
        return (1 << 31) - 1, 30
    return int(q_fijo), int(desp)


def preparar_capas(modelo, fc_producto_float32=True):
    """Calcula multiplicadores, desplazamientos, sesgo corregido y límites de activación.
    fc_producto_float32: en capas densas por tensor, algunas versiones de TFLite multiplican
    las escalas en float32 y otras en double; el programa principal prueba ambas."""
    for c in modelo["capas"]:
        if c["tipo"] == "maxpool":
            c.update(act_min=-128, act_max=127)
            continue
        n_out = c["w"].shape[0]
        ws = c["w_escalas"]
        por_canal = ws.size > 1
        if c["tipo"] == "fc" and not por_canal and fc_producto_float32:
            reales = [float(np.float32(c["in_escala"]) * np.float32(ws[0])) / float(np.float32(c["out_escala"]))]
        else:
            reales = [float(np.float32(c["in_escala"])) * float(np.float32(s)) / float(np.float32(c["out_escala"]))
                      for s in ws]
        mult, desp = zip(*[quantize_multiplier(r) for r in reales])
        c["mult"] = np.array(mult, np.int64)
        c["desp"] = np.array(desp, np.int64)
        c["por_canal"] = por_canal
        suma_w = c["w"].reshape(n_out, -1).astype(np.int64).sum(axis=1)
        c["b_ef"] = c["b"] - c["in_zp"] * suma_w       # se pliega el punto cero de entrada
        if np.any(np.abs(c["b_ef"]) > 2**31 - 1):
            raise ValueError("El sesgo corregido no cabe en int32.")
        c["act_min"] = max(-128, c["out_zp"]) if c["relu"] else -128
        c["act_max"] = 127
    return modelo


# ============================================================
# 3) REFERENCIA EN NUMPY (misma aritmética que cnn_int8.c)
# ============================================================
def _srdhm(a, b):
    ab = a.astype(np.int64) * b.astype(np.int64)
    s = ab + np.where(ab >= 0, 1 << 30, 1 - (1 << 30))
    return np.where(s >= 0, s >> 31, -((-s) >> 31))


def _rdbpot(x, e):
    mascara = (np.int64(1) << e) - 1
    resto = x & mascara
    umbral = (mascara >> 1) + (x < 0)
    return (x >> e) + (resto > umbral)


def _reescalar(acc, mult, desp):
    izq = np.maximum(desp, 0)
    der = np.maximum(-desp, 0)
    x = ((acc << izq) + 2**31) % 2**32 - 2**31          # desbordamiento como int32
    return _rdbpot(_srdhm(x, mult), der)


def inferir_referencia(modelo, x):
    """x: entrada int8 (H, W, C). Devuelve los logits int8 de la última capa."""
    x = x.astype(np.int64)
    for c in modelo["capas"]:
        if c["tipo"] == "conv":
            k = c["k"]
            v = np.lib.stride_tricks.sliding_window_view(x, (k, k, x.shape[2]))
            oh, ow = v.shape[:2]
            parches = v.reshape(oh * ow, -1)
            acc = parches @ c["w"].reshape(c["w"].shape[0], -1).astype(np.int64).T + c["b_ef"]
            y = _reescalar(acc, c["mult"], c["desp"]) + c["out_zp"]
            x = np.clip(y, c["act_min"], c["act_max"]).reshape(oh, ow, -1)
        elif c["tipo"] == "maxpool":
            k = c["k"]
            oh, ow, ch = c["out_hwc"]
            x = x[:oh * k, :ow * k].reshape(oh, k, ow, k, ch).max(axis=(1, 3))
        else:
            acc = x.reshape(-1) @ c["w"].astype(np.int64).T + c["b_ef"]
            y = _reescalar(acc, c["mult"], c["desp"]) + c["out_zp"]
            x = np.clip(y, c["act_min"], c["act_max"])
    return x.reshape(-1).astype(np.int8)


def cuantizar_entrada(modelo, img_u8):
    """Igual que preproc.c: píxel/255 -> int8 con la escala y punto cero de la entrada."""
    e = modelo["entrada"]
    tabla = np.clip(np.array([_redondear(float(np.float32(np.float32(p) / np.float32(255.0))
                                                / np.float32(e["escala"])))
                              for p in range(256)]) + e["zp"], -128, 127).astype(np.int8)
    return tabla[img_u8].reshape(e["h"], e["w"], e["c"])


def cargar_imagen_u8(ruta):
    """Mismo preprocesamiento que el entrenamiento y que el micro: gris + Lanczos a 64x64."""
    with Image.open(ruta) as img:
        g = img.convert("L")
        if g.size != (TAM, TAM):
            g = g.resize((TAM, TAM), Image.LANCZOS)
        return np.asarray(g, dtype=np.uint8)


# ============================================================
# 4) GENERACIÓN DE CÓDIGO C
# ============================================================
def _arreglo(tipo, nombre, valores, por_linea=16):
    v = [str(int(x)) for x in np.asarray(valores).reshape(-1)]
    lineas = [", ".join(v[i:i + por_linea]) for i in range(0, len(v), por_linea)]
    return f"const {tipo} {nombre}[{len(v)}] = {{\n    " + ",\n    ".join(lineas) + "\n};\n"


def generar_c(modelo, carpeta, vectores=None):
    carpeta = Path(carpeta)
    carpeta.mkdir(parents=True, exist_ok=True)
    capas = modelo["capas"]
    e, s = modelo["entrada"], modelo["salida"]

    tam = [int(np.prod(c["out_hwc"])) for c in capas]
    buf_a = max([t for i, t in enumerate(tam) if i % 2 == 0] + [1])
    buf_b = max([t for i, t in enumerate(tam) if i % 2 == 1] + [1])
    n_param, flash = 0, 0
    cuerpo, tabla = [], []
    for i, c in enumerate(capas):
        ih, iw, ic = c["in_hwc"]
        oh, ow, oc = c["out_hwc"]
        if c["tipo"] == "maxpool":
            tabla.append(f"    {{ CAPA_MAXPOOL, {c['k']}, 0, 0, {ih}, {iw}, {ic}, {oh}, {ow}, {oc}, "
                         f"{c['out_zp']}, {c['act_min']}, {c['act_max']}, 0, 0, 0, 0 }},")
            continue
        p = f"capa{i}"
        cuerpo += [_arreglo("int8_t", f"{p}_w", c["w"]), _arreglo("int32_t", f"{p}_b", c["b_ef"]),
                   _arreglo("int32_t", f"{p}_mult", c["mult"]), _arreglo("int8_t", f"{p}_desp", c["desp"])]
        n_param += c["w"].size + c["b"].size
        flash += c["w"].size + 4 * c["b"].size + 4 * c["mult"].size + c["desp"].size
        tipo = "CAPA_CONV" if c["tipo"] == "conv" else "CAPA_FC"
        tabla.append(f"    {{ {tipo}, {c['k']}, {int(c['por_canal'])}, 0, {ih}, {iw}, {ic}, {oh}, {ow}, {oc}, "
                     f"{c['out_zp']}, {c['act_min']}, {c['act_max']}, {p}_w, {p}_b, {p}_mult, {p}_desp }},")

    h = f"""/* Generado por exportar_modelo_c.py - no editar a mano. */
#ifndef CNN_MODELO_H
#define CNN_MODELO_H

#include "cnn_int8.h"

#define CNN_ENTRADA_H       {e['h']}
#define CNN_ENTRADA_W       {e['w']}
#define CNN_ENTRADA_C       {e['c']}
#define CNN_ENTRADA_ESCALA  {e['escala']:.10e}f
#define CNN_ENTRADA_ZP      ({e['zp']})
#define CNN_N_CLASES        {s['n']}
#define CNN_SALIDA_ESCALA   {s['escala']:.10e}f
#define CNN_SALIDA_ZP       ({s['zp']})
#define CNN_N_CAPAS         {len(capas)}
#define CNN_BUF_A_BYTES     {buf_a}
#define CNN_BUF_B_BYTES     {buf_b}
#define CNN_N_PARAMETROS    {n_param}u
#define CNN_FLASH_BYTES     {flash}u   /* pesos + sesgos + multiplicadores */

extern const capa_t cnn_capas[CNN_N_CAPAS];

#endif
"""
    cc = ("/* Generado por exportar_modelo_c.py - no editar a mano. */\n"
          "#include \"cnn_modelo.h\"\n\n" + "\n".join(cuerpo) +
          "\nconst capa_t cnn_capas[CNN_N_CAPAS] = {\n" + "\n".join(tabla) + "\n};\n")
    (carpeta / "cnn_modelo.h").write_text(h, encoding="utf-8")
    (carpeta / "cnn_modelo.c").write_text(cc, encoding="utf-8")

    # Vectores de prueba
    vectores = vectores or []
    hv = f"""/* Generado por exportar_modelo_c.py - no editar a mano. */
#ifndef CNN_VECTORES_H
#define CNN_VECTORES_H

#include <stdint.h>
#include "cnn_modelo.h"

#define CNN_N_VECTORES {len(vectores)}
#if CNN_N_VECTORES > 0
extern const int8_t cnn_vec_entrada[CNN_N_VECTORES][CNN_ENTRADA_H * CNN_ENTRADA_W * CNN_ENTRADA_C];
extern const int8_t cnn_vec_logits[CNN_N_VECTORES][CNN_N_CLASES];
#endif

#endif
"""
    cv = "/* Generado por exportar_modelo_c.py - no editar a mano. */\n#include \"cnn_vectores.h\"\n"
    if vectores:
        def bloque(arr):
            v = [str(int(x)) for x in arr.reshape(-1)]
            return "    { " + ",\n      ".join(", ".join(v[i:i + 24]) for i in range(0, len(v), 24)) + " }"
        cv += ("\nconst int8_t cnn_vec_entrada[CNN_N_VECTORES][CNN_ENTRADA_H * CNN_ENTRADA_W * CNN_ENTRADA_C] = {\n"
               + ",\n".join(bloque(x) for x, _ in vectores) + "\n};\n")
        cv += ("\nconst int8_t cnn_vec_logits[CNN_N_VECTORES][CNN_N_CLASES] = {\n"
               + ",\n".join(bloque(y) for _, y in vectores) + "\n};\n")
    (carpeta / "cnn_vectores.h").write_text(hv, encoding="utf-8")
    (carpeta / "cnn_vectores.c").write_text(cv, encoding="utf-8")
    return dict(parametros=n_param, flash=flash, ram=buf_a + buf_b)


# ============================================================
# 5) PROGRAMA PRINCIPAL
# ============================================================
def main():
    raiz = Path(__file__).resolve().parent.parent
    p = argparse.ArgumentParser(description="Exporta modelo_int8.tflite a C para el S32K344.")
    p.add_argument("--tflite", required=True, help="ruta a modelo_int8.tflite")
    p.add_argument("--test", help="carpeta test/ (con subcarpetas por clase) para verificar")
    p.add_argument("--salida", default=str(raiz / "firmware" / "modelo"))
    p.add_argument("--n-verificar", type=int, default=200, help="imágenes de test a comparar")
    args = p.parse_args()

    modelo, interp = leer_tflite(args.tflite)
    preparar_capas(modelo)
    print("Capas del modelo:")
    for i, c in enumerate(modelo["capas"]):
        extra = f" por_canal={c.get('por_canal', '-')}" if c["tipo"] != "maxpool" else ""
        print(f"  {i}: {c['tipo']:<8} {c['in_hwc']} -> {c['out_hwc']}{extra}")

    # Imágenes para verificar (del conjunto de test, o aleatorias si no se indica)
    imagenes = []
    if args.test:
        for k, clase in enumerate(CLASES):
            rutas = sorted(r for r in (Path(args.test) / clase).iterdir() if r.suffix.lower() in EXTENSIONES)
            imagenes += [(r, k) for r in rutas]
        rng = np.random.default_rng(0)
        rng.shuffle(imagenes)
        imagenes = imagenes[:args.n_verificar]
        entradas = [(cuantizar_entrada(modelo, cargar_imagen_u8(r)), k) for r, k in imagenes]
    else:
        rng = np.random.default_rng(0)
        entradas = [(cuantizar_entrada(modelo, rng.integers(0, 256, (TAM, TAM), dtype=np.uint8)), -1)
                    for _ in range(args.n_verificar)]

    # Salida de TFLite: logits = entrada del SOFTMAX (salida de la última capa densa)
    ent = interp.get_input_details()[0]
    idx_logits = [op for op in interp._get_ops_details() if op["op_name"] == "SOFTMAX"]
    idx_logits = idx_logits[0]["inputs"][0] if idx_logits else interp.get_output_details()[0]["index"]
    logits_tfl = []
    for x, _ in entradas:
        interp.set_tensor(ent["index"], x[np.newaxis])
        interp.invoke()
        logits_tfl.append(interp.get_tensor(idx_logits).reshape(-1).astype(np.int8))

    def comparar():
        iguales, misma_clase, dif_max, aciertos = 0, 0, 0, 0
        for (x, k), ref_tfl in zip(entradas, logits_tfl):
            ref_c = inferir_referencia(modelo, x)
            d = int(np.max(np.abs(ref_tfl.astype(int) - ref_c.astype(int))))
            dif_max = max(dif_max, d)
            iguales += d == 0
            misma_clase += int(np.argmax(ref_tfl) == np.argmax(ref_c))
            aciertos += int(np.argmax(ref_c) == k)
        return iguales, misma_clase, dif_max, aciertos

    # Elegir la variante de cálculo del multiplicador que reproduce exactamente a TFLite
    resultado = comparar()
    if resultado[0] < len(entradas):
        preparar_capas(modelo, fc_producto_float32=False)
        alterno = comparar()
        if alterno[0] > resultado[0]:
            resultado = alterno
        else:
            preparar_capas(modelo, fc_producto_float32=True)
    iguales, coinciden_clase, dif_max, aciertos = resultado
    n = len(entradas)
    print(f"\nVerificación contra TensorFlow Lite ({n} imágenes):")
    print(f"  Salidas idénticas bit a bit : {iguales}/{n}")
    print(f"  Misma clase predicha        : {coinciden_clase}/{n}")
    print(f"  Diferencia máxima (LSB)     : {dif_max}")
    if args.test:
        print(f"  Accuracy de la versión en C : {aciertos / n:.4f}")
    if dif_max > 1:
        print("  ATENCIÓN: hay diferencias de más de 1 LSB; revisa la versión de TensorFlow.")

    # Vectores de prueba para el micro: una imagen por clase (o 4 aleatorias)
    vectores, vistas = [], set()
    for x, k in entradas:
        if k not in vistas or k == -1:
            vectores.append((x, inferir_referencia(modelo, x)))
            vistas.add(k)
        if len(vectores) == 4:
            break

    info = generar_c(modelo, args.salida, vectores)
    print(f"\nArchivos generados en: {args.salida}")
    print(f"  Parámetros            : {info['parametros']:,}")
    print(f"  Flash del modelo      : {info['flash'] / 1024:.1f} KB")
    print(f"  RAM de activaciones   : {info['ram'] / 1024:.1f} KB (más 4 KB de la imagen de entrada)")


if __name__ == "__main__":
    main()
