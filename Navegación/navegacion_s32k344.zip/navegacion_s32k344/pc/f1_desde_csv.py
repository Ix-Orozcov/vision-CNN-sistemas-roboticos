"""
f1_desde_csv.py - Accuracy y F1 macro de los modelos evaluados en el micro durante el
entrenamiento, a partir de las telemetrías prueba_*_telemetria.csv.

Uso:
    python f1_desde_csv.py "resultados_mcu\\20261106_125630_entrenar"
"""
import csv
import sys
from pathlib import Path

CLASES = ["avanzar", "izquierda", "derecha", "obstaculo"]
MODELOS = [("prueba_mcu_float", "Float32 (micro)"),
           ("prueba_mcu_int8", "INT8 (micro)"),
           ("prueba_pc", "INT8 (PC) en el micro")]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    carpeta = Path(sys.argv[1])
    print(f"{'Modelo':<24}{'N':>5}{'Accuracy':>10}{'Precision':>11}{'Recall':>8}{'F1 macro':>10}")
    for prefijo, nombre in MODELOS:
        ruta = carpeta / f"{prefijo}_telemetria.csv"
        if not ruta.is_file():
            print(f"{nombre:<24}  (no se encontró {ruta.name})")
            continue
        with open(ruta, encoding="utf-8") as f:
            filas = list(csv.DictReader(f))
        real = [int(r["clase_real"]) for r in filas]
        pred = [int(r["clase_pred"]) for r in filas]
        n = len(real)
        acc = sum(a == b for a, b in zip(real, pred)) / n
        ps, rs, f1s = [], [], []
        for k in range(len(CLASES)):
            tp = sum(a == k and b == k for a, b in zip(real, pred))
            fp = sum(a != k and b == k for a, b in zip(real, pred))
            fn = sum(a == k and b != k for a, b in zip(real, pred))
            p = tp / (tp + fp) if tp + fp else 0.0
            r = tp / (tp + fn) if tp + fn else 0.0
            ps.append(p)
            rs.append(r)
            f1s.append(2 * p * r / (p + r) if p + r else 0.0)
        print(f"{nombre:<24}{n:>5}{acc:>10.4f}{sum(ps) / 4:>11.4f}{sum(rs) / 4:>8.4f}{sum(f1s) / 4:>10.4f}")


if __name__ == "__main__":
    main()
