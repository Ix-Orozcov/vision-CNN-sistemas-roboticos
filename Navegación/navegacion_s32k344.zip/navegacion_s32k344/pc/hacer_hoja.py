"""
hacer_hoja.py - Arma la hoja de diagnóstico a partir de las fotos guardadas con --guardar-fotos.

Muestra, a 64x64 (lo que ve la CNN), las fotos tomadas cerca de las señales con su
clase real, la predicción del micro y la distancia. Verde = correcta, rojo = error.

Uso:
    python hacer_hoja.py "ruta\\resultados_mcu\\<fecha>_navegar\\fotos\\corrida1"
"""
import re
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

PATRON = re.compile(r"(?P<t>[\d.]+)s_real-(?P<real>\w+)_pred-(?P<pred>[\w?]+)_(?P<conf>[\d.]+)_d(?P<d>[\d.]+|sin)m?\.png")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    carpeta = Path(sys.argv[1])
    fotos = []
    for ruta in sorted(carpeta.glob("*.png")):
        m = PATRON.match(ruta.name)
        if not m:
            continue
        d = None if m["d"] == "sin" else float(m["d"])
        if m["real"] == "ninguna" and (d is None or d > 2.5):
            continue                                  # lejos de las señales
        with Image.open(ruta) as im:
            g = im.convert("L")
            if g.size != (64, 64):
                g = g.resize((64, 64), Image.LANCZOS)  # igual que el micro
            fotos.append((np.asarray(g), m))
    if not fotos:
        print("No hay fotos cerca de las señales en esa carpeta.")
        return

    idx = np.linspace(0, len(fotos) - 1, min(48, len(fotos))).round().astype(int)
    cols = 8
    filas = int(np.ceil(len(idx) / cols))
    fig, axs = plt.subplots(filas, cols, figsize=(cols * 1.9, filas * 2.4), squeeze=False)
    for a in axs.flat:
        a.axis("off")
    for a, i in zip(axs.flat, idx):
        img, m = fotos[i]
        color = "gray" if m["real"] == "ninguna" else ("green" if m["real"] == m["pred"] else "red")
        a.imshow(img, cmap="gray", vmin=0, vmax=255)
        a.set_title(f"t={float(m['t']):.1f}s d={m['d']}\nreal {m['real']}\npred {m['pred']} {m['conf']}",
                    fontsize=7, color=color)
    fig.suptitle("Lo que vio la CNN (64x64) cerca de las señales | verde = correcto, rojo = error, "
                 "gris = sin señal a la vista", fontsize=10)
    fig.tight_layout()
    salida = carpeta / "fotos_cerca_de_senales.png"
    fig.savefig(salida, dpi=120)
    print(f"Hoja guardada en: {salida}  ({len(fotos)} fotos cerca de señales, se muestran {len(idx)})")


if __name__ == "__main__":
    main()
