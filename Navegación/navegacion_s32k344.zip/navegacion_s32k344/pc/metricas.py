"""
metricas.py - Indicadores de desempeño (percepción, cómputo y navegación) y gráficas.
"""
import math

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CLASES = ["avanzar", "izquierda", "derecha", "obstaculo"]


# ============================================================
# PERCEPCIÓN
# ============================================================
def metricas_percepcion(y_real, y_pred, conf, umbral):
    y_real, y_pred, conf = np.asarray(y_real), np.asarray(y_pred), np.asarray(conf, float)
    n = len(CLASES)
    cm = np.zeros((n, n), int)
    for r, p in zip(y_real, y_pred):
        cm[r, p] += 1
    tp = np.diag(cm).astype(float)
    precision = np.divide(tp, cm.sum(0), out=np.zeros(n), where=cm.sum(0) > 0)
    recall = np.divide(tp, cm.sum(1), out=np.zeros(n), where=cm.sum(1) > 0)
    f1 = np.divide(2 * precision * recall, precision + recall, out=np.zeros(n),
                   where=(precision + recall) > 0)
    correctas = y_real == y_pred
    return dict(
        n=int(len(y_real)),
        accuracy=float(correctas.mean()) if len(y_real) else float("nan"),
        precision=precision.tolist(), recall=recall.tolist(), f1=f1.tolist(),
        precision_macro=float(precision.mean()), recall_macro=float(recall.mean()),
        f1_macro=float(f1.mean()),
        accuracy_por_clase=recall.tolist(),
        confianza_promedio=float(conf.mean()) if len(conf) else float("nan"),
        confianza_aciertos=float(conf[correctas].mean()) if correctas.any() else float("nan"),
        confianza_errores=float(conf[~correctas].mean()) if (~correctas).any() else float("nan"),
        bajo_umbral=float((conf < umbral).mean()) if len(conf) else float("nan"),
        matriz_confusion=cm.tolist(),
    )


def graficar_percepcion(m, carpeta, titulo, prefijo):
    cm = np.array(m["matriz_confusion"])
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    im = ax.imshow(cm, cmap="Blues")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    ax.set_xticks(range(4), CLASES)
    ax.set_yticks(range(4), CLASES)
    ax.set_xlabel("Predicción")
    ax.set_ylabel("Clase real")
    ax.set_title(f"Matriz de confusión ({titulo})")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(carpeta / f"{prefijo}_matriz_confusion.png", dpi=150)
    plt.close(fig)

    x = np.arange(4)
    fig, ax = plt.subplots(figsize=(9, 4.8))
    for k, (nombre, color) in enumerate([("accuracy_por_clase", "#4C72B0"), ("precision", "#55A868"),
                                         ("recall", "#C44E52"), ("f1", "#8172B2")]):
        vals = m[nombre]
        barras = ax.bar(x + (k - 1.5) * 0.2, vals, 0.2, color=color, edgecolor="black",
                        label=nombre.replace("_por_clase", " por clase").replace("f1", "F1-score"))
        for b, v in zip(barras, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.01, f"{v:.2f}", ha="center", fontsize=7)
    ax.set_xticks(x, CLASES)
    ax.set_ylim(0, 1.15)
    ax.set_title(f"Métricas por clase ({titulo}) | Accuracy = {m['accuracy']:.3f} | "
                 f"Confianza promedio = {m['confianza_promedio']:.3f}")
    ax.legend(ncol=4, fontsize=8, loc="upper center")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(carpeta / f"{prefijo}_metricas_por_clase.png", dpi=150)
    plt.close(fig)


# ============================================================
# CÓMPUTO
# ============================================================
def metricas_computo(filas, hw, corriente_ma=None, corriente_reposo_ma=None, voltaje=3.3):
    img = [f for f in filas if f["con_imagen"]]
    if not img:
        return {}

    def est(clave):
        v = np.array([f[clave] for f in img], float) / 1000.0      # ms
        return dict(media=float(v.mean()), desv=float(v.std()), p95=float(np.percentile(v, 95)),
                    max=float(v.max()))

    computo = np.array([f["t_preproc"] + f["t_inferencia"] + f["t_control"] for f in img], float)
    periodos = np.array([f["t_periodo"] for f in filas if f["t_periodo"] > 0], float)
    lat = np.array([f["t_latencia"] for f in img], float)
    carga = (computo.mean() / periodos.mean()) if len(periodos) else float("nan")

    m = dict(
        ciclos_con_imagen=len(img),
        t_captura_ms=est("t_captura"), t_preproc_ms=est("t_preproc"),
        t_inferencia_ms=est("t_inferencia"), t_control_ms=est("t_control"),
        latencia_total_ms=est("t_latencia"),
        fps_lazo=float(1e6 / lat.mean()),
        fps_solo_computo=float(1e6 / computo.mean()) if computo.mean() > 0 else float("inf"),
        carga_cpu=float(carga),
        en_pc=(hw or {}).get("cpu_mhz", 0) == 0,
    )
    if hw:
        m.update(flash_modelo_kb=hw["flash_modelo"] / 1024, ram_total_kb=hw["ram_total"] / 1024,
                 ram_pesos_kb=hw["ram_pesos"] / 1024, ram_trabajo_kb=hw["ram_trabajo"] / 1024,
                 ram_int8_mcu_kb=hw["ram_int8_mcu"] / 1024, ram_preproc_kb=hw["ram_preproc"] / 1024,
                 ram_imagen_kb=hw["ram_imagen"] / 1024,
                 n_parametros=hw["n_parametros"], cpu_mhz=hw["cpu_mhz"],
                 autoprueba={0: "FALLÓ", 1: "correcta", 2: "sin vectores"}.get(hw["autoprueba"], "?"))
    if corriente_ma:
        p_act = voltaje * corriente_ma / 1000.0                       # W
        p_rep = voltaje * (corriente_reposo_ma if corriente_reposo_ma is not None else corriente_ma) / 1000.0
        t_comp = computo.mean() / 1e6
        t_per = periodos.mean() / 1e6 if len(periodos) else lat.mean() / 1e6
        m.update(potencia_activa_mw=p_act * 1000,
                 energia_inferencia_mj=p_act * np.mean([f["t_inferencia"] for f in img]) / 1e6 * 1000,
                 energia_por_cuadro_mj=(p_act * t_comp + p_rep * max(t_per - t_comp, 0)) * 1000,
                 potencia_media_mw=(p_act * t_comp + p_rep * max(t_per - t_comp, 0)) / t_per * 1000)
    return m


def graficar_computo(filas, m, carpeta, prefijo):
    img = [f for f in filas if f["con_imagen"]]
    if not img:
        return
    partes = ["t_captura", "t_preproc", "t_inferencia", "t_control"]
    nombres = ["Captura + UART", "Preprocesamiento", "Inferencia CNN", "Control"]
    colores = ["#8C8C8C", "#55A868", "#C44E52", "#4C72B0"]
    medias = [m[p + "_ms"]["media"] for p in partes]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 4.5), gridspec_kw=dict(width_ratios=[1, 2]))
    abajo = 0
    for v, n, c in zip(medias, nombres, colores):
        ax1.bar(0, v, bottom=abajo, color=c, edgecolor="black", label=f"{n}: {v:.2f} ms")
        abajo += v
    ax1.set_xticks([])
    ax1.set_ylabel("ms por cuadro")
    ax1.set_title(f"Latencia media {m['latencia_total_ms']['media']:.1f} ms | {m['fps_lazo']:.2f} FPS")
    ax1.legend(fontsize=8, loc="upper right")

    t = np.arange(len(img))
    for p, n, c in zip(partes[1:], nombres[1:], colores[1:]):
        ax2.plot(t, [f[p] / 1000 for f in img], label=n, color=c, lw=1)
    ax2.set_xlabel("Cuadro")
    ax2.set_ylabel("ms")
    ax2.set_title("Tiempos de cómputo en el microcontrolador")
    ax2.legend(fontsize=8)
    ax2.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(carpeta / f"{prefijo}_tiempos.png", dpi=150)
    plt.close(fig)


# ============================================================
# NAVEGACIÓN
# ============================================================
def distancia_a_polilinea(px, py, puntos):
    mejor = float("inf")
    for (ax, ay), (bx, by) in zip(puntos[:-1], puntos[1:]):
        dx, dy = bx - ax, by - ay
        L2 = dx * dx + dy * dy
        t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
        mejor = min(mejor, math.hypot(px - (ax + t * dx), py - (ay + t * dy)))
    return mejor


def resumen_navegacion(corridas):
    """corridas: lista de dicts con los indicadores de cada corrida."""
    claves = ["tiempo_recorrido_s", "colisiones", "decisiones_incorrectas", "error_tray_medio_m",
              "error_tray_rms_m", "error_tray_max_m", "distancia_m", "paradas"]
    r = {k: float(np.mean([c[k] for c in corridas])) for k in claves}
    r["exito_navegacion"] = float(np.mean([c["exito"] for c in corridas]))
    r["corridas"] = len(corridas)
    return r


def graficar_trayectorias(corridas, estaciones, ruta_ref, limites, carpeta):
    fig, ax = plt.subplots(figsize=(10, 7.5))
    x0, x1, y0, y1 = limites
    ax.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, lw=2, color="gray"))
    rx, ry = zip(*ruta_ref)
    ax.plot(rx, ry, "k--", lw=1.5, label="Trayectoria de referencia")
    colores = plt.cm.tab10.colors
    for i, c in enumerate(corridas):
        ax.plot(c["x"], c["y"], color=colores[i % 10], lw=2,
                label=f"Corrida {i + 1} ({'éxito' if c['exito'] else 'fallo'})")
        for d in c["eventos_decision"]:
            ax.plot(d["x"], d["y"], "o" if d["correcta"] else "X", ms=9,
                    color="#2CA02C" if d["correcta"] else "#D62728", mec="black")
            ax.annotate(d["decision"], (d["x"], d["y"]), textcoords="offset points", fontsize=8,
                        xytext=(6, -14) if d["decision"] == "reanudar" else (6, 6))
        for (cx, cy) in c["puntos_colision"]:
            ax.plot(cx, cy, "*", ms=16, color="red", mec="black")
    for e in estaciones:
        a = math.radians(e["rumbo"])
        nx, ny = -math.sin(a), math.cos(a)
        if e["clase"] == "obstaculo":
            ax.add_patch(plt.Polygon(_rect(e["x"], e["y"], 0.3, 0.65, a), color="#8B5A2B", alpha=0.8))
        else:
            ax.plot([e["x"] - 0.33 * nx, e["x"] + 0.33 * nx], [e["y"] - 0.33 * ny, e["y"] + 0.33 * ny],
                    lw=5, color="#1F77B4")
        ax.annotate(f"{e['nombre']}: {e['clase']}", (e["x"], e["y"]), textcoords="offset points",
                    xytext=(8, -14), fontsize=9, weight="bold")
    ax.plot([], [], "o", color="#2CA02C", mec="black", label="Decisión correcta")
    ax.plot([], [], "X", color="#D62728", mec="black", label="Decisión incorrecta")
    ax.plot([], [], "*", color="red", mec="black", ms=12, label="Colisión")
    ax.set_aspect("equal")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title("Navegación del robot controlado por el S32K344")
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(carpeta / "navegacion_trayectoria.png", dpi=150)
    plt.close(fig)


def graficar_series(corrida, carpeta, umbral, indice):
    t = corrida["t"]
    fig, axs = plt.subplots(3, 1, figsize=(11, 8), sharex=True)
    axs[0].plot(t, corrida["v"], label="v (m/s)")
    axs[0].plot(t, corrida["w"], label="ω (rad/s)")
    axs[0].set_title(f"Corrida {indice}: comandos de velocidad (cinemática inversa en el micro)")
    axs[0].legend(fontsize=8)
    axs[1].plot(t, corrida["w_izq"], label="ω rueda izquierda")
    axs[1].plot(t, corrida["w_der"], label="ω rueda derecha")
    axs[1].set_ylabel("rad/s")
    axs[1].legend(fontsize=8)
    con_img = [i for i, c in enumerate(corrida["clase"]) if c != 255]     # 255 = ciclo sin imagen (giro)
    axs[2].scatter([t[i] for i in con_img], [corrida["conf"][i] for i in con_img],
                   c=[corrida["clase"][i] for i in con_img], cmap="tab10", vmin=0, vmax=9, s=10)
    axs[2].axhline(umbral, color="red", ls="--", label=f"umbral = {umbral:.2f}")
    axs[2].set_ylabel("confianza")
    axs[2].set_xlabel("tiempo de simulación (s)")
    for k, c in enumerate(CLASES):
        axs[2].scatter([], [], color=plt.cm.tab10(k), label=c, s=10)
    axs[2].legend(fontsize=8, ncol=5)
    for a in axs:
        a.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(carpeta / f"navegacion_series_corrida{indice}.png", dpi=150)
    plt.close(fig)


def _rect(cx, cy, largo, ancho, a):
    ca, sa = math.cos(a), math.sin(a)
    return [(cx + ca * dx - sa * dy, cy + sa * dx + ca * dy)
            for dx, dy in [(-largo / 2, -ancho / 2), (largo / 2, -ancho / 2),
                           (largo / 2, ancho / 2), (-largo / 2, ancho / 2)]]


# ============================================================
# ENTRENAMIENTO EN EL MICRO
# ============================================================
def graficar_curvas(historia, carpeta):
    ep = [h["epoca"] for h in historia]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    ax1.plot(ep, [h["acc"] for h in historia], "o-", label="Entrenamiento")
    ax1.plot(ep, [h["val_acc"] for h in historia], "s-", label="Validación")
    ax1.set_title("Accuracy por época")
    ax1.set_xlabel("Época")
    ax1.set_ylabel("Accuracy")
    ax2.plot(ep, [h["loss"] for h in historia], "o-", label="Entrenamiento")
    ax2.plot(ep, [h["val_loss"] for h in historia], "s-", label="Validación")
    ax2.set_title("Loss por época")
    ax2.set_xlabel("Época")
    ax2.set_ylabel("Loss")
    for a in (ax1, ax2):
        a.grid(alpha=0.3)
        a.legend()
    fig.suptitle("Curvas de aprendizaje (entrenamiento en el microcontrolador)")
    fig.tight_layout()
    fig.savefig(carpeta / "entrenamiento_curvas_aprendizaje.png", dpi=150)
    plt.close(fig)


def graficar_comparacion(modelos, carpeta):
    """modelos: {nombre: dict(accuracy, f1_macro, t_inferencia_ms, memoria_kb)}"""
    nombres = list(modelos)
    fig, axs = plt.subplots(1, 3, figsize=(14, 4.5))
    for ax, clave, titulo, fmt in [(axs[0], "accuracy", "Accuracy (test)", "{:.3f}"),
                                   (axs[1], "t_inferencia_ms", "Tiempo de inferencia (ms)", "{:.2f}"),
                                   (axs[2], "memoria_kb", "Memoria del modelo (KB)", "{:.1f}")]:
        vals = [modelos[n][clave] for n in nombres]
        barras = ax.bar(range(len(nombres)), vals, color=["#4C72B0", "#DD8452", "#55A868"][:len(nombres)],
                        edgecolor="black")
        for b, v in zip(barras, vals):
            ax.text(b.get_x() + b.get_width() / 2, v, fmt.format(v), ha="center", va="bottom", fontsize=9)
        ax.set_xticks(range(len(nombres)), [n.replace(" ", "\n", 1) for n in nombres], fontsize=8)
        ax.set_title(titulo)
        ax.grid(axis="y", alpha=0.3)
    fig.suptitle("Comparación de modelos ejecutados en el microcontrolador")
    fig.tight_layout()
    fig.savefig(carpeta / "entrenamiento_comparacion_modelos.png", dpi=150)
    plt.close(fig)
