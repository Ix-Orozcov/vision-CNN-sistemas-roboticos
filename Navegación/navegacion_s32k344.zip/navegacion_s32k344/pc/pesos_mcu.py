"""
pesos_mcu.py - Pesos entrenados en el microcontrolador.

- Los convierte del formato del micro (bloques float32) a arreglos con nombre.
- Los guarda en .npz y, si TensorFlow está instalado, como modelo de Keras (.keras)
  con la misma arquitectura que cnn_navegacion.py, para analizarlo en la PC
  (por ejemplo, con cuantizar_cnn.py).
- Ejecuta la red en numpy para comprobar que la PC obtiene el mismo resultado que el micro.
"""
import numpy as np

FORMAS = [("w1", (8, 3, 3, 1)), ("b1", (8,)), ("w2", (16, 3, 3, 8)), ("b2", (16,)),
          ("w3", (16, 3136)), ("b3", (16,)), ("w4", (4, 16)), ("b4", (4,))]


def desempaquetar(datos):
    v = np.frombuffer(datos, dtype="<f4")
    pesos, i = {}, 0
    for nombre, forma in FORMAS:
        n = int(np.prod(forma))
        pesos[nombre] = v[i:i + n].reshape(forma).copy()
        i += n
    if i != v.size:
        raise ValueError(f"Se esperaban {i} valores y llegaron {v.size}.")
    return pesos


def guardar(pesos, carpeta):
    np.savez(carpeta / "pesos_entrenados_en_mcu.npz", **pesos)
    try:
        import tensorflow as tf
        from tensorflow.keras import layers
        m = tf.keras.Sequential([
            tf.keras.Input(shape=(64, 64, 1)),
            layers.Conv2D(8, (3, 3), activation="relu", name="conv1"),
            layers.MaxPooling2D((2, 2), name="pool1"),
            layers.Conv2D(16, (3, 3), activation="relu", name="conv2"),
            layers.MaxPooling2D((2, 2), name="pool2"),
            layers.Flatten(name="flatten"),
            layers.Dense(16, activation="relu", name="dense"),
            layers.Dense(4, activation="softmax", name="salida"),
        ])
        # El micro guarda conv como [salida][ky][kx][entrada] y dense como [salida][entrada];
        # Keras usa [ky][kx][entrada][salida] y [entrada][salida].
        m.set_weights([pesos["w1"].transpose(1, 2, 3, 0), pesos["b1"], pesos["w2"].transpose(1, 2, 3, 0),
                       pesos["b2"], pesos["w3"].T, pesos["b3"], pesos["w4"].T, pesos["b4"]])
        ruta = carpeta / "modelo_entrenado_en_mcu.keras"
        m.save(ruta)
        return ruta
    except ImportError:
        return None


def _conv_relu_pool(x, w, b):
    """x: (N, H, W, C), w: (O, 3, 3, C). Conv 'valid' + ReLU + MaxPool 2x2."""
    v = np.lib.stride_tricks.sliding_window_view(x, (3, 3), axis=(1, 2))   # N,H-2,W-2,C,3,3
    y = np.einsum("nhwcij,oijc->nhwo", v, w, optimize=True) + b
    y = np.maximum(y, 0)
    n, h, ww, o = y.shape
    h2, w2 = h // 2, ww // 2
    return y[:, :h2 * 2, :w2 * 2].reshape(n, h2, 2, w2, 2, o).max(axis=(2, 4))


def inferir(pesos, imagenes_u8, lote=64):
    """imagenes_u8: (N, 64, 64) en gris. Devuelve las probabilidades (N, 4)."""
    salida = []
    for i in range(0, len(imagenes_u8), lote):
        x = imagenes_u8[i:i + lote].astype(np.float32)[..., None] / 255.0
        x = _conv_relu_pool(x, pesos["w1"], pesos["b1"])
        x = _conv_relu_pool(x, pesos["w2"], pesos["b2"])
        h = np.maximum(x.reshape(len(x), -1) @ pesos["w3"].T + pesos["b3"], 0)
        z = h @ pesos["w4"].T + pesos["b4"]
        z = np.exp(z - z.max(axis=1, keepdims=True))
        salida.append(z / z.sum(axis=1, keepdims=True))
    return np.concatenate(salida)
