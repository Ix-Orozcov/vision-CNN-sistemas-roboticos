"""
protocolo.py - Mensajes binarios entre el puente (PC) y el S32K344.
Debe coincidir con firmware/comun/protocolo.h.

Trama:  0xA5 0x5A | tipo (1) | longitud (4, LE) | datos | CRC-16/CCITT-FALSE (2, LE)
"""
import binascii
import socket
import struct
import time

SINC = b"\xA5\x5A"

MSG_HOLA, MSG_PEDIR_FOTO, MSG_PEDIR_ODOM, MSG_MOTORES, MSG_ENTRENO, MSG_RESULTADO = 1, 2, 3, 4, 5, 6
MSG_ACK, MSG_FOTO, MSG_ODOM, MSG_MUESTRA, MSG_COMANDO = 0x81, 0x82, 0x83, 0x84, 0x85

CMD_CONFIG_ROBOT, CMD_INICIAR_PESOS, CMD_USAR_MODELO, CMD_CALIBRAR, CMD_CUANTIZAR, CMD_SUBIR_PESOS = 1, 2, 3, 4, 5, 6
CMD_CARGAR_PESOS = 7
MODELOS = {"pc": 0, "mcu_float": 1, "mcu_int8": 2}
NOMBRE_MODELO = {0: "INT8 entrenado en la PC", 1: "float32 entrenado en el micro", 2: "INT8 entrenado y cuantizado en el micro"}

BANDERA_REINICIO = 0x01
BANDERA_EVALUACION = 0x02

ACCIONES = ["avanzar", "izquierda", "derecha", "detener", "incierto", "girando", "esperando", "sin_objeto_cerca"]
ESTADOS = ["avanzar", "giro", "parado"]
DECISIONES = ["ninguna", "izquierda", "derecha", "detener", "reanudar"]


def crc16(datos, crc=0xFFFF):
    return binascii.crc_hqx(datos, crc)          # CRC-16/CCITT-FALSE con inicio 0xFFFF


def armar(tipo, datos=b""):
    cab = struct.pack("<BI", tipo, len(datos))
    return SINC + cab + datos + struct.pack("<H", crc16(cab + datos))


# ---------------- Transportes ----------------
class TransporteTCP:
    """Servidor TCP para el firmware compilado en la PC (firmware/pc)."""

    def __init__(self, puerto):
        self.srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("0.0.0.0", puerto))
        self.srv.listen(1)
        print(f"Esperando al firmware de PC en el puerto TCP {puerto}...")
        self.con, dir_ = self.srv.accept()
        self.con.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        print(f"Firmware conectado desde {dir_[0]}")

    def leer(self, n, timeout):
        self.con.settimeout(timeout)
        partes, faltan = [], n
        while faltan:
            try:
                d = self.con.recv(faltan)
            except socket.timeout:
                raise TimeoutError
            if not d:
                raise ConnectionError("El firmware cerró la conexión.")
            partes.append(d)
            faltan -= len(d)
        return b"".join(partes)

    def escribir(self, datos):
        self.con.sendall(datos)

    def cerrar(self):
        self.con.close()
        self.srv.close()


class TransporteSerie:
    """Puerto serie hacia el S32K344 (requiere: pip install pyserial)."""

    def __init__(self, puerto, baudios):
        import serial
        # El tiempo de espera del puerto se fija UNA vez. Cambiar s.timeout en cada
        # lectura hace que pyserial reconfigure el puerto en Windows, y algunos
        # convertidores USB-serie (como el de las tarjetas de NXP) pierden bytes ahí.
        self.s = serial.Serial(puerto, baudios, timeout=0.05)
        self.s.reset_input_buffer()
        print(f"Puerto serie {puerto} abierto a {baudios} baudios.")

    def leer(self, n, timeout):
        fin = time.monotonic() + timeout
        d = bytearray()
        while len(d) < n:
            d += self.s.read(n - len(d))
            if len(d) < n and time.monotonic() > fin:
                raise TimeoutError
        return bytes(d)

    def escribir(self, datos):
        """Manda los datos a la velocidad del puerto, en pedazos, sin adelantarse más de
        ~1 KB. El convertidor USB-serie de la tarjeta tiene un búfer chico: si se le manda
        de golpe una trama grande (un bloque de pesos de 4-12 KB o una foto de 128x128),
        pierde bytes en silencio y el micro nunca recibe la trama completa."""
        bytes_por_s = self.s.baudrate / 10.0           # 8 bits + inicio + parada
        adelanto_max, pedazo = 1024, 256
        t0 = time.monotonic()
        for i in range(0, len(datos), pedazo):
            enviados = i                                # bytes ya escritos antes de este pedazo
            en_camino = enviados - (time.monotonic() - t0) * bytes_por_s
            if en_camino > adelanto_max:
                time.sleep((en_camino - adelanto_max) / bytes_por_s)
            self.s.write(datos[i:i + pedazo])

    def cerrar(self):
        self.s.close()


# ---------------- Envío y recepción ----------------
def recibir(t, timeout=10.0):
    """Devuelve (tipo, datos). Descarta bytes hasta encontrar la sincronía."""
    fin = time.monotonic() + timeout
    previo = b""
    while True:
        restante = fin - time.monotonic()
        if restante <= 0:
            raise TimeoutError
        b = t.leer(1, restante)
        if previo == SINC[:1] and b == SINC[1:]:
            break
        previo = b
    cab = t.leer(5, timeout)
    tipo, n = struct.unpack("<BI", cab)
    if n > 4_000_000:
        raise ValueError("Longitud de trama inválida.")
    datos = t.leer(n, timeout) if n else b""
    crc, = struct.unpack("<H", t.leer(2, timeout))
    if crc != crc16(cab + datos):
        crudo = (SINC + cab + datos + struct.pack("<H", crc))
        muestra_hex = " ".join(f"{x:02X}" for x in crudo[:64]) + (" ..." if len(crudo) > 64 else "")
        raise ValueError(f"CRC incorrecto (tipo {tipo}, longitud {n}).\n      bytes: {muestra_hex}\n     ")
    return tipo, datos


def enviar(t, tipo, datos=b""):
    t.escribir(armar(tipo, datos))


def ack(t, estado=0):
    enviar(t, MSG_ACK, bytes([estado]))


def foto(t, pixeles, ancho, alto, canales, enc_izq, enc_der, ident, banderas=0, dist_mm=0xFFFF,
         rumbo=float("nan")):
    """dist_mm: sensor de distancia frontal en mm (0xFFFF = sin sensor).
    rumbo: orientación del giroscopio en rad (NaN = sin IMU)."""
    cab = struct.pack("<BBHHHiiIf", banderas, canales, ancho, alto, dist_mm, enc_izq, enc_der, ident, rumbo)
    enviar(t, MSG_FOTO, cab + pixeles)


def muestra(t, pixeles, ancho, alto, canales, etiqueta, tasa, epoca, ident, banderas=0):
    cab = struct.pack("<BBHHBxfIIf", banderas, canales, ancho, alto, etiqueta, tasa, epoca, ident, float("nan"))
    enviar(t, MSG_MUESTRA, cab + pixeles)


def comando(t, cmd, seq, datos=b""):
    """COMANDO = [cmd][0][0][0][secuencia u32][datos]."""
    enviar(t, MSG_COMANDO, bytes([cmd, 0, 0, 0]) + struct.pack("<I", seq) + datos)


def secuencia(d):
    """Número de secuencia de una petición del micro (PEDIR_FOTO / PEDIR_ODOM)."""
    return struct.unpack("<I", d[:4])[0] if len(d) >= 4 else 0


def odom(t, enc_izq, enc_der, ident, banderas=0, rumbo=float("nan")):
    enviar(t, MSG_ODOM, struct.pack("<B3xiiIf", banderas, enc_izq, enc_der, ident, rumbo))


def decodificar_hola(d):
    (v, n, auto, mhz, flash, ram_trabajo, ram_pre, npar, umbral, ram_pesos, ram_int8,
     ram_img) = struct.unpack("<HBBIIIIIfIII", d[:40])
    return dict(version=v, n_clases=n, autoprueba=auto, cpu_mhz=mhz, flash_modelo=flash,
                ram_trabajo=ram_trabajo, ram_preproc=ram_pre, n_parametros=npar, umbral=umbral,
                ram_pesos=ram_pesos, ram_int8_mcu=ram_int8, ram_imagen=ram_img,
                ram_total=ram_trabajo + ram_pre + ram_pesos + ram_int8 + ram_img)


def decodificar_motores(d):
    (wl, wr, ident, clase, accion, estado, decision, p0, p1, p2, p3, conf, v, w,
     t_cap, t_pre, t_inf, t_ctrl, t_lat, t_per, con_img) = struct.unpack("<ffIBBBB" + "f" * 7 + "I" * 6 + "B", d[:69])
    return dict(w_izq=wl, w_der=wr, id=ident, clase=clase, accion=accion, estado=estado,
                decision=decision, prob=[p0, p1, p2, p3], conf=conf, v=v, w=w,
                t_captura=t_cap, t_preproc=t_pre, t_inferencia=t_inf, t_control=t_ctrl,
                t_latencia=t_lat, t_periodo=t_per, con_imagen=con_img, modelo=d[69])


def decodificar_entreno(d):
    ident, etiqueta, pred, perdida, p0, p1, p2, p3, t_cap, t_pre, t_paso, epoca, t_per = \
        struct.unpack("<IBBxxfffffIIIII", d[:48])
    return dict(id=ident, etiqueta=etiqueta, pred=pred, perdida=perdida, prob=[p0, p1, p2, p3],
                t_captura=t_cap, t_preproc=t_pre, t_paso=t_paso, epoca=epoca, t_periodo=t_per)


def decodificar_resultado(d):
    cmd, estado, modelo, t_us = struct.unpack("<BBBxI", d[:8])
    return dict(cmd=cmd, estado=estado, modelo=modelo, t_us=t_us, datos=d[8:])