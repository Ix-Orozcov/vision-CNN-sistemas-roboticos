"""
puente_coppelia.py - Une el S32K344 con el robot Pioneer P3DX simulado en CoppeliaSim.

    CoppeliaSim  <-- ZMQ -->  este puente (PC)  <-- UART / TCP -->  S32K344

El micro decide y aprende: entrena la CNN, pide fotos, las preprocesa, ejecuta la red,
aplica el umbral, elige la acción y calcula las velocidades de rueda. El puente solo:
  - le manda las imágenes etiquetadas para entrenar (el micro no tiene espacio para
    guardar el dataset) y las fotos de la cámara del robot,
  - aplica los comandos de motores al Pioneer y lee sus encoders,
  - detecta colisiones, registra todo y calcula los indicadores.

MODOS
  entrenar : el micro entrena la CNN desde cero con dataset/train, se valida con
             dataset/validation, la cuantiza a INT8 y se comparan los modelos en
             dataset/test. Con --navegar recorre después el circuito con ese modelo.
  evaluar  : manda las imágenes de una carpeta al micro y mide percepción y tiempos.
  navegar  : recorre el circuito de 5 estaciones con el Pioneer. Si la escena abierta en
             CoppeliaSim ya tiene el circuito (guardada antes), usa esos objetos; si
             está vacía, lo crea.

EJEMPLOS
  python puente_coppelia.py entrenar --serie COM5 --datos ruta/dataset_run --navegar
  python puente_coppelia.py evaluar  --serie COM5 --carpeta ruta/dataset_run/test --modelo pc
  python puente_coppelia.py navegar  --serie COM5 --modelo pc
  (sin tarjeta: cambia --serie COM5 por --tcp 5005 y ejecuta firmware_pc)

IMPORTANTE: el modelo entrenado en el micro vive en su RAM; si reinicias la tarjeta
se pierde. Por eso "entrenar --navegar" hace todo en la misma sesión.

Requisitos: pip install numpy pillow matplotlib coppeliasim-zmqremoteapi-client pyserial
"""
import argparse
import csv
import json
import math
import random
import struct
import time
from datetime import datetime
from pathlib import Path

import numpy as np
from PIL import Image

import metricas as M
import pesos_mcu
import protocolo as P
from robots import Escena, RobotCinematico, RobotPioneer, caja, distancia_frontal

CLASES = ["avanzar", "izquierda", "derecha", "obstaculo"]
EXTENSIONES = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

# ---------------- Circuito ----------------
# rumbo: dirección (grados) con la que el robot llega a la estación; el panel mira hacia él.
#   barrera : señal "avanzar" en una barrera que se abre cuando el robot llega a 1 m
#   giro    : señal de giro en un muro; el robot debe girar antes de llegar
#   temporal: obstáculo que se retira cuando el robot lleva 3 s detenido frente a él
#   meta    : obstáculo final; el robot debe detenerse frente a él
INICIO = (0.0, 0.0, 0.0)
ESTACIONES = [
    dict(nombre="E1", clase="avanzar",   x=3.5,  y=0.0, rumbo=0,  modo="barrera"),
    dict(nombre="E2", clase="izquierda", x=8.0,  y=0.0, rumbo=0,  modo="giro"),
    dict(nombre="E3", clase="obstaculo", x=6.3,  y=3.4, rumbo=90, modo="temporal"),
    dict(nombre="E4", clase="derecha",   x=6.3,  y=7.4, rumbo=90, modo="giro"),
    dict(nombre="E5", clase="obstaculo", x=10.5, y=5.7, rumbo=0,  modo="meta"),
]
LIMITES = (-2.5, 13.0, -3.0, 10.0)        # x_min, x_max, y_min, y_max del área con muros
D_GIRO_REF, D_META_REF = 1.7, 1.6         # dónde se espera que gire / se detenga (referencia)
D_ETIQUETA, ANG_ETIQUETA = 2.4, 22.0      # estación "a la vista" para etiquetar cuadros
D_RANGO, ANG_RANGO = 3.0, 30.0            # estación "en rango" para juzgar decisiones
D_BARRERA, D_OMISION = 1.0, 0.9
T_ESPERA_OBSTACULO, T_META = 3.0, 2.0
ZONA_META = (0.4, 3.0)                    # distancia mín/máx (m) al obstáculo final para la meta


# ============================================================
# MISIÓN: estado del circuito y evaluación de decisiones
# ============================================================
class Mision:
    def __init__(self, estaciones, rng=None):
        self.est = [dict(e) for e in estaciones]
        if rng is not None:                      # pequeña variación entre corridas
            for e in self.est:
                a = math.radians(e["rumbo"])
                d = rng.uniform(-0.08, 0.08)
                e["x"] += -math.sin(a) * d
                e["y"] += math.cos(a) * d
        self.activa = 0
        self.visibles = {e["nombre"]: True for e in self.est}
        self.completadas, self.omitidas = set(), set()
        self.t_quieto_obst = self.t_quieto_meta = 0.0
        self.resultado = None                    # "exito" / "meta_incompleta"

    def ruta_referencia(self):
        pts = [INICIO[:2]]
        for e in self.est:
            a = math.radians(e["rumbo"])
            if e["modo"] == "giro":
                pts.append((e["x"] - D_GIRO_REF * math.cos(a), e["y"] - D_GIRO_REF * math.sin(a)))
            elif e["modo"] == "meta":
                pts.append((e["x"] - D_META_REF * math.cos(a), e["y"] - D_META_REF * math.sin(a)))
        return pts

    def cajas(self):
        x0, x1, y0, y1 = LIMITES
        cs = [caja((x0 + x1) / 2, y1, x1 - x0, .1, 0), caja((x0 + x1) / 2, y0, x1 - x0, .1, 0),
              caja(x1, (y0 + y1) / 2, .1, y1 - y0, 0), caja(x0, (y0 + y1) / 2, .1, y1 - y0, 0)]
        for e in self.est:
            if self.visibles[e["nombre"]]:
                largo, ancho = (.3, .65) if e["clase"] == "obstaculo" else (.025, .66)
                cs.append(caja(e["x"], e["y"], largo, ancho, math.radians(e["rumbo"])))
        return cs

    def estacion_activa(self):
        return self.est[self.activa] if self.activa < len(self.est) else None

    @staticmethod
    def relativa(robot, e, pose):
        """Distancia de la cámara a la estación y ángulo respecto al eje de la cámara."""
        cx, cy = robot.camara()
        dx, dy = e["x"] - cx, e["y"] - cy
        ang = math.degrees(math.atan2(dy, dx) - pose[2])
        ang = (ang + 180) % 360 - 180
        return math.hypot(dx, dy), ang

    def a_la_vista(self, robot, e, dmax, angmax, pose):
        if e is None or not self.visibles[e["nombre"]]:
            return False
        d, ang = self.relativa(robot, e, pose)
        return d <= dmax and abs(ang) <= angmax

    def etiqueta(self, robot, pose):
        """Clase correcta para el cuadro actual (None si no hay señal a la vista)."""
        e = self.estacion_activa()
        return CLASES.index(e["clase"]) if self.a_la_vista(robot, e, D_ETIQUETA, ANG_ETIQUETA, pose) else None

    def evaluar_decision(self, robot, dec, pose):
        """dec: 'izquierda', 'derecha', 'detener' o 'reanudar'. Devuelve si fue correcta."""
        e = self.estacion_activa()
        en_rango = self.a_la_vista(robot, e, D_RANGO, ANG_RANGO, pose)
        if dec == "reanudar":
            return not (en_rango and e["clase"] == "obstaculo")
        if not en_rango:
            return False                               # actuó sin señal válida delante
        correcta = {"izquierda": "izquierda", "derecha": "derecha", "detener": "obstaculo"}[dec] == e["clase"]
        if correcta and e["modo"] == "giro":
            self._completar(e)
        return correcta

    def _completar(self, e):
        self.completadas.add(e["nombre"])
        self.activa += 1

    def actualizar(self, robot, pose, quieto, dt, escena):
        """Abre barreras, retira obstáculos temporales, detecta omisiones y la meta.
        Devuelve el número de omisiones nuevas (decisiones no tomadas)."""
        e = self.estacion_activa()
        if e is None:
            return 0
        omisiones = 0
        x, y, _ = pose
        a = math.radians(e["rumbo"])
        dx, dy = e["x"] - x, e["y"] - y
        frente = dx * math.cos(a) + dy * math.sin(a)          # distancia a lo largo del rumbo
        lateral = -dx * math.sin(a) + dy * math.cos(a)
        d_cam, _ = self.relativa(robot, e, pose)

        if e["modo"] == "barrera":
            if self.visibles[e["nombre"]] and math.hypot(dx, dy) <= D_BARRERA:
                self.visibles[e["nombre"]] = False
                if escena:
                    escena.colocar_estacion(e, False)
            if not self.visibles[e["nombre"]] and frente < 0:
                self._completar(e)
        elif e["modo"] == "giro":
            if d_cam <= D_OMISION and e["nombre"] not in self.omitidas:
                self.omitidas.add(e["nombre"])
                omisiones = 1                              # llegó a la señal sin girar
        elif e["modo"] == "temporal":
            cerca = 0 < frente <= 2.8 and abs(lateral) <= 1.0
            self.t_quieto_obst = self.t_quieto_obst + dt if (quieto and cerca) else 0.0
            if self.t_quieto_obst >= T_ESPERA_OBSTACULO:
                self.visibles[e["nombre"]] = False
                if escena:
                    escena.colocar_estacion(e, False)
                self._completar(e)
        elif e["modo"] == "meta":
            # Meta: detenido frente al obstáculo final (a la vista de la cámara y a buena distancia)
            en_zona = ZONA_META[0] <= frente <= ZONA_META[1] and self.a_la_vista(robot, e, D_RANGO, ANG_RANGO, pose)
            self.t_quieto_meta = self.t_quieto_meta + dt if (quieto and en_zona) else 0.0
            if self.t_quieto_meta >= T_META:
                previas = {x_["nombre"] for x_ in self.est[:-1]}
                self.resultado = "exito" if previas <= self.completadas else "meta_incompleta"
                self._completar(e)
        return omisiones


# ============================================================
# COMUNICACIÓN CON EL MICRO
# ============================================================
class Puente:
    def __init__(self, transporte, carpeta):
        self.t = transporte
        self.carpeta = carpeta
        self.hw = None
        self.id = 0

    def esperar_mensaje(self, timeout=30.0):
        while True:
            try:
                tipo, d = P.recibir(self.t, timeout=timeout)
            except TimeoutError:
                print(f"  (aviso: el micro no ha mandado nada en {timeout:.0f} s; se sigue esperando)")
                continue
            except ValueError as err:
                print(f"  (aviso: trama dañada - {err} Se espera la siguiente)")
                continue
            if tipo == P.MSG_HOLA:
                self.hw = P.decodificar_hola(d)
                P.ack(self.t)
                mhz = self.hw["cpu_mhz"]
                auto = {1: "correcta", 0: "FALLÓ", 2: "sin vectores"}.get(self.hw["autoprueba"], "?")
                print(f"Micro conectado: {'PC (prueba)' if mhz == 0 else f'{mhz} MHz'} | autoprueba CNN de la PC: "
                      f"{auto} | RAM usada {self.hw['ram_total'] / 1024:.1f} KB | umbral {self.hw['umbral']:.2f}")
                continue
            return tipo, d

    def siguiente_peticion(self):
        """Espera a que el micro pida trabajo. Devuelve (tipo, secuencia). Los mensajes
        atrasados se confirman y se ignoran."""
        while True:
            tipo, d = self.esperar_mensaje()
            if tipo in (P.MSG_PEDIR_FOTO, P.MSG_PEDIR_ODOM):
                return tipo, P.secuencia(d)
            P.ack(self.t)

    def _esperar(self, tipo_esperado, reenviar, seq, es_respuesta):
        """Espera la respuesta del micro a la petición 'seq'. Ignora mensajes atrasados
        (de otra petición) y, si el micro repite la misma petición porque no le llegó la
        respuesta, se la vuelve a mandar (el micro descarta los duplicados)."""
        while True:
            tipo, d = self.esperar_mensaje()
            if tipo in (P.MSG_PEDIR_FOTO, P.MSG_PEDIR_ODOM):
                if P.secuencia(d) == seq:
                    reenviar()
                continue
            P.ack(self.t)
            if tipo == tipo_esperado and es_respuesta(d):
                return d

    def comando(self, cmd, datos=b"", obligatorio=True):
        _, seq = self.siguiente_peticion()
        enviar = lambda: P.comando(self.t, cmd, seq, datos)
        enviar()
        r = P.decodificar_resultado(self._esperar(P.MSG_RESULTADO, enviar, seq, lambda d: d[0] == cmd))
        if r["estado"] and obligatorio:
            raise RuntimeError(f"El micro rechazó el comando {cmd} (estado {r['estado']}).")
        return r

    def usar_modelo(self, nombre):
        r = self.comando(P.CMD_USAR_MODELO, bytes([P.MODELOS[nombre]]), obligatorio=False)
        if r["estado"]:
            raise RuntimeError(f"El modelo '{nombre}' no está disponible en el micro (¿se reinició la "
                               "tarjeta? el modelo entrenado en el micro se pierde al reiniciar).")
        print(f"Modelo activo en el micro: {P.NOMBRE_MODELO[P.MODELOS[nombre]]}")

    def configurar_robot(self, robot):
        self.comando(P.CMD_CONFIG_ROBOT, struct.pack("<fff", robot.radio, robot.eje, robot.w_max))

    def muestra(self, px, etiqueta, tasa, epoca, canales):
        _, seq = self.siguiente_peticion()
        enviar = lambda: P.muestra(self.t, px.tobytes(), px.shape[1], px.shape[0], canales, etiqueta,
                                   tasa, epoca, seq)
        enviar()
        d = self._esperar(P.MSG_ENTRENO, enviar, seq, lambda d: P.decodificar_entreno(d)["id"] == seq)
        return P.decodificar_entreno(d)

    def clasificar(self, px, canales):
        _, seq = self.siguiente_peticion()
        enviar = lambda: P.foto(self.t, px.tobytes(), px.shape[1], px.shape[0], canales, 0, 0, seq,
                                P.BANDERA_EVALUACION)
        enviar()
        d = self._esperar(P.MSG_MOTORES, enviar, seq, lambda d: P.decodificar_motores(d)["id"] == seq)
        return P.decodificar_motores(d)


def preparar_pixeles(img, canales):
    """img: arreglo HxWx3 uint8. La cámara entrega gris (1 canal) o RGB (3 canales)."""
    if canales == 1:
        return np.asarray(Image.fromarray(img).convert("L"), dtype=np.uint8)
    return img


def aumentar(px, rng):
    """Aumento de datos para el entrenamiento en el micro (equivalente a las capas Random* de
    Keras usadas en la PC): brillo, contraste, zoom, desplazamiento y rotación pequeña.
    Sin volteo horizontal: convertiría una flecha izquierda en derecha."""
    gris = px.ndim == 2
    a = px.astype(np.float32)
    h, w = a.shape[:2]
    m = 16                                                   # margen con el borde replicado
    pad = np.pad(a, ((m, m), (m, m)) + (() if gris else ((0, 0),)), mode="edge")
    img = Image.fromarray(np.clip(pad, 0, 255).astype(np.uint8))
    zoom = rng.uniform(0.8, 1.25)                            # >1 acerca, <1 aleja (distancia)
    ang = math.radians(rng.uniform(-14, 14))
    tx, ty = rng.uniform(-0.1, 0.1) * w, rng.uniform(-0.1, 0.1) * h
    cx, cy = pad.shape[1] / 2, pad.shape[0] / 2
    c, s_ = math.cos(ang) / zoom, math.sin(ang) / zoom
    # Transformación inversa (de la salida a la entrada) que pide PIL
    coef = (c, s_, cx - c * cx - s_ * cy - tx, -s_, c, cy + s_ * cx - c * cy - ty)
    img = img.transform(img.size, Image.AFFINE, coef, resample=Image.BILINEAR)
    a = np.asarray(img, np.float32)[m:m + h, m:m + w]
    media = a.mean()
    a = (a - media) * rng.uniform(0.75, 1.25) + media        # contraste
    a = a * rng.uniform(0.75, 1.25)                          # brillo
    return np.clip(a, 0, 255).astype(np.uint8)


def cargar_carpeta(carpeta, canales, limite=0, semilla=0):
    """Lee carpeta/<clase>/*.png. Devuelve [(pixeles, clase, nombre)]."""
    carpeta = Path(carpeta)
    datos = []
    for k, c in enumerate(CLASES):
        sub = carpeta / c
        if not sub.is_dir():
            raise FileNotFoundError(f"No existe la carpeta {sub}")
        for r in sorted(sub.iterdir()):
            if r.suffix.lower() in EXTENSIONES:
                with Image.open(r) as im:
                    datos.append((preparar_pixeles(np.asarray(im.convert("RGB"), np.uint8), canales), k, r.name))
    if limite:
        random.Random(semilla).shuffle(datos)
        datos = datos[:limite]
    return datos


def guardar_csv(filas, ruta):
    if not filas:
        return
    with open(ruta, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0].keys()))
        w.writeheader()
        w.writerows(filas)


def fila_telemetria(tel, extra):
    f = dict(extra)
    f.update(con_imagen=tel["con_imagen"], modelo=tel.get("modelo", 0), clase_pred=tel["clase"],
             conf=round(tel["conf"], 5), **{f"p_{c}": round(p, 5) for c, p in zip(CLASES, tel["prob"])},
             accion=P.ACCIONES[tel["accion"]] if tel["accion"] < len(P.ACCIONES) else tel["accion"],
             estado=P.ESTADOS[tel["estado"]] if tel["estado"] < len(P.ESTADOS) else tel["estado"],
             decision=P.DECISIONES[tel["decision"]] if tel["decision"] < len(P.DECISIONES) else tel["decision"],
             v=round(tel["v"], 4), w=round(tel["w"], 4),
             w_izq=round(tel["w_izq"], 4), w_der=round(tel["w_der"], 4),
             t_captura=tel["t_captura"], t_preproc=tel["t_preproc"], t_inferencia=tel["t_inferencia"],
             t_control=tel["t_control"], t_latencia=tel["t_latencia"], t_periodo=tel["t_periodo"])
    return f


# ============================================================
# MODO EVALUAR
# ============================================================
def evaluar_conjunto(args, puente, datos, prefijo, titulo, graficar=True):
    filas, y_real, y_pred, confs = [], [], [], []
    for i, (px, k, nombre) in enumerate(datos, 1):
        tel = puente.clasificar(px, args.canales)
        y_real.append(k)
        y_pred.append(tel["clase"])
        confs.append(tel["conf"])
        filas.append(fila_telemetria(tel, dict(imagen=nombre, clase_real=k)))
        if i % 100 == 0 or i == len(datos):
            print(f"  {i}/{len(datos)}  accuracy parcial {np.mean(np.array(y_real) == np.array(y_pred)):.3f}")
    umbral = puente.hw["umbral"] if puente.hw else 0.7
    mp = M.metricas_percepcion(y_real, y_pred, confs, umbral)
    mc = M.metricas_computo(filas, puente.hw, args.corriente_ma, args.corriente_reposo_ma, args.voltaje)
    if graficar:
        M.graficar_percepcion(mp, puente.carpeta, titulo, prefijo)
        M.graficar_computo(filas, mc, puente.carpeta, prefijo)
    guardar_csv(filas, puente.carpeta / f"{prefijo}_telemetria.csv")
    return dict(percepcion=mp, computo=mc)


def modo_evaluar(args, puente):
    puente.usar_modelo(args.modelo)
    datos = cargar_carpeta(args.carpeta, args.canales, args.limite)
    print(f"Evaluando {len(datos)} imágenes de {args.carpeta} en el micro...")
    return evaluar_conjunto(args, puente, datos, "evaluacion", f"micro, {Path(args.carpeta).name}")


# ============================================================
# CALIBRACIÓN / CARGA DE PESOS GUARDADOS
# ============================================================
def calibrar_y_cuantizar(args, puente, imagenes):
    """Mide los rangos de activación del modelo float del micro con imágenes de todas las
    clases (muestra aleatoria) y lo cuantiza a INT8 en el micro."""
    puente.comando(P.CMD_CALIBRAR)
    muestra = random.Random(args.semilla).sample(imagenes, min(args.n_calibracion, len(imagenes)))
    for px, _, _ in muestra:
        puente.clasificar(px, args.canales)
    rc = puente.comando(P.CMD_CUANTIZAR)
    return struct.unpack("<fiII", rc["datos"][:16])        # escala, zp, muestras, RAM del INT8


def cargar_pesos_en_micro(args, puente):
    """Manda al micro los pesos float guardados (pesos_entrenados_en_mcu.npz), comprueba que
    llegaron idénticos, y los calibra y cuantiza a INT8 en el micro. Así se recupera la red
    que entrenó el micro sin volver a entrenar (por ejemplo, si se reinició la tarjeta)."""
    ruta = Path(args.cargar_pesos)
    if not ruta.is_file():
        raise FileNotFoundError(f"No existe {ruta}")
    pesos = dict(np.load(ruta))
    bloques = [pesos["w1"], pesos["b1"], pesos["w2"], pesos["b2"], *pesos["w3"],
               pesos["b3"], pesos["w4"], pesos["b4"]]
    print(f"Cargando en el micro los pesos de {ruta} ({len(bloques)} bloques)...")
    t0 = time.monotonic()
    for i, b in enumerate(bloques):
        crudo = np.ascontiguousarray(b, dtype="<f4").tobytes()
        puente.comando(P.CMD_CARGAR_PESOS, struct.pack("<I", i) + crudo)
        print(f"  bloque {i + 1}/{len(bloques)}", end="\r", flush=True)
    esperado = b"".join(np.ascontiguousarray(b, dtype="<f4").tobytes() for b in bloques)
    devuelto = puente.comando(P.CMD_SUBIR_PESOS)["datos"]
    if devuelto != esperado:
        raise RuntimeError("Los pesos que tiene el micro no coinciden con los del archivo.")
    print(f"  Pesos cargados y verificados ({len(esperado) / 1024:.1f} KB, {time.monotonic() - t0:.1f} s).")

    if args.datos:
        carpeta_cal = Path(args.datos) / "train"
    elif args.carpeta:
        carpeta_cal = Path(args.carpeta)
    else:
        raise ValueError("Para calibrar la cuantización se necesita --datos (usa train/) o --carpeta.")
    imagenes = cargar_carpeta(carpeta_cal, args.canales)
    print(f"Calibrando y cuantizando a INT8 en el micro con {min(args.n_calibracion, len(imagenes))} "
          f"imágenes de {carpeta_cal}...")
    puente.usar_modelo("mcu_float")
    esc, zp, n_cal, ram_int8 = calibrar_y_cuantizar(args, puente, imagenes)
    print(f"  INT8 listo: escala de salida {esc:.5f}, zp {zp}, {n_cal} muestras, "
          f"{ram_int8 / 1024:.1f} KB")


# ============================================================
# MODO ENTRENAR
# ============================================================
def modo_entrenar(args, puente):
    raiz = Path(args.datos)
    train = cargar_carpeta(raiz / "train", args.canales, args.limite)
    val = cargar_carpeta(raiz / "validation", args.canales)
    test = cargar_carpeta(raiz / "test", args.canales) if (raiz / "test").is_dir() else val
    print(f"Datos: {len(train)} entrenamiento, {len(val)} validación, {len(test)} prueba | "
          f"aumento de datos: {'sí' if args.aumento else 'no'}")
    if len(train) < 1000:
        print(f"  AVISO: solo {len(train)} imágenes de entrenamiento (¿usaste --limite?). "
              "Con pocas imágenes la red memoriza y falla en validación.")

    puente.comando(P.CMD_INICIAR_PESOS, struct.pack("<I", args.semilla_pesos))
    puente.usar_modelo("mcu_float")
    rng = random.Random(args.semilla)
    historia, t_pasos, filas = [], [], []
    mejor_val, sin_mejora = float("inf"), 0
    t0 = time.monotonic()

    for e in range(args.epocas):
        tasa = args.tasa * args.decaimiento ** e
        orden = list(range(len(train)))
        rng.shuffle(orden)
        perdidas, aciertos, t_ep = [], 0, time.monotonic()
        for n, i in enumerate(orden, 1):
            px, k, nombre = train[i]
            if args.aumento:
                px = aumentar(px, rng)
            r = puente.muestra(px, k, tasa, e + 1, args.canales)
            perdidas.append(r["perdida"])
            aciertos += r["pred"] == k
            t_pasos.append(r["t_paso"])
            filas.append(dict(epoca=e + 1, imagen=nombre, etiqueta=k, pred=r["pred"],
                              perdida=round(r["perdida"], 5), t_captura=r["t_captura"],
                              t_preproc=r["t_preproc"], t_paso=r["t_paso"]))
            if n % 200 == 0:
                print(f"    época {e + 1}: {n}/{len(train)}  pérdida media {np.mean(perdidas):.4f}",
                      end="\r", flush=True)
        # Validación con los pesos float actuales
        vp, va = [], 0
        for px, k, _ in val:
            tel = puente.clasificar(px, args.canales)
            vp.append(-math.log(max(tel["prob"][k], 1e-7)))
            va += tel["clase"] == k
        h = dict(epoca=e + 1, tasa=tasa, loss=float(np.mean(perdidas)), acc=aciertos / len(train),
                 val_loss=float(np.mean(vp)), val_acc=va / len(val), t_epoca_s=time.monotonic() - t_ep,
                 t_computo_micro_s=sum(t_pasos[-len(train):]) / 1e6)
        historia.append(h)
        print(f"\r  Época {e + 1:2d}/{args.epocas} | tasa {tasa:.4f} | loss {h['loss']:.4f} acc {h['acc']:.4f} | "
              f"val_loss {h['val_loss']:.4f} val_acc {h['val_acc']:.4f} | {h['t_epoca_s']:.0f} s "
              f"(cómputo en el micro {h['t_computo_micro_s']:.1f} s)")
        if args.paciencia:
            if h["val_loss"] < mejor_val - 1e-4:
                mejor_val, sin_mejora = h["val_loss"], 0
            else:
                sin_mejora += 1
                if sin_mejora >= args.paciencia:
                    print(f"  Parada temprana: {args.paciencia} épocas sin mejorar la validación.")
                    break
    t_total = time.monotonic() - t0

    # ---- Calibración y cuantización INT8 en el micro ----
    print("Calibrando rangos de activación y cuantizando a INT8 en el micro...")
    esc, zp, n_cal, ram_int8 = calibrar_y_cuantizar(args, puente, train)

    # ---- Descargar los pesos y comprobarlos en la PC ----
    print("Descargando los pesos entrenados en el micro...")
    pesos = pesos_mcu.desempaquetar(puente.comando(P.CMD_SUBIR_PESOS)["datos"])
    ruta_keras = pesos_mcu.guardar(pesos, puente.carpeta)
    gris_test = np.stack([px if px.ndim == 2 else np.asarray(Image.fromarray(px).convert("L")) for px, _, _ in test])
    pred_np = pesos_mcu.inferir(pesos, gris_test).argmax(axis=1)
    acc_np = float(np.mean(pred_np == np.array([k for _, k, _ in test])))

    # ---- Comparación de modelos en el conjunto de prueba ----
    hw = puente.hw or {}
    candidatos = [("mcu_float", "Float32 (micro)", hw.get("ram_pesos", 0), "RAM"),
                  ("mcu_int8", "INT8 (micro)", ram_int8, "RAM"),
                  ("pc", "INT8 (PC)", hw.get("flash_modelo", 0), "Flash")]
    modelos, detalle = {}, {}
    for clave, nombre, mem, donde in candidatos:
        print(f"Evaluando {nombre} en el conjunto de prueba...")
        puente.usar_modelo(clave)
        r = evaluar_conjunto(args, puente, test, f"prueba_{clave}", f"{nombre}, prueba")
        detalle[clave] = r
        modelos[nombre] = dict(accuracy=r["percepcion"]["accuracy"], f1_macro=r["percepcion"]["f1_macro"],
                               confianza=r["percepcion"]["confianza_promedio"],
                               t_inferencia_ms=r["computo"]["t_inferencia_ms"]["media"],
                               memoria_kb=mem / 1024, donde=donde)
    M.graficar_comparacion(modelos, puente.carpeta)
    pred_float = [f["clase_pred"] for f in
                  csv.DictReader(open(puente.carpeta / "prueba_mcu_float_telemetria.csv", encoding="utf-8"))]
    coincide = float(np.mean(np.array(pred_float, int) == pred_np))

    puente.usar_modelo("mcu_int8")             # el modelo entrenado y cuantizado en el micro
    # Archivos grandes y gráficas al final, para no dejar al micro esperando a la mitad
    guardar_csv(filas, puente.carpeta / "entrenamiento_pasos.csv")
    M.graficar_curvas(historia, puente.carpeta)
    ult = historia[-1]
    ent = dict(epocas=len(historia), tasa_inicial=args.tasa, decaimiento=args.decaimiento,
               accuracy_entrenamiento=ult["acc"], accuracy_validacion=ult["val_acc"],
               loss_entrenamiento=ult["loss"], loss_validacion=ult["val_loss"],
               n_parametros=hw.get("n_parametros", 51508),
               tiempo_entrenamiento_micro_s=sum(t_pasos) / 1e6, tiempo_entrenamiento_total_s=t_total,
               t_paso_medio_ms=float(np.mean(t_pasos)) / 1000, historia=historia,
               cuantizacion=dict(escala_salida=esc, zp_salida=zp, muestras_calibracion=n_cal,
                                 ram_int8_kb=ram_int8 / 1024),
               verificacion_pc=dict(accuracy_numpy=acc_np, coincidencia_con_micro=coincide,
                                    keras=str(ruta_keras) if ruta_keras else None))
    return dict(entrenamiento=ent, modelos=modelos, evaluacion_prueba=detalle)


# ============================================================
# MODO NAVEGAR
# ============================================================
def imagen_oraculo(etiqueta, res):
    """Solo para --prueba-oraculo: imagen uniforme que codifica la clase correcta."""
    valor = 225 if etiqueta is None else 25 + 50 * etiqueta
    return np.full((res, res, 3), valor, np.uint8)


def crear_robot(args):
    if args.prueba_oraculo:
        return RobotCinematico(*INICIO), None
    from coppeliasim_zmqremoteapi_client import RemoteAPIClient
    cliente = RemoteAPIClient(host=args.host_coppelia, port=args.puerto_coppelia)
    sim = cliente.require("sim")
    escena = Escena(sim, ESTACIONES, LIMITES, permitir_pioneer=(args.robot == "pioneer"))
    if args.robot == "pioneer":
        return RobotPioneer(cliente, sim, escena, args.resolucion, args.modelo_pioneer), escena
    return RobotCinematico(*INICIO, escena=escena, resolucion=args.resolucion), escena


def modo_navegar(args, puente, modelo=None):
    robot, escena = crear_robot(args)
    puente.configurar_robot(robot)
    puente.usar_modelo(modelo or args.modelo)
    print(f"Robot: {robot.nombre} (radio {robot.radio:.4f} m, eje {robot.eje:.4f} m)")

    corridas, filas_todas = [], []
    rng = random.Random(args.semilla)
    try:
        for n in range(args.corridas):
            mision = Mision(ESTACIONES, rng if (args.variar and n > 0) else None)
            if escena:
                robot.terminar()
                for e in mision.est:
                    escena.colocar_estacion(e, True)
            robot.colocar(*INICIO)
            robot.iniciar()
            ruta_ref = mision.ruta_referencia()
            print(f"\n=== Corrida {n + 1}/{args.corridas} ===")
            res = correr(args, puente, robot, escena, mision, ruta_ref, n)
            corridas.append(res[0])
            filas_todas += res[1]
    finally:
        robot.terminar()

    umbral = puente.hw["umbral"] if puente.hw else 0.7
    for i, c in enumerate(corridas):
        M.graficar_series(c, puente.carpeta, umbral, i + 1)
    etiquetadas = [f for f in filas_todas if f["con_imagen"] and f["clase_real"] >= 0]
    mp = (M.metricas_percepcion([f["clase_real"] for f in etiquetadas], [f["clase_pred"] for f in etiquetadas],
                                [f["conf"] for f in etiquetadas], umbral) if etiquetadas else {})
    if mp:
        M.graficar_percepcion(mp, puente.carpeta, "cuadros con señal durante la navegación", "navegacion")
    mc = M.metricas_computo(filas_todas, puente.hw, args.corriente_ma, args.corriente_reposo_ma, args.voltaje)
    M.graficar_computo(filas_todas, mc, puente.carpeta, "navegacion")
    mn = M.resumen_navegacion(corridas)
    M.graficar_trayectorias(corridas, ESTACIONES, Mision(ESTACIONES).ruta_referencia(), LIMITES, puente.carpeta)
    guardar_csv(filas_todas, puente.carpeta / "navegacion_telemetria.csv")
    detalle = [{k: v for k, v in c.items() if k not in ("x", "y", "t", "v", "w", "w_izq", "w_der",
                                                          "conf", "clase", "puntos_colision")}
               for c in corridas]
    return dict(percepcion=mp, computo=mc, navegacion=mn, corridas=detalle,
                robot=dict(nombre=robot.nombre, radio=robot.radio, eje=robot.eje))


def guardar_foto(px, t_sim, etiqueta, tel, dist, carpeta, cerca):
    """Guarda la foto tal como la tomó la cámara y, si había una señal cerca, la versión
    64x64 que ve la CNN para la hoja de diagnóstico."""
    real = "ninguna" if etiqueta is None else CLASES[etiqueta]
    pred = CLASES[tel["clase"]] if tel["clase"] < len(CLASES) else "?"
    d = "sin" if dist is None else f"{dist:.2f}"
    nombre = f"{t_sim:07.2f}s_real-{real}_pred-{pred}_{tel['conf']:.2f}_d{d}m.png"
    Image.fromarray(px).save(carpeta / nombre)
    if etiqueta is not None or (dist is not None and dist <= 2.5):
        g = Image.fromarray(px).convert("L")
        if g.size != (64, 64):
            g = g.resize((64, 64), Image.LANCZOS)          # lo mismo que hace el micro
        color = "gray" if etiqueta is None else ("green" if tel["clase"] == etiqueta else "red")
        cerca.append((np.asarray(g), f"t={t_sim:.1f}s d={d}\nreal {real}\npred {pred} {tel['conf']:.2f}", color))


def hoja_de_fotos(fotos, ruta, maximo=40):
    import matplotlib.pyplot as plt
    if not fotos:
        return
    idx = np.linspace(0, len(fotos) - 1, min(maximo, len(fotos))).round().astype(int)
    n = len(idx)
    cols = 8
    filas = int(np.ceil(n / cols))
    fig, axs = plt.subplots(filas, cols, figsize=(cols * 1.9, filas * 2.4), squeeze=False)
    for a in axs.flat:
        a.axis("off")
    for a, i in zip(axs.flat, idx):
        img, texto, color = fotos[i]
        a.imshow(img, cmap="gray", vmin=0, vmax=255)
        a.set_title(texto, fontsize=7, color=color)
    fig.suptitle("Lo que vio la CNN (64x64) cerca de las señales  |  verde = correcto, rojo = error, "
                 "gris = sin señal a la vista", fontsize=10)
    fig.tight_layout()
    fig.savefig(ruta, dpi=120)
    plt.close(fig)


def correr(args, puente, robot, escena, mision, ruta_ref, n):
    reinicio, t_pared_prev, etiqueta_pend, dist_pend, px_pend = True, None, None, None, None
    seq_atendida, reenviar_nav = None, (lambda: None)
    fotos_cerca = []                     # (imagen 64x64 que ve la CNN, texto, color) cerca de señales
    carpeta_fotos = puente.carpeta / "fotos" / f"corrida{n + 1}"
    if args.guardar_fotos:
        carpeta_fotos.mkdir(parents=True, exist_ok=True)
    pose = (robot.x, robot.y, robot.th)
    datos = dict(x=[pose[0]], y=[pose[1]], t=[], v=[], w=[], w_izq=[], w_der=[], conf=[], clase=[],
                 eventos_decision=[], puntos_colision=[])
    filas, colisiones, incorrectas, paradas, distancia = [], 0, 0, 0, 0.0
    errores, moviendo_prev = [], False
    t_inicio_pared = time.monotonic()

    while mision.resultado is None and robot.t_sim < args.tiempo_max:
        tipo, d = puente.esperar_mensaje()
        if tipo in (P.MSG_PEDIR_FOTO, P.MSG_PEDIR_ODOM):
            seq = P.secuencia(d)
            if seq == seq_atendida:
                reenviar_nav()           # petición repetida: se reenvía la misma respuesta
                continue                 # (si ya le había llegado, el micro la descarta)
            seq_atendida = seq
            banderas = P.BANDERA_REINICIO if reinicio else 0
            reinicio = False
            ei, ed = robot.encoders()
            imu = float("nan") if args.sin_imu else pose[2]      # giroscopio: orientación del robot
            if tipo == P.MSG_PEDIR_FOTO:
                etiqueta_pend = mision.etiqueta(robot, pose)
                img = imagen_oraculo(etiqueta_pend, args.resolucion) if args.prueba_oraculo else robot.capturar()
                px = px_pend = preparar_pixeles(img, args.canales)
                dist_pend = None if args.sin_sensor_distancia else distancia_frontal(*pose, mision.cajas())
                cab = (px.tobytes(), px.shape[1], px.shape[0], args.canales, ei, ed, seq, banderas,
                       0xFFFF if dist_pend is None else min(int(dist_pend * 1000), 0xFFFE), imu)
                reenviar_nav = lambda cab=cab: P.foto(puente.t, *cab)
                reenviar_nav()
            else:
                etiqueta_pend, dist_pend, px_pend = None, None, None
                reenviar_nav = lambda a=(ei, ed, seq, banderas, imu): P.odom(puente.t, *a)
                reenviar_nav()
            continue
        if tipo != P.MSG_MOTORES:
            P.ack(puente.t)
            continue

        # ---- Comando de motores del micro ----
        tel = P.decodificar_motores(d)
        if tel["id"] != seq_atendida:     # telemetría atrasada de otra petición
            P.ack(puente.t)
            continue
        ahora = time.monotonic()
        dt = args.dt if args.modo_tiempo == "sincrono" else min(ahora - (t_pared_prev or ahora), 1.5)
        t_pared_prev = ahora
        t_sim = robot.t_sim

        dec = P.DECISIONES[tel["decision"]] if tel["decision"] < len(P.DECISIONES) else "ninguna"
        dec_ok = None
        if dec != "ninguna":
            dec_ok = mision.evaluar_decision(robot, dec, pose)
            incorrectas += 0 if dec_ok else 1
            datos["eventos_decision"].append(dict(x=pose[0], y=pose[1], decision=dec, correcta=dec_ok))
            print(f"  t={t_sim:6.1f}s  decisión: {dec:<9} {'correcta' if dec_ok else 'INCORRECTA'}"
                  f"  (conf {tel['conf']:.2f})")

        if robot.avanzar(tel["w_izq"], tel["w_der"], dt, mision.cajas()):
            colisiones += 1
            datos["puntos_colision"].append((robot.x, robot.y))
            print(f"  t={robot.t_sim:6.1f}s  ¡COLISIÓN!")
        nueva = (robot.x, robot.y, robot.th)
        distancia += math.hypot(nueva[0] - pose[0], nueva[1] - pose[1])
        pose = nueva
        quieto = abs(tel["w_izq"]) < 1e-6 and abs(tel["w_der"]) < 1e-6
        if quieto and moviendo_prev:
            paradas += 1
        moviendo_prev = not quieto
        om = mision.actualizar(robot, pose, quieto, dt, escena)
        if om:
            incorrectas += om
            datos["eventos_decision"].append(dict(x=pose[0], y=pose[1], decision="omisión", correcta=False))
            print(f"  t={robot.t_sim:6.1f}s  decisión omitida en {mision.estacion_activa()['nombre']}")

        err = M.distancia_a_polilinea(pose[0], pose[1], ruta_ref)
        errores.append(err)
        for k, v in [("x", pose[0]), ("y", pose[1]), ("t", robot.t_sim), ("v", tel["v"]), ("w", tel["w"]),
                     ("w_izq", tel["w_izq"]), ("w_der", tel["w_der"]), ("conf", tel["conf"]),
                     ("clase", tel["clase"])]:
            datos[k].append(v)
        fila = fila_telemetria(tel, dict(corrida=n + 1, t_sim=round(robot.t_sim, 3), x=round(pose[0], 4),
                                         y=round(pose[1], 4), th=round(pose[2], 4),
                                         clase_real=-1 if etiqueta_pend is None else etiqueta_pend,
                                         dist_frontal=-1 if dist_pend is None else round(dist_pend, 3)))
        fila.update(decision_correcta="" if dec_ok is None else int(dec_ok),
                    colision=int(robot.en_contacto), error_tray=round(err, 4))
        filas.append(fila)
        if args.guardar_fotos and tel["con_imagen"] and px_pend is not None:
            guardar_foto(px_pend, t_sim, etiqueta_pend, tel, dist_pend, carpeta_fotos, fotos_cerca)
        P.ack(puente.t)

    if args.guardar_fotos:
        hoja_de_fotos(fotos_cerca, puente.carpeta / f"fotos_cerca_de_senales_corrida{n + 1}.png")
        print(f"Fotos guardadas en: {carpeta_fotos}")
    exito = mision.resultado == "exito" and colisiones == 0
    motivo = {"exito": "llegó a la meta", "meta_incompleta": "llegó a la meta sin completar el circuito",
              None: "tiempo agotado"}[mision.resultado]
    e = np.array(errores) if errores else np.zeros(1)
    res = dict(tiempo_recorrido_s=robot.t_sim, colisiones=colisiones, decisiones_incorrectas=incorrectas,
               error_tray_medio_m=float(e.mean()), error_tray_rms_m=float(np.sqrt((e ** 2).mean())),
               error_tray_max_m=float(e.max()), distancia_m=distancia, paradas=paradas,
               exito=bool(exito), motivo=motivo, tiempo_pared_s=time.monotonic() - t_inicio_pared,
               estaciones_completadas=sorted(mision.completadas))
    print(f"Corrida {n + 1}: {'ÉXITO' if exito else 'FALLO'} ({motivo}) | {robot.t_sim:.1f} s | "
          f"{colisiones} colisiones | {incorrectas} decisiones incorrectas | {distancia:.2f} m")
    return {**datos, **res}, filas


# ============================================================
# RESUMEN
# ============================================================
def escribir_resumen(res, args, carpeta):
    L = []
    pct = lambda v: f"{100 * v:.1f} %"
    en = res.get("entrenamiento")
    if en:
        L += ["ENTRENAMIENTO EN EL MICROCONTROLADOR",
              f"  Épocas                     : {en['epocas']} (tasa {en['tasa_inicial']} x {en['decaimiento']}^época, SGD batch 1)",
              f"  Accuracy entrenamiento     : {en['accuracy_entrenamiento']:.4f}   (promedio de la última época)",
              f"  Accuracy validación        : {en['accuracy_validacion']:.4f}",
              f"  Loss entrenamiento         : {en['loss_entrenamiento']:.4f}",
              f"  Loss validación            : {en['loss_validacion']:.4f}",
              f"  Número de parámetros       : {en['n_parametros']:,}",
              f"  Tiempo de entrenamiento    : {en['tiempo_entrenamiento_micro_s']:.1f} s de cómputo en el micro "
              f"({en['t_paso_medio_ms']:.2f} ms por imagen); {en['tiempo_entrenamiento_total_s']:.1f} s en total "
              "con la transferencia de imágenes",
              f"  Cuantización INT8          : {en['cuantizacion']['muestras_calibracion']} imágenes de calibración, "
              f"modelo de {en['cuantizacion']['ram_int8_kb']:.1f} KB",
              f"  Verificación en la PC      : accuracy con los pesos descargados {en['verificacion_pc']['accuracy_numpy']:.4f}, "
              f"misma predicción que el micro en {pct(en['verificacion_pc']['coincidencia_con_micro'])}"]
        if en["verificacion_pc"]["keras"]:
            L.append(f"  Modelo de Keras guardado   : {en['verificacion_pc']['keras']}")
        L += ["", "COMPARACIÓN DE MODELOS EN EL MICRO (conjunto de prueba)",
              f"  {'Modelo':<18}{'Accuracy':>10}{'F1':>8}{'Confianza':>11}{'Inferencia':>13}{'Memoria':>16}"]
        for nombre, m in res["modelos"].items():
            L.append(f"  {nombre:<18}{m['accuracy']:>10.4f}{m['f1_macro']:>8.4f}{m['confianza']:>11.4f}"
                     f"{m['t_inferencia_ms']:>10.2f} ms{m['memoria_kb']:>9.1f} KB {m['donde']}")
        L.append("")
    mp, mc, mn = res.get("percepcion"), res.get("computo"), res.get("navegacion")
    if mp:
        L += ["DESEMPEÑO DE PERCEPCIÓN", f"  Cuadros evaluados   : {mp['n']}",
              f"  Accuracy            : {mp['accuracy']:.4f}",
              f"  Precision (macro)   : {mp['precision_macro']:.4f}",
              f"  Recall (macro)      : {mp['recall_macro']:.4f}",
              f"  F1-score (macro)    : {mp['f1_macro']:.4f}",
              f"  Confianza promedio  : {mp['confianza_promedio']:.4f} "
              f"(aciertos {mp['confianza_aciertos']:.3f}, errores {mp['confianza_errores']:.3f})",
              f"  Bajo el umbral      : {pct(mp['bajo_umbral'])}",
              "  Por clase           :   precision  recall    F1"]
        for k, c in enumerate(CLASES):
            L.append(f"    {c:<18}:   {mp['precision'][k]:.3f}      {mp['recall'][k]:.3f}    {mp['f1'][k]:.3f}")
        L.append("  Matriz de confusión (filas = real, columnas = predicción):")
        for k, c in enumerate(CLASES):
            L.append(f"    {c:<10} " + " ".join(f"{v:5d}" for v in mp["matriz_confusion"][k]))
        L.append("")
    if mc:
        L += ["DESEMPEÑO COMPUTACIONAL" + ("  (firmware ejecutado en la PC: tiempos NO representan al S32K344)"
                                           if mc.get("en_pc") else "")]
        for clave, nombre in [("t_captura_ms", "Tiempo de captura"), ("t_preproc_ms", "Tiempo de preprocesamiento"),
                              ("t_inferencia_ms", "Tiempo de inferencia"), ("t_control_ms", "Tiempo de control"),
                              ("latencia_total_ms", "Latencia total")]:
            s = mc[clave]
            L.append(f"  {nombre:<27}: {s['media']:9.3f} ms (desv {s['desv']:.3f}, p95 {s['p95']:.3f}, máx {s['max']:.3f})")
        L += [f"  FPS (lazo completo)        : {mc['fps_lazo']:.2f}",
              f"  FPS (solo cómputo)         : {mc['fps_solo_computo']:.1f}",
              f"  Carga de CPU               : {pct(mc['carga_cpu'])}"]
        if "ram_total_kb" in mc:
            L += [f"  RAM total del firmware     : {mc['ram_total_kb']:.1f} KB = pesos float {mc['ram_pesos_kb']:.1f} + "
                  f"memoria de trabajo {mc['ram_trabajo_kb']:.1f} + INT8 del micro {mc['ram_int8_mcu_kb']:.1f} + "
                  f"preprocesamiento {mc['ram_preproc_kb']:.1f} + imagen {mc['ram_imagen_kb']:.1f}",
                  f"  Flash del modelo de la PC  : {mc['flash_modelo_kb']:.1f} KB ({mc['n_parametros']:,} parámetros)",
                  f"  Autoprueba de la CNN       : {mc['autoprueba']}"]
        if args.flash_total_kb or args.ram_total_kb:
            L.append(f"  Programa completo (.map)   : Flash {args.flash_total_kb or '-'} KB, RAM {args.ram_total_kb or '-'} KB")
        if "energia_por_cuadro_mj" in mc:
            L += [f"  Potencia activa            : {mc['potencia_activa_mw']:.1f} mW",
                  f"  Energía por inferencia     : {mc['energia_inferencia_mj']:.3f} mJ",
                  f"  Energía por cuadro         : {mc['energia_por_cuadro_mj']:.3f} mJ",
                  f"  Potencia media             : {mc['potencia_media_mw']:.1f} mW"]
        else:
            L.append("  Consumo energético         : indica --corriente-ma (medida en la tarjeta) para calcularlo")
        L.append("")
    if mn:
        L += ["DESEMPEÑO DE NAVEGACIÓN" + (f"  (promedio de {mn['corridas']} corridas)" if mn["corridas"] > 1 else ""),
              f"  Robot                      : {res['robot']['nombre']}",
              f"  Tiempo de recorrido        : {mn['tiempo_recorrido_s']:.1f} s (tiempo simulado)",
              f"  Número de colisiones       : {mn['colisiones']:.2f}",
              f"  Decisiones incorrectas     : {mn['decisiones_incorrectas']:.2f}",
              f"  Error de trayectoria       : medio {mn['error_tray_medio_m']:.3f} m, RMS "
              f"{mn['error_tray_rms_m']:.3f} m, máx {mn['error_tray_max_m']:.3f} m",
              f"  Distancia recorrida        : {mn['distancia_m']:.2f} m",
              f"  Número de paradas          : {mn['paradas']:.2f}",
              f"  Éxito de navegación        : {pct(mn['exito_navegacion'])}"]
        for i, c in enumerate(res["corridas"]):
            L.append(f"    Corrida {i + 1}: {'éxito' if c['exito'] else 'fallo'} - {c['motivo']} "
                     f"(estaciones completadas: {', '.join(c['estaciones_completadas']) or 'ninguna'})")
    texto = "\n".join(L)
    (carpeta / "resumen.txt").write_text(texto, encoding="utf-8")
    (carpeta / "metricas.json").write_text(json.dumps(res, indent=2, ensure_ascii=False, default=float),
                                          encoding="utf-8")
    return texto


def main():
    p = argparse.ArgumentParser(description="Puente entre el S32K344 y CoppeliaSim.")
    p.add_argument("modo", choices=["entrenar", "evaluar", "navegar"])
    con = p.add_mutually_exclusive_group(required=True)
    con.add_argument("--serie", help="puerto serie de la tarjeta (p. ej. COM5 o /dev/ttyACM0)")
    con.add_argument("--tcp", type=int, help="puerto TCP para el firmware compilado en la PC")
    p.add_argument("--baudios", type=int, default=921600)
    p.add_argument("--canales", type=int, choices=[1, 3], default=1,
                   help="1 = se manda en gris (3 veces menos datos), 3 = RGB")
    p.add_argument("--modelo", choices=list(P.MODELOS), default="pc",
                   help="modelo para evaluar/navegar: pc, mcu_float o mcu_int8")
    # entrenar
    p.add_argument("--datos", help="carpeta con train/, validation/ y test/ (entrenar)")
    p.add_argument("--epocas", type=int, default=30)
    p.add_argument("--tasa", type=float, default=0.01, help="tasa de aprendizaje inicial (SGD)")
    p.add_argument("--decaimiento", type=float, default=0.97, help="factor de la tasa por época")
    p.add_argument("--paciencia", type=int, default=0, help="parada temprana (0 = desactivada)")
    p.add_argument("--semilla-pesos", type=int, default=42)
    p.add_argument("--n-calibracion", type=int, default=200, help="imágenes para calibrar la cuantización")
    p.add_argument("--cargar-pesos", help="(evaluar/navegar) archivo pesos_entrenados_en_mcu.npz para "
                   "volver a cargar en el micro la red que entrenó; se usa con --modelo mcu_float o mcu_int8")
    p.add_argument("--navegar", action="store_true", help="después de entrenar, recorrer el circuito")
    p.add_argument("--aumento", action="store_true",
                   help="aplicar aumento de datos (brillo, contraste, zoom, desplazamiento, rotación); "
                        "da robustez pero necesita más épocas")
    # evaluar
    p.add_argument("--carpeta", help="carpeta con subcarpetas por clase (evaluar)")
    p.add_argument("--limite", type=int, default=0, help="usar solo N imágenes")
    # navegar
    p.add_argument("--robot", choices=["pioneer", "cinematico"], default="pioneer")
    p.add_argument("--modelo-pioneer", help="ruta al archivo 'pioneer p3dx.ttm' si no se encuentra solo")
    p.add_argument("--resolucion", type=int, default=320, help="resolución de la cámara")
    p.add_argument("--guardar-fotos", action="store_true",
                   help="guardar cada foto de la cámara y una hoja con lo que vio la CNN cerca de las señales")
    p.add_argument("--sin-imu", action="store_true",
                   help="no mandar el giroscopio (el micro estima la orientación solo con los encoders)")
    p.add_argument("--sin-sensor-distancia", action="store_true",
                   help="no mandar el sensor de distancia frontal (el micro decide solo con la CNN)")
    p.add_argument("--corridas", type=int, default=1)
    p.add_argument("--variar", action="store_true", help="mover un poco las señales entre corridas")
    p.add_argument("--semilla", type=int, default=1)
    p.add_argument("--modo-tiempo", choices=["sincrono", "tiempo_real"], default="sincrono",
                   help="sincrono: cada comando dura --dt s simulados; tiempo_real: lo que tarda el ciclo")
    p.add_argument("--dt", type=float, default=0.4, help="periodo de control simulado (s)")
    p.add_argument("--tiempo-max", type=float, default=240.0, help="tiempo simulado máximo por corrida")
    p.add_argument("--host-coppelia", default="localhost")
    p.add_argument("--puerto-coppelia", type=int, default=23000)
    # energía y memoria
    p.add_argument("--corriente-ma", type=float, help="corriente del micro en ejecución (mA), medida")
    p.add_argument("--corriente-reposo-ma", type=float, help="corriente esperando datos (mA), medida")
    p.add_argument("--voltaje", type=float, default=3.3)
    p.add_argument("--flash-total-kb", type=float, help="Flash del programa completo (del .map)")
    p.add_argument("--ram-total-kb", type=float, help="RAM del programa completo (del .map)")
    p.add_argument("--salida", default="resultados_mcu")
    p.add_argument("--prueba-oraculo", action="store_true", help=argparse.SUPPRESS)
    args = p.parse_args()
    if args.modo == "evaluar" and not args.carpeta:
        p.error("El modo evaluar necesita --carpeta")
    if args.modo == "entrenar" and not args.datos:
        p.error("El modo entrenar necesita --datos")
    if args.cargar_pesos and args.modo == "entrenar":
        p.error("--cargar-pesos es para evaluar o navegar (entrenar empieza con pesos nuevos)")
    if args.cargar_pesos and not (args.datos or args.carpeta):
        p.error("--cargar-pesos necesita --datos (o --carpeta) para calibrar la cuantización INT8")

    carpeta = Path(args.salida) / f"{datetime.now():%Y%m%d_%H%M%S}_{args.modo}"
    carpeta.mkdir(parents=True, exist_ok=True)
    t = P.TransporteTCP(args.tcp) if args.tcp else P.TransporteSerie(args.serie, args.baudios)
    puente = Puente(t, carpeta)
    try:
        if args.cargar_pesos:
            cargar_pesos_en_micro(args, puente)
        if args.modo == "entrenar":
            res = modo_entrenar(args, puente)
            if args.navegar:
                res.update(modo_navegar(args, puente, modelo="mcu_int8"))
        elif args.modo == "evaluar":
            res = modo_evaluar(args, puente)
        else:
            res = modo_navegar(args, puente)
    finally:
        t.cerrar()
    if puente.hw:
        res["hardware"] = puente.hw
    print("\n" + escribir_resumen(res, args, carpeta))
    print(f"\nResultados guardados en: {carpeta.resolve()}")


if __name__ == "__main__":
    main()
