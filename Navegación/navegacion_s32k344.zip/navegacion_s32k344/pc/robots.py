"""
robots.py - Entorno de CoppeliaSim y los dos robots que puede usar el puente.

  RobotPioneer      Pioneer P3DX de la biblioteca de CoppeliaSim, con física. El micro
                    manda velocidades de rueda que se aplican a sus motores
                    (leftMotor / rightMotor). Los encoders salen de los ángulos de las
                    articulaciones y las colisiones del motor de colisiones.
  RobotCinematico   robot diferencial ideal (sin física). Sirve para probar todo sin
                    CoppeliaSim; con CoppeliaSim dibuja el robot de captura original.
"""
import math
import time

import numpy as np

TICKS_POR_VUELTA = 2048
ALTURA_CAMARA = 0.45          # misma altura que en la captura del dataset
CAMARA_ADELANTE = 0.20        # cámara 0.20 m delante del centro del eje
ALTURA_MUROS = 15.0           # muros altos para que no se vea el cielo (ver Escena)
ALCANCE_CAMARA = 30.0         # plano lejano de la cámara: los muros más lejanos están a ~20 m

PATRONES = {
    "avanzar": ["0001000", "0011100", "0111110", "0001000", "0001000", "0001000", "0001000"],
    "izquierda": ["0001000", "0011000", "0111111", "1111111", "0111111", "0011000", "0001000"],
    "derecha": ["0001000", "0001100", "1111110", "1111111", "1111110", "0001100", "0001000"],
}


# ============================================================
# GEOMETRÍA 2D
# ============================================================
def caja(cx, cy, largo, ancho, ang):
    return (cx, cy, largo / 2, ancho / 2, ang)


def choca(px, py, c, r):
    cx, cy, hx, hy, a = c
    dx, dy = px - cx, py - cy
    lx = dx * math.cos(a) + dy * math.sin(a)
    ly = -dx * math.sin(a) + dy * math.cos(a)
    qx, qy = max(-hx, min(hx, lx)), max(-hy, min(hy, ly))
    return (lx - qx) ** 2 + (ly - qy) ** 2 <= r * r


def _rayo_caja(ox, oy, dx, dy, c):
    """Distancia a lo largo del rayo hasta la caja c (o None si no la toca)."""
    cx, cy, hx, hy, a = c
    ca, sa = math.cos(a), math.sin(a)
    px, py = (ox - cx) * ca + (oy - cy) * sa, -(ox - cx) * sa + (oy - cy) * ca
    vx, vy = dx * ca + dy * sa, -dx * sa + dy * ca
    t0, t1 = -math.inf, math.inf
    for p, v, h in ((px, vx, hx), (py, vy, hy)):
        if abs(v) < 1e-12:
            if abs(p) > h:
                return None
            continue
        ta, tb = (-h - p) / v, (h - p) / v
        t0, t1 = max(t0, min(ta, tb)), min(t1, max(ta, tb))
    if t0 > t1 or t1 < 0:
        return None
    return max(t0, 0.0)


def distancia_frontal(x, y, th, cajas, alcance=5.0, cono_grados=10.0, n_rayos=5):
    """Sensor de distancia frontal (como un sonar del Pioneer P3DX): abanico de rayos
    desde el centro del robot; devuelve la distancia al objeto más cercano (m)."""
    mejor = alcance
    for i in range(n_rayos):
        a = th + math.radians(cono_grados) * (i / (n_rayos - 1) - 0.5) * 2
        dx, dy = math.cos(a), math.sin(a)
        for c in cajas:
            d = _rayo_caja(x, y, dx, dy, c)
            if d is not None and d < mejor:
                mejor = d
    return mejor


def camera_matrix(x, y, z, yaw):
    """Matriz del sensor de visión (columnas: derecha, arriba, adelante), como en la captura."""
    c, s = math.cos(yaw), math.sin(yaw)
    return [s, 0, c, x, -c, 0, s, y, 0, 1, 0, z]


def buscar(sim, ruta):
    """Handle del objeto con esa ruta de alias (p. ej. '/Panel_E1'), o None si no existe."""
    try:
        h = sim.getObject(ruta)
        return h if h is not None and h >= 0 else None
    except Exception:
        return None


def _envolver(a):
    return math.atan2(math.sin(a), math.cos(a))


# ============================================================
# ENTORNO EN COPPELIASIM
# ============================================================
class Escena:
    """Suelo, muros y estaciones (paneles con símbolo u obstáculos)."""

    def __init__(self, sim, estaciones, limites, permitir_pioneer=False):
        self.sim = sim
        self.mundo = sim.handle_world
        if sim.getSimulationState() != sim.simulation_stopped:
            raise RuntimeError("Detén la simulación antes de ejecutar.")

        # ¿La escena ya tiene el circuito (guardada de una ejecución anterior)?
        self.reutilizada = buscar(sim, "/Suelo") is not None
        if self.reutilizada:
            print("Escena existente: se usan los objetos que ya tiene (suelo, muros, estaciones, robot).")
        else:
            propias = set()
            if permitir_pioneer:
                p = buscar_pioneer(sim)
                if p is not None:
                    propias = set(sim.getObjectsInTree(p, sim.object_shape_type, 0))
            otras = [h for h in sim.getObjectsInTree(sim.handle_scene, sim.object_shape_type, 0)
                     if h not in propias]
            if otras:
                raise RuntimeError("La escena tiene objetos que no son del circuito. Abre la escena que "
                                   "guardaste del circuito, o una escena NUEVA sin el Floor.")
            print("Escena vacía: se crea el circuito.")

        x0, x1, y0, y1 = limites
        self._obtener_caja("Suelo", [x1 - x0 + 1, y1 - y0 + 1, .1], [(x0 + x1) / 2, (y0 + y1) / 2, -.05], [.48] * 3)
        self.muros = []
        # Muros altos: en la escena del dataset el muro de fondo tapaba casi toda la parte
        # alta de la imagen. Si aquí se viera el cielo (negro), la CNN vería algo que nunca
        # aprendió. Con 15 m de alto y la cámara a 0.45 m el cielo no aparece en el campo de visión.
        h = ALTURA_MUROS
        for nombre, tam, pos in [("MuroN", [x1 - x0, .1, h], [(x0 + x1) / 2, y1, h / 2]),
                                 ("MuroS", [x1 - x0, .1, h], [(x0 + x1) / 2, y0, h / 2]),
                                 ("MuroE", [.1, y1 - y0, h], [x1, (y0 + y1) / 2, h / 2]),
                                 ("MuroO", [.1, y1 - y0, h], [x0, (y0 + y1) / 2, h / 2])]:
            m = self._obtener_caja(nombre, tam, pos, [.7] * 3)
            self._asegurar_altura(m, pos)
            self.muros.append(m)

        self.objetos = {}
        for e in estaciones:
            if e["clase"] == "obstaculo":
                h = self._obtener_caja("Obstaculo_" + e["nombre"], [.3, .65, .75], [0, 0, .375], [.35, .22, .12])
            else:
                h = buscar(sim, "/Panel_" + e["nombre"])
                if h is None:
                    h = self._caja("Panel_" + e["nombre"], [.025, .66, .66], [0, 0, .45], [.92] * 3)
                    s = self._simbolo(e["clase"])
                    sim.setObjectPosition(s, self.mundo, [-.014, 0, .45])
                    sim.setObjectParent(s, h, True)          # el símbolo sigue al panel
            self.objetos[e["nombre"]] = h

    def _obtener_caja(self, nombre, tam, pos, rgb, respondable=True):
        """Usa el objeto de la escena si ya existe; si no, lo crea."""
        h = buscar(self.sim, "/" + nombre)
        return h if h is not None else self._caja(nombre, tam, pos, rgb, respondable)

    def _asegurar_altura(self, muro, pos):
        """Si la escena guardada tiene muros bajos (versión anterior), los sube a ALTURA_MUROS."""
        try:
            alto = float(self.sim.getShapeBB(muro)[2])
            if alto < ALTURA_MUROS - 0.1:
                self.sim.scaleObject(muro, 1.0, 1.0, ALTURA_MUROS / alto, 0)
                p = self.sim.getObjectPosition(muro, self.mundo)
                self.sim.setObjectPosition(muro, self.mundo, [p[0], p[1], ALTURA_MUROS / 2])
                print(f"  {self.sim.getObjectAlias(muro)}: altura {alto:.1f} m -> {ALTURA_MUROS:.0f} m")
        except Exception:
            pass

    def _caja(self, nombre, tam, pos, rgb, respondable=True):
        sim = self.sim
        h = sim.createPrimitiveShape(sim.primitiveshape_cuboid, tam, 0)
        sim.setObjectAlias(h, nombre)
        sim.setObjectInt32Param(h, sim.shapeintparam_static, 1)
        sim.setObjectInt32Param(h, sim.shapeintparam_respondable, 1 if respondable else 0)
        sim.setObjectPosition(h, self.mundo, pos)
        sim.setShapeColor(h, None, sim.colorcomponent_ambient_diffuse, rgb)
        return h

    def _simbolo(self, clase):
        vertices, indices = [], []
        for fila, celdas in enumerate(PATRONES[clase]):
            for col, celda in enumerate(celdas):
                if celda != "1":
                    continue
                y0, y1 = (3.5 - col) * .065, (2.5 - col) * .065
                z0, z1 = (3.5 - fila) * .065, (2.5 - fila) * .065
                b = len(vertices) // 3
                vertices.extend([0, y0, z0, 0, y1, z0, 0, y1, z1, 0, y0, z1])
                indices.extend([b, b + 1, b + 2, b, b + 2, b + 3])
        h = self.sim.createShape(0, 0, vertices, indices)
        self.sim.setObjectAlias(h, "Simbolo_" + clase)
        self.sim.setObjectInt32Param(h, self.sim.shapeintparam_static, 1)
        self.sim.setShapeColor(h, None, self.sim.colorcomponent_ambient_diffuse, [.04] * 3)
        return h

    def colocar_estacion(self, e, visible):
        h = self.objetos[e["nombre"]]
        z = (.375 if e["clase"] == "obstaculo" else .45) if visible else -8
        self.sim.setObjectPosition(h, self.mundo, [e["x"], e["y"], z])
        self.sim.setObjectOrientation(h, self.mundo, [0, 0, math.radians(e["rumbo"])])

    def crear_camara(self, resolucion):
        sensor = self.sim.createVisionSensor(1 + 2 + 4, [resolucion, resolucion, 0, 0],
                                             [.02, ALCANCE_CAMARA, math.radians(65), .03, 0, 0, .6, .6, .6, 0, 0])
        self.sim.setObjectAlias(sensor, "CamaraFrontal")
        return sensor

    def ajustar_camara(self, sensor):
        """Cámara que ya estaba en la escena: alcance suficiente para ver los muros lejanos."""
        try:
            self.sim.setObjectFloatParam(sensor, self.sim.visionfloatparam_far_clipping, ALCANCE_CAMARA)
        except Exception:
            pass

    def capturar(self, sensor):
        self.sim.handleVisionSensor(sensor)
        crudo, (w, h) = self.sim.getVisionSensorImg(sensor)
        arr = np.frombuffer(bytes(crudo), dtype=np.uint8).reshape(h, w, 3)
        return np.flipud(arr).copy()           # OpenGL tiene el origen abajo


# ============================================================
# ROBOT CINEMÁTICO (pruebas)
# ============================================================
class RobotCinematico:
    """Robot diferencial ideal: integra la cinemática directa con las velocidades de rueda."""
    nombre = "robot cinemático"
    radio, eje, w_max = 0.09, 0.36, 8.0
    radio_colision = 0.23

    def __init__(self, x, y, th, escena=None, resolucion=320):
        self.x, self.y, self.th = x, y, th
        self.phi_izq = self.phi_der = 0.0
        self.en_contacto = False
        self.t_sim = 0.0
        self.escena = escena
        self.sensor = None
        if escena and buscar(escena.sim, "/RobotDiferencial") is not None:     # ya existe en la escena
            self.cuerpo = buscar(escena.sim, "/RobotDiferencial")
            self.sensor = buscar(escena.sim, "/RobotDiferencial/CamaraFrontal")
            if self.sensor is None:
                raise RuntimeError("El robot de la escena no tiene la cámara 'CamaraFrontal'.")
            escena.ajustar_camara(self.sensor)
            self._dibujar()
        elif escena:                   # robot de captura original, solo para la imagen
            sim, w = escena.sim, escena.mundo
            self.cuerpo = escena._caja("RobotDiferencial", [.35, .28, .14], [0, 0, .16], [.12, .25, .55], False)
            for lado in (-1, 1):
                h = sim.createPrimitiveShape(sim.primitiveshape_cylinder, [.18, .18, .06], 0)
                sim.setObjectInt32Param(h, sim.shapeintparam_static, 1)
                sim.setObjectPosition(h, w, [0, lado * .18, .1])
                sim.setObjectOrientation(h, w, [math.pi / 2, 0, 0])
                sim.setShapeColor(h, None, sim.colorcomponent_ambient_diffuse, [.08] * 3)
                sim.setObjectParent(h, self.cuerpo, True)
            self.sensor = escena.crear_camara(resolucion)
            sim.setObjectMatrix(self.sensor, w, camera_matrix(CAMARA_ADELANTE, 0, ALTURA_CAMARA, 0))
            sim.setObjectParent(self.sensor, self.cuerpo, True)
            self._dibujar()

    def colocar(self, x, y, th):
        self.x, self.y, self.th = x, y, th
        self.en_contacto = False
        self.t_sim = 0.0
        self._dibujar()

    def iniciar(self):
        pass

    def terminar(self):
        pass

    def _dibujar(self):
        if self.escena:
            sim = self.escena.sim
            sim.setObjectPosition(self.cuerpo, self.escena.mundo, [self.x, self.y, .16])
            sim.setObjectOrientation(self.cuerpo, self.escena.mundo, [0, 0, self.th])

    def encoders(self):
        k = TICKS_POR_VUELTA / (2 * math.pi)
        return int(round(self.phi_izq * k)), int(round(self.phi_der * k))

    def camara(self):
        return self.x + CAMARA_ADELANTE * math.cos(self.th), self.y + CAMARA_ADELANTE * math.sin(self.th)

    def capturar(self):
        return self.escena.capturar(self.sensor)

    def avanzar(self, w_izq, w_der, dt, obstaculos):
        """Devuelve True si en este paso empezó una colisión nueva."""
        nueva = False
        n = max(1, math.ceil(dt / 0.02))
        h = dt / n
        v = self.radio * (w_der + w_izq) / 2
        w = self.radio * (w_der - w_izq) / self.eje
        for _ in range(n):
            self.phi_izq += w_izq * h
            self.phi_der += w_der * h
            th1 = self.th + w * h
            if abs(w) < 1e-9:
                nx, ny = self.x + v * h * math.cos(self.th), self.y + v * h * math.sin(self.th)
            else:
                nx = self.x + v / w * (math.sin(th1) - math.sin(self.th))
                ny = self.y - v / w * (math.cos(th1) - math.cos(self.th))
            self.th = _envolver(th1)
            if any(choca(nx, ny, c, self.radio_colision) for c in obstaculos):
                if not self.en_contacto:      # choque: el robot no avanza (las ruedas patinan)
                    nueva = True
                self.en_contacto = True
            else:
                self.x, self.y = nx, ny
                self.en_contacto = False
        self.t_sim += dt
        self._dibujar()
        return nueva


# ============================================================
# PIONEER P3DX (CoppeliaSim con física)
# ============================================================
RUTAS_MODELO = ["models/robots/mobile/pioneer p3dx.ttm", "robots/mobile/pioneer p3dx.ttm"]


def buscar_pioneer(sim):
    for ruta in ("/PioneerP3DX", "/Pioneer_p3dx"):
        try:
            return sim.getObject(ruta)
        except Exception:
            pass
    return None


class RobotPioneer:
    nombre = "Pioneer P3DX"

    def __init__(self, cliente, sim, escena, resolucion=320, ruta_modelo=None):
        self.cliente, self.sim, self.escena = cliente, sim, escena
        w = self.mundo = escena.mundo
        self.base = buscar_pioneer(sim)
        if self.base is None:
            self.base = self._cargar_modelo(ruta_modelo)
        self._quitar_scripts()

        # Motores
        juntas = sim.getObjectsInTree(self.base, sim.object_joint_type, 0)
        nombres = {j: sim.getObjectAlias(j).lower() for j in juntas}
        izq = [j for j, n in nombres.items() if "left" in n and "motor" in n]
        der = [j for j, n in nombres.items() if "right" in n and "motor" in n]
        if not izq or not der:
            raise RuntimeError(f"No se encontraron leftMotor/rightMotor en el Pioneer: {list(nombres.values())}")
        self.m_izq, self.m_der = izq[0], der[0]

        # Geometría medida en el modelo: distancia entre ruedas y radio de rueda
        pi_, pd = np.array(sim.getObjectPosition(self.m_izq, w)), np.array(sim.getObjectPosition(self.m_der, w))
        self.eje = float(np.linalg.norm(pi_ - pd))
        self.radio = self._radio_rueda() or 0.0975
        self.w_max = 8.0
        # Dirección "adelante" en el marco del robot (perpendicular al eje de las ruedas)
        izq_mundo = (pi_ - pd)[:2] / np.linalg.norm((pi_ - pd)[:2])
        adelante_mundo = np.array([izq_mundo[1], -izq_mundo[0], 0.0])
        R = self._rotacion()
        self.adelante_local = R.T @ adelante_mundo
        self.radio_colision = self._radio_huella()

        # Cámara a la misma altura que en el dataset, sobre un poste (si la escena ya la
        # tiene montada, se usa la que existe)
        self.sensor = self._buscar_camara()
        if self.sensor is not None:
            escena.ajustar_camara(self.sensor)
            print("Cámara existente en el Pioneer: se usa la de la escena.")
        else:
            cx, cy, th = self._pose()
            self.sensor = escena.crear_camara(resolucion)
            xc, yc = cx + CAMARA_ADELANTE * math.cos(th), cy + CAMARA_ADELANTE * math.sin(th)
            sim.setObjectMatrix(self.sensor, w, camera_matrix(xc, yc, ALTURA_CAMARA, th))
            sim.setObjectParent(self.sensor, self.base, True)
            z_base = sim.getObjectPosition(self.base, w)[2]
            poste = escena._caja("PosteCamara", [.03, .03, ALTURA_CAMARA - z_base],
                                 [xc - .03 * math.cos(th), yc - .03 * math.sin(th), (ALTURA_CAMARA + z_base) / 2],
                                 [.2] * 3, respondable=False)
            sim.setObjectInt32Param(poste, sim.shapeintparam_static, 1)
            sim.setObjectParent(poste, self.base, True)


        # Colecciones para detectar colisiones con muros y estaciones
        self.col_robot = self.col_obst = None
        try:
            self.col_robot = sim.createCollection(0)
            sim.addItemToCollection(self.col_robot, sim.handle_tree, self.base, 0)
            self.col_obst = sim.createCollection(0)
            for h in escena.muros + list(escena.objetos.values()):
                sim.addItemToCollection(self.col_obst, sim.handle_tree, h, 0)
        except Exception:
            print("  (aviso: sin colecciones; las colisiones se calculan con la geometría 2D)")

        self.dt_sim = float(sim.getSimulationTimeStep())
        self.phi_izq = self.phi_der = 0.0
        self.en_contacto = False
        self.t_sim = 0.0
        print(f"Pioneer P3DX: radio de rueda {self.radio:.4f} m, distancia entre ruedas {self.eje:.4f} m, "
              f"paso de simulación {self.dt_sim * 1000:.0f} ms")

    def _buscar_camara(self):
        """Sensor de visión 'CamaraFrontal' en cualquier nivel debajo del Pioneer."""
        sim = self.sim
        try:
            for h in sim.getObjectsInTree(self.base, sim.object_visionsensor_type, 0):
                if sim.getObjectAlias(h) == "CamaraFrontal":
                    return h
        except Exception:
            pass
        return None

    # ---------- carga y limpieza del modelo ----------
    def _cargar_modelo(self, ruta):
        sim = self.sim
        candidatas = [ruta] if ruta else []
        for clave in ("stringparam_resourcesdir", "stringparam_application_path"):
            try:
                base = sim.getStringParam(getattr(sim, clave))
                candidatas += [f"{base}/{r}" for r in RUTAS_MODELO]
            except Exception:
                pass
        candidatas += RUTAS_MODELO
        for c in candidatas:
            try:
                h = sim.loadModel(c)
                print(f"Modelo cargado: {c}")
                return h
            except Exception:
                continue
        raise RuntimeError("No se pudo cargar el Pioneer P3DX. Arrástralo a la escena desde la biblioteca "
                           "de modelos (robots/mobile) o indica la ruta con --modelo-pioneer.")

    def _quitar_scripts(self):
        """El modelo trae un script de evasión (Braitenberg) que mueve los motores por su
        cuenta; hay que quitarlo para que solo mande el microcontrolador."""
        sim, quitados, revisado = self.sim, 0, False
        for clave in ("sceneobject_script", "object_script_type"):
            tipo = getattr(sim, clave, None)
            if tipo is None:
                continue
            try:
                for s in sim.getObjectsInTree(self.base, tipo, 0):
                    sim.removeObjects([s])
                    quitados += 1
                revisado = True
                break
            except Exception:
                pass
        try:
            s = sim.getScript(sim.scripttype_childscript, self.base)
            if s is not None and s != -1:
                sim.removeScript(s)
                quitados += 1
            revisado = True
        except Exception:
            pass
        if quitados:
            print(f"Script de evasión del Pioneer quitado ({quitados}).")
        elif not revisado:
            print("  AVISO: no se pudo revisar el script del Pioneer. Si el robot no obedece al micro, "
                  "bórralo a mano en la jerarquía (icono de script junto a PioneerP3DX).")

    def _radio_rueda(self):
        sim = self.sim
        try:
            formas = sim.getObjectsInTree(self.m_izq, sim.object_shape_type, 1)
            tam = sim.getShapeBB(formas[0])
            return float(max(tam)) / 2
        except Exception:
            return None

    def _radio_huella(self):
        sim = self.sim
        try:
            xs = [sim.getObjectFloatParam(self.base, getattr(sim, f"objfloatparam_modelbbox_{e}"))
                  for e in ("min_x", "max_x", "min_y", "max_y")]
            return 0.5 * math.hypot(xs[1] - xs[0], xs[3] - xs[2])
        except Exception:
            return 0.27

    # ---------- pose ----------
    def _rotacion(self):
        m = self.sim.getObjectMatrix(self.base, self.mundo)
        return np.array([m[0:3], m[4:7], m[8:11]])

    def _pose(self):
        pi_ = self.sim.getObjectPosition(self.m_izq, self.mundo)
        pd = self.sim.getObjectPosition(self.m_der, self.mundo)
        f = self._rotacion() @ self.adelante_local if hasattr(self, "adelante_local") else None
        th = math.atan2(f[1], f[0]) if f is not None else 0.0
        return (pi_[0] + pd[0]) / 2, (pi_[1] + pd[1]) / 2, th

    @property
    def x(self):
        return self._pose()[0]

    @property
    def y(self):
        return self._pose()[1]

    @property
    def th(self):
        return self._pose()[2]

    def camara(self):
        p = self.sim.getObjectPosition(self.sensor, self.mundo)
        return p[0], p[1]

    def capturar(self):
        return self.escena.capturar(self.sensor)

    # ---------- simulación ----------
    def _paso(self):
        try:
            self.sim.step()
        except Exception:
            self.cliente.step()

    def _stepping(self, activo):
        try:
            self.sim.setStepping(activo)
        except Exception:
            self.cliente.setStepping(activo)

    def terminar(self):
        sim = self.sim
        if sim.getSimulationState() != sim.simulation_stopped:
            sim.stopSimulation()
            while sim.getSimulationState() != sim.simulation_stopped:
                try:
                    self._paso()
                except Exception:
                    time.sleep(0.05)

    def colocar(self, x, y, th):
        """Coloca el robot (simulación detenida) con el centro del eje en (x, y)."""
        self.terminar()
        sim, w = self.sim, self.mundo
        e = sim.getObjectOrientation(self.base, w)
        sim.setObjectOrientation(self.base, w, [e[0], e[1], e[2] + _envolver(th - self._pose()[2])])
        cx, cy, _ = self._pose()
        b = sim.getObjectPosition(self.base, w)
        sim.setObjectPosition(self.base, w, [b[0] + x - cx, b[1] + y - cy, b[2]])
        self.phi_izq = self.phi_der = 0.0
        self.en_contacto = False
        self.t_sim = 0.0

    def iniciar(self):
        self._stepping(True)
        self.sim.startSimulation()
        self.q_izq = self.sim.getJointPosition(self.m_izq)
        self.q_der = self.sim.getJointPosition(self.m_der)

    def encoders(self):
        k = TICKS_POR_VUELTA / (2 * math.pi)
        return int(round(self.phi_izq * k)), int(round(self.phi_der * k))

    def _choque(self, obstaculos):
        if self.col_robot is not None:
            try:
                r = self.sim.checkCollision(self.col_robot, self.col_obst)
                return bool(r[0] if isinstance(r, (list, tuple)) else r)
            except Exception:
                self.col_robot = None
        x, y, _ = self._pose()
        return any(choca(x, y, c, self.radio_colision) for c in obstaculos)

    def avanzar(self, w_izq, w_der, dt, obstaculos):
        """Aplica las velocidades a los motores durante dt segundos simulados."""
        sim = self.sim
        sim.setJointTargetVelocity(self.m_izq, float(w_izq))
        sim.setJointTargetVelocity(self.m_der, float(w_der))
        nueva = False
        for _ in range(max(1, round(dt / self.dt_sim))):
            self._paso()
            self.t_sim += self.dt_sim
            # Encoders: se acumula el cambio de ángulo en cada paso (las juntas dan vueltas)
            qi, qd = sim.getJointPosition(self.m_izq), sim.getJointPosition(self.m_der)
            self.phi_izq += _envolver(qi - self.q_izq)
            self.phi_der += _envolver(qd - self.q_der)
            self.q_izq, self.q_der = qi, qd
            choque = self._choque(obstaculos)
            if choque and not self.en_contacto:
                nueva = True
            self.en_contacto = choque
        return nueva
